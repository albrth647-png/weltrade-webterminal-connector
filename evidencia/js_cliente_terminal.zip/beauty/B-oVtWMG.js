var e, t, r, n = e => {
        throw TypeError(e)
    },
    a = (e, t, r) => t.has(e) || n("Cannot " + r),
    o = (e, t, r) => (a(e, t, "read from private field"), r ? r.call(e) : t.get(e)),
    i = (e, t, r) => t.has(e) ? n("Cannot add the same private member more than once") : t instanceof WeakSet ? t.add(e) : t.set(e, r),
    s = (e, t, r, n) => (a(e, t, "write to private field"), n ? n.call(e, r) : t.set(e, r), r);

function u(e) {
    const t = e.indexOf("//"),
        r = -1 !== t ? t + 2 : 0;
    return e.slice(r)
}
const c = {
    get: function(e) {
        return new URLSearchParams(window.self.location.search).get(e)
    },
    remove: function(e) {
        const t = new URL(window.self.location.href);
        t.searchParams.delete(e), window.self.history.replaceState(null, "", t.href)
    },
    stringify: function(e, t = "?") {
        const r = [];
        return Object.keys(e).forEach(t => {
            const n = e[t];
            "boolean" == typeof n ? r.push(`${t}=${Number(n)}`) : ("number" == typeof n && !isNaN(n) || n) && r.push(`${t}=${n}`)
        }), r.length ? `${t}${r.join("&")}` : ""
    },
    parse: function(e = window.self.location.search) {
        const t = new URLSearchParams(e),
            r = {};
        return t.forEach((e, t) => {
            r[t] = e
        }), r
    }
};
var l, f, h, g = (l = {}, Object.defineProperty(l, Symbol.toStringTag, {
    value: "Module"
}), l.isHighDensity = function() {
    return !!(window.devicePixelRatio && window.devicePixelRatio > 1.3)
}, l.isMacOs = function() {
    return void 0 === h && (h = !!~navigator.userAgent.indexOf("Mac")), h
}, l.isTouch = function() {
    if ("maxTouchPoints" in navigator) var e = navigator.maxTouchPoints > 1;
    else void 0 === f && (f = /Android|webOS|iPhone|iPad|iPod|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)), e = f;
    return e
}, l.isWindows = function() {
    var e, t, r, n = Reflect.get(navigator, "userAgentData");
    return n = "object" == typeof n && null !== n && "platform" in n && "string" == typeof n.platform ? {
        platform: n.platform
    } : void 0, (null == (e = null == navigator ? void 0 : navigator.platform) ? void 0 : e.toLowerCase().indexOf("win")) >= 0 || (null == (t = navigator.appVersion) ? void 0 : t.toLowerCase().indexOf("win")) >= 0 || void 0 !== n && n.platform.toLowerCase().includes("win") || (null == (r = navigator.userAgent) ? void 0 : r.toLowerCase().indexOf("win")) >= 0
}, l);
const p = g.isHighDensity,
    d = g.isMacOs,
    b = g.isTouch,
    m = g.isWindows,
    y = Object.freeze(Object.defineProperty({
        __proto__: null,
        isHighDensity: p,
        isMacOs: d,
        isTouch: b,
        isWindows: m
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var w = function(e) {
    Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    });
    var t = [1, 10, 100, 1e3, 1e4, 1e5, 1e6, 1e7, 1e8];
    return e.normalize = function(e, r) {
        return r = t[Math.min(Math.max(r, 0), 8)], e >= 0 ? Math.floor(e * r + .5000001) / r : Math.ceil(e * r - .5000001) / r
    }, e
}({});
const A = w.normalize,
    S = Object.freeze(Object.defineProperty({
        __proto__: null,
        normalize: A
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var M = function(e, t) {
    return Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    }), e.toMoney = function(e, r) {
        r = (e = (0, t.normalize)(e, r).toFixed(r).split("."))[0].startsWith("-") ? 1 : 0;
        for (let t = e[0].length - 3; t > r; t -= 3) e[0] = `${e[0].slice(0,t)} ${e[0].slice(t)}`;
        return e.join(".")
    }, e
}({}, S);
const T = M.toMoney,
    v = Object.freeze(Object.defineProperty({
        __proto__: null,
        toMoney: T
    }, Symbol.toStringTag, {
        value: "Module"
    }));

function C(e) {
    const t = [];
    for (let r = 0, n = e.length / 2; r < n; r++) t.push(Number(`0x${e.substring(2*r,2*r+2)}`));
    return new Uint8Array(t).buffer
}

function U(e) {
    const t = [];
    for (let r = 0; r < e.length; r++) 28 === e.charCodeAt(r) ? t.push("&") : 23 === e.charCodeAt(r) ? t.push("!") : t.push(String.fromCharCode(e.charCodeAt(r) - 1));
    return t.join("")
}
const k = {
        hexToBuffer: C,
        toHex: function(e) {
            let t = "";
            for (let r = 0, n = e.length; r < n; r++) t += e.charCodeAt(r).toString(16).padStart(2, "0");
            return t
        },
        obfuscation: U,
        trimZeros: function(e, t) {
            let r = e,
                n = r.length,
                a = 0;
            for (; n > 0 && "0" === r.charAt(n - 1) && a < t;) n -= 1, a += 1;
            return r = r.substring(0, n), n > 0 && "." === r.charAt(n - 1) && (r = r.substring(0, n - 1)), r
        }
    },
    E = (null == (e = globalThis.crypto) ? void 0 : e.subtle) ?? null,
    O = "AES-CBC";

function D() {
    return !!E
}
async function I(e) {
    if (!D()) throw new Error("Error initializing crypto api");
    const t = {
        name: O
    };
    return E.importKey("raw", e, t, !0, ["encrypt", "decrypt"])
}

function _(e, t) {
    const r = {
        name: O,
        iv: new Uint8Array(16)
    };
    return E.encrypt(r, t, e)
}

function x(e, t) {
    const r = {
        name: O,
        iv: new Uint8Array(16)
    };
    return E.decrypt(r, t, e)
}
const j = {
    available: D,
    initKey: I,
    enc: _,
    dec: x
};

function F() {
    const {
        name: e
    } = window;
    if (e && Boolean(e.split("").find(e => isNaN(parseInt(e, 10))))) return e.substring(0, 12);
    let t = document.cookie;
    if (t && (t = t.split(";").find(e => 0 === e.indexOf("uniq=")), t && (t = t.split("=")[1], t))) {
        if (t = t.split("-"), 1 === t.length && t[0].length >= 12) return t[0].substring(0, 12);
        if (t.length > 1) return t[0] + t[1]
    }
    return ""
}
let N = null,
    L = !1;
const P = function() {
    if (L || (L = !0, N || (N = document.createElement("div"), N.className = "GoogleAd Advertisment BannerAd", N.id = "yandex_ad", N.style.width = "1px", N.style.height = "1px", N.style.visibility = "hidden", N.style.position = "absolute", document.body.appendChild(N))), !N) return !1;
    const e = 0 === N.offsetHeight;
    try {
        document.body.removeChild(N)
    } catch (t) {}
    return N = null, e
}();

function z(e) {
    const t = (65280 & e) >> 8,
        r = 255 & e;
    return `#${((16711680&e)>>16).toString(16).padStart(2,"0")}${t.toString(16).padStart(2,"0")}${r.toString(16).padStart(2,"0")}`
}

function B(e) {
    return [(16711680 & e) >> 16, (65280 & e) >> 8, 255 & e].join(",")
}
var R = function(e) {
    function t() {}
    Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    });
    var r = [];
    return e.Store = class {
        constructor(e = t) {
            this.subscribers = [], this.stop = null, this.value = this, this.start = e
        }
        set(e) {
            var t = this.value;
            if ((t == t ? t !== e || t && "object" == typeof t || "function" == typeof t : e == e) && (this.value = e, this.stop)) {
                for (e = !r.length, t = 0; t < this.subscribers.length; t += 1) {
                    let e = this.subscribers[t];
                    e[1](), r.push(e, this.value)
                }
                if (e) {
                    for (e = 0; e < r.length; e += 2) r[e][0](r[e + 1]);
                    r.length = 0
                }
            }
        }
        update(e) {
            this.set(e(this.value))
        }
        subscribe(e, r = t) {
            var n = [e, r];
            return this.subscribers.push(n), 1 === this.subscribers.length && (this.stop = this.start(this.set) || t), e(this.value), () => {
                var e = this.subscribers.indexOf(n); - 1 !== e && this.subscribers.splice(e, 1), 0 === this.subscribers.length && this.stop && (this.stop(), this.stop = null)
            }
        }
        refresh() {
            this.update(e => e)
        }
    }, e.Subscribe = function(e, t, r) {
        if (r) {
            var n = r.value;
            r.value = function(...e) {
                return (e = n.apply(this, e)) instanceof Promise ? e.then(() => this.set(this)) : this.set(this), e
            }
        }
    }, e
}({});
const H = R.Store,
    V = R.Subscribe,
    X = Object.freeze(Object.defineProperty({
        __proto__: null,
        Store: H,
        Subscribe: V
    }, Symbol.toStringTag, {
        value: "Module"
    }));
class $ {
    constructor() {
        i(this, t, {})
    }
    getItem(e) {
        return o(this, t)[e] ?? null
    }
    setItem(e, r) {
        o(this, t)[e] = r
    }
    removeItem(e) {
        delete o(this, t)[e]
    }
    clear() {
        s(this, t, {})
    }
    get length() {
        return Object.keys(o(this, t)).length
    }
    key(e) {
        return Object.keys(o(this, t))[e] ?? null
    }
}
t = new WeakMap;
class W {
    constructor(e) {
        i(this, r),
            function(e) {
                try {
                    return !!e && (e.setItem("a", "b"), e.removeItem("a"), !0)
                } catch (t) {
                    return !1
                }
            }(e) ? s(this, r, e) : s(this, r, new $)
    }
    getItem(e) {
        return o(this, r).getItem(e)
    }
    setItem(e, t) {
        o(this, r).setItem(e, t)
    }
    removeItem(e) {
        o(this, r).removeItem(e)
    }
}
r = new WeakMap;
const J = new W(window.localStorage),
    Y = new W(window.sessionStorage);
var q = function(e) {
    function t(e, t, r) {
        return e === t ? 0 : Math.round(((e > t ? e : t) - (e < t ? e : t)) / (60 * r * 1e3))
    }

    function r(e, t = 1, r = 1) {
        switch (t) {
            case 1:
                e.setUTCMinutes(e.getUTCMinutes() + 1 * r);
                break;
            case 5:
                e.setUTCMinutes(e.getUTCMinutes() + 5 * r);
                break;
            case 15:
                e.setUTCMinutes(e.getUTCMinutes() + 15 * r);
                break;
            case 30:
                e.setUTCMinutes(e.getUTCMinutes() + 30 * r);
                break;
            case 60:
                e.setUTCHours(e.getUTCHours() + 1 * r);
                break;
            case 240:
                e.setUTCHours(e.getUTCHours() + 4 * r);
                break;
            case 1440:
                e.setUTCDate(e.getUTCDate() + 1 * r);
                break;
            case 10080:
                e.setUTCDate(e.getUTCDate() + 7 * r);
                break;
            case 43200:
                e.setUTCMonth(e.getUTCMonth() + 1 * r)
        }
    }
    Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    });
    var n, a, o = Object.freeze("January February March April May June July August September October November December".split(" ")),
        i = Object.freeze("Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split(" ")),
        s = Object.freeze("Sunday Monday Tuesday Wednesday Thursday Friday Saturday".split(" ")),
        u = Object.freeze("Sun Mon Tue Wed Thu Fri Sat".split(" "));
    return e.align = function(e, t) {
        switch ((e = new Date(e)).setUTCMilliseconds(0), e.setUTCSeconds(0), t && t >= 60 && e.setUTCMinutes(0), t && t >= 1440 && e.setUTCHours(0), t && t >= 43200 && e.setUTCDate(1), t) {
            case 5:
                e.setUTCMinutes(5 * Math.floor(e.getUTCMinutes() / 5));
                break;
            case 15:
                e.setUTCMinutes(15 * Math.floor(e.getUTCMinutes() / 15));
                break;
            case 30:
                e.setUTCMinutes(30 * Math.floor(e.getUTCMinutes() / 30));
                break;
            case 240:
                e.setUTCHours(4 * Math.floor(e.getUTCHours() / 4));
                break;
            case 10080:
                for (; 0 !== e.getUTCDay();) e.setUTCDate(e.getUTCDate() - 1)
        }
        return e.getTime()
    }, e.dateOffset = function(e, t = 1, n = 0) {
        return r(e = new Date(e), t, n), e.getTime()
    }, e.dateShift = r, e.diff = function(e, r, n) {
        if (-1 === "YMDhm".indexOf(n) || e === r) return 0;
        var a = e < r ? e : r;
        switch (e = e > r ? e : r, n) {
            case "Y":
                return t(a, e, 518400);
            case "M":
                return t(a, e, 43200);
            case "D":
                return t(a, e, 1440);
            case "h":
                return t(a, e, 60);
            case "m":
                return t(a, e, 1);
            default:
                return 0
        }
    }, e.difference = t, e.formatDate = function(e, t = "DD.MM.YY hhhh:mm:ss", r = !0) {
        e = new Date(e);
        var n = r ? e.getUTCDate() : e.getDate(),
            a = r ? e.getUTCMonth() : e.getMonth(),
            c = r ? e.getUTCFullYear() : e.getFullYear(),
            l = r ? e.getUTCMinutes() : e.getMinutes(),
            f = r ? e.getUTCSeconds() : e.getSeconds(),
            h = r ? e.getUTCHours() : e.getHours(),
            g = r ? e.getUTCDay() : e.getDay(),
            p = h >= 12 ? "PM" : "AM",
            d = h % 12 || 12;
        r = {
            sss: (r ? e.getUTCMilliseconds() : e.getMilliseconds()).toString().padStart(3, "0"),
            ss: f.toString().padStart(2, "0"),
            s: f,
            mm: l.toString().padStart(2, "0"),
            m: l,
            hhhh: h.toString().padStart(2, "0"),
            hhh: h,
            hh: `${d.toString().padStart(2,"0")}${p}`,
            h: `${d}${p}`,
            DDDD: s[g],
            DDD: u[g],
            DD: n.toString().padStart(2, "0"),
            D: n,
            MMMM: o[a],
            MMM: i[a],
            MM: (a + 1).toString().padStart(2, "0"),
            M: a + 1,
            YY: c,
            Y: c.toString().substring(2)
        }, e = "";
        for (let o = 0, i = t.length; o < i; o++) {
            n = t.charAt(o);
            e: {
                for (a = o, c = 4; c > 1;) {
                    if (l = n.repeat(c), t.substring(a, a + c) === l) {
                        a = l;
                        break e
                    }--c
                }
                a = n
            }
            void 0 === r[a] ? e += n : (e += r[a], o += a.length - 1)
        }
        return e
    }, e.getOffset = function(e = !0) {
        return e ? n - a : n
    }, e.isAligned = function(e, t) {
        if (0 !== (e = new Date(e)).getUTCMilliseconds() || 0 !== e.getUTCSeconds()) return !1;
        switch (t) {
            case 1:
                return !0;
            case 5:
                return e.getUTCMinutes() % 5 == 0;
            case 15:
                return e.getUTCMinutes() % 15 == 0;
            case 30:
                return e.getUTCMinutes() % 30 == 0
        }
        if (t >= 60) {
            if (0 !== e.getUTCMinutes()) return !1;
            switch (t) {
                case 60:
                    return !0;
                case 240:
                    return e.getUTCHours() % 4 == 0
            }
        }
        return !(t >= 1440 && 0 !== e.getUTCHours() || t >= 43200 && 1 !== e.getUTCDate())
    }, e.setTimeOffset = function(e, t) {
        n = e, a = t
    }, e
}({});
const K = q.align,
    G = q.dateOffset,
    Z = q.dateShift,
    Q = q.diff,
    ee = q.difference,
    te = q.formatDate;
q.getOffset;
const re = q.isAligned;
q.setTimeOffset;
const ne = Object.freeze(Object.defineProperty({
        __proto__: null,
        align: K,
        dateOffset: G,
        dateShift: Z,
        diff: Q,
        difference: ee,
        formatDate: te,
        isAligned: re
    }, Symbol.toStringTag, {
        value: "Module"
    })),
    ae = [{
        tz: "UTC",
        offset: 0
    }, ... function e(t) {
        const r = [];
        return Object.values(t).forEach(t => {
            if ("object" == typeof t) {
                const n = e(t);
                r.push(...n)
            } else r.push(t)
        }), r
    }({
        africa: {
            cairo: "Africa/Cairo",
            casablanca: "Africa/Casablanca",
            johannesburg: "Africa/Johannesburg",
            lagos: "Africa/Lagos",
            nairobi: "Africa/Nairobi",
            tunis: "Africa/Tunis"
        },
        america: {
            anchorage: "America/Anchorage",
            bogota: "America/Bogota",
            buenosAires: "America/Buenos_Aires",
            caracas: "America/Caracas",
            chicago: "America/Chicago",
            denver: "America/Denver",
            elSalvador: "America/El_Salvador",
            juneau: "America/Juneau",
            lima: "America/Lima",
            losAngeles: "America/Los_Angeles",
            mexicoCity: "America/Mexico_City",
            newYork: "America/New_York",
            phoenix: "America/Phoenix",
            santiago: "America/Santiago",
            saoPaulo: "America/Sao_Paulo",
            toronto: "America/Toronto",
            vancouver: "America/Vancouver"
        },
        asia: {
            almaty: "Asia/Almaty",
            ashgabat: "Asia/Ashgabat",
            bahrain: "Asia/Bahrain",
            bangkok: "Asia/Bangkok",
            calcutta: "Asia/Calcutta",
            colombo: "Asia/Colombo",
            dhaka: "Asia/Dhaka",
            dubai: "Asia/Dubai",
            hongKong: "Asia/Hong_Kong",
            jakarta: "Asia/Jakarta",
            jerusalem: "Asia/Jerusalem",
            karachi: "Asia/Karachi",
            katmandu: "Asia/Katmandu",
            kuwait: "Asia/Kuwait",
            manila: "Asia/Manila",
            muscat: "Asia/Muscat",
            nicosia: "Asia/Nicosia",
            qatar: "Asia/Qatar",
            rangoon: "Asia/Rangoon",
            riyadh: "Asia/Riyadh",
            saigon: "Asia/Saigon",
            seoul: "Asia/Seoul",
            shanghai: "Asia/Shanghai",
            singapore: "Asia/Singapore",
            taipei: "Asia/Taipei",
            tehran: "Asia/Tehran",
            tokyo: "Asia/Tokyo"
        },
        atlantic: {
            reykjavik: "Atlantic/Reykjavik"
        },
        australia: {
            adelaide: "Australia/Adelaide",
            brisbane: "Australia/Brisbane",
            perth: "Australia/Perth",
            sydney: "Australia/Sydney"
        },
        europe: {
            amsterdam: "Europe/Amsterdam",
            athens: "Europe/Athens",
            belgrade: "Europe/Belgrade",
            berlin: "Europe/Berlin",
            bratislava: "Europe/Bratislava",
            brussels: "Europe/Brussels",
            bucharest: "Europe/Bucharest",
            budapest: "Europe/Budapest",
            copenhagen: "Europe/Copenhagen",
            dublin: "Europe/Dublin",
            helsinki: "Europe/Helsinki",
            istanbul: "Europe/Istanbul",
            lisbon: "Europe/Lisbon",
            london: "Europe/London",
            luxembourg: "Europe/Luxembourg",
            madrid: "Europe/Madrid",
            malta: "Europe/Malta",
            moscow: "Europe/Moscow",
            oslo: "Europe/Oslo",
            paris: "Europe/Paris",
            prague: "Europe/Prague",
            riga: "Europe/Riga",
            rome: "Europe/Rome",
            stockholm: "Europe/Stockholm",
            tallinn: "Europe/Tallinn",
            vienna: "Europe/Vienna",
            vilnius: "Europe/Vilnius",
            warsaw: "Europe/Warsaw",
            zurich: "Europe/Zurich"
        },
        pacific: {
            auckland: "Pacific/Auckland",
            chatham: "Pacific/Chatham",
            fakaofo: "Pacific/Fakaofo",
            honolulu: "Pacific/Honolulu",
            norfolk: "Pacific/Norfolk"
        }
    }).map(e => ({
        tz: e,
        offset: ie(e)
    })).sort((e, t) => e.offset - t.offset)],
    oe = {};

function ie(e) {
    const t = new Date,
        r = t.toLocaleString("en-US", {
            timeZone: e
        }),
        n = t.toLocaleString("en-US"),
        a = (Date.parse(n) - Date.parse(r)) / 6e4 + t.getTimezoneOffset();
    return 0 === a ? a : -a
}

function se(e) {
    try {
        if (e instanceof Error) {
            const t = JSON.parse(e.message);
            return Array.isArray(t) && 2 === t.length && t.every(e => "number" == typeof e) ? [t[1], t[0]] : [e.message]
        }
    } catch {
        return [null]
    }
    return [null]
}

function ue(e) {
    switch (e) {
        case 1:
            return window.tr(window.lang.chart.period.short.M1);
        case 5:
            return window.tr(window.lang.chart.period.short.M5);
        case 15:
            return window.tr(window.lang.chart.period.short.M15);
        case 30:
            return window.tr(window.lang.chart.period.short.M30);
        case 60:
            return window.tr(window.lang.chart.period.short.H1);
        case 240:
            return window.tr(window.lang.chart.period.short.H4);
        case 1440:
            return window.tr(window.lang.chart.period.short.D1);
        case 10080:
            return window.tr(window.lang.chart.period.short.W1);
        case 43200:
            return window.tr(window.lang.chart.period.short.MN);
        default:
            return window.tr(window.lang.chart.period.short.Unknown)
    }
}
ae.forEach(e => {
    oe[e.tz] = e
});
var ce = function(e) {
    function t(e) {
        return e instanceof Object || Array.isArray(e)
    }
    return Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    }), e.copy = function(e) {
        return e = JSON.stringify(e), JSON.parse(e)
    }, e.diff = function e(r, n) {
        var a = {},
            o = !1;
        return Object.keys(r).forEach(i => {
            var s = Reflect.get(n, i),
                u = Reflect.get(r, i);
            if (![null, void 0, u].includes(s)) {
                var c = s;
                "object" == typeof s && t(s) && (c = e(t(u) ? u : {}, s)), null != c && (Object.assign(a, {
                    [i]: c
                }), o = !0)
            }
        }), o ? a : null
    }, e.extend = function e(r, n) {
        return Object.keys(n).forEach(a => {
            var o = Reflect.get(n, a);
            t(o) ? (t(Reflect.get(r, a)) || Reflect.set(r, a, {}), t(a = Reflect.get(r, a)) && e(a, o)) : null === o ? Reflect.deleteProperty(r, a) : Reflect.set(r, a, o)
        }), r
    }, e.isObject = t, e
}({});
const le = ce.copy,
    fe = ce.diff,
    he = ce.extend,
    ge = ce.isObject,
    pe = Object.freeze(Object.defineProperty({
        __proto__: null,
        copy: le,
        diff: fe,
        extend: he,
        isObject: ge
    }, Symbol.toStringTag, {
        value: "Module"
    }));

function de() {
    return !!(document.fullscreenElement || document.mozFullScreenElement || document.webkitFullscreenElement || document.msFullscreenElement)
}

function be() {
    de() ? document.exitFullscreen ? document.exitFullscreen() : document.webkitExitFullscreen ? document.webkitExitFullscreen() : document.mozCancelFullscreen ? document.mozCancelFullscreen() : document.msExitFullscreen && document.msExitFullscreen() : function() {
        const {
            documentElement: e
        } = document;
        e.requestFullscreen ? e.requestFullscreen() : e.webkitRequestFullscreen ? e.webkitRequestFullscreen() : e.mozRequestFullscreen ? e.mozRequestFullscreen() : e.msRequestFullscreen && e.msRequestFullscreen()
    }()
}
var me = function(e, t) {
    function r(e, r = 0) {
        return r = Math.min(r, 8), (0, t.normalize)(e / 10 ** r, r)
    }

    function n(e, r = 0) {
        return r = Math.min(r, 8), (0, t.normalize)(Number(e) / Number(10n ** BigInt(r)), r)
    }

    function a(e, t) {
        return e - Math.floor(e / t) * t
    }

    function o(e, r = 2) {
        if (e < 0) return 8;
        if (0 === e) return r;
        e = (0, t.normalize)(e, 8);
        for (var n = 5e-9, a = 0; a < 8 && Math.abs(e - Math.round(e)) > n;) e *= 10, n *= 10, a += 1;
        return a < r && (a = r), a
    }

    function i(e, t) {
        if (0 === t) return 0n;
        if (!Number.isFinite(t)) throw new TypeError(`Input must be finite: ${t}`);
        var r = new DataView(new ArrayBuffer(8));
        r.setFloat64(0, t, !0);
        var n = ((r = r.getBigUint64(0, !0)) & ~(1n << 63n)) >> 52n;
        if (0n === n) throw Error(`Subnormal floats not supported: ${t}`);
        var {
            i: a,
            exponent: o,
            h: i
        } = {
            i: (-1n) ** (r >> 63n),
            exponent: n - 1023n,
            h: r & (1n << 52n) - 1n
        };
        return r = (t = (e *= a * 2n ** (o + 1023n) * (4503599627370496n + i)) < 0n ? -e : e) / 0x80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000n, t % 0x80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000n * 2n > 0x80000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000000n && (r += 1n), (e < 0n ? -1n : 1n) * r
    }
    Object.defineProperties(e, {
        [Symbol.toStringTag]: {
            value: "Module"
        }
    });
    var s = {
            abs: e => e < 0n ? -e : e,
            max: function(...e) {
                if (0 === e.length) throw new TypeError("Expected at least one bigint");
                return e.slice(1).reduce((e, t) => t > e ? t : e, e[0])
            },
            min: function(...e) {
                if (0 === e.length) throw new TypeError("Expected at least one bigint");
                return e.slice(1).reduce((e, t) => t < e ? t : e, e[0])
            }
        },
        u = {
            INT32_MAX: 2147483647,
            UINT32_MAX: 4294967295,
            FLOAT64_MAX: 17976931348623157e292,
            INT64_MAX: 0x7fffffffffffffffn,
            INT64_MAX_UNSIGNED: 0xffffffffffffffffn,
            INT64_MIN: -0x8000000000000000n,
            toDouble: r,
            toDouble64: n,
            fmod: a,
            calcDecimalsCount: o,
            multiplyFloat: i,
            bMath: s
        };
    return e.FLOAT64_MAX = 17976931348623157e292, e.INT32_MAX = 2147483647, e.INT64_MAX = 0x7fffffffffffffffn, e.INT64_MAX_UNSIGNED = 0xffffffffffffffffn, e.INT64_MIN = -0x8000000000000000n, e.UINT32_MAX = 4294967295, e.bMath = s, e.calcDecimalsCount = o, e.default = u, e.fmod = a, e.multiplyFloat = i, e.toDouble = r, e.toDouble64 = n, e
}({}, S);
const ye = me.FLOAT64_MAX,
    we = me.INT32_MAX,
    Ae = me.INT64_MAX,
    Se = me.INT64_MAX_UNSIGNED,
    Me = me.INT64_MIN,
    Te = me.UINT32_MAX,
    ve = me.bMath,
    Ce = me.calcDecimalsCount,
    Ue = me.fmod,
    ke = me.multiplyFloat,
    Ee = me.toDouble,
    Oe = me.toDouble64,
    De = me.default,
    Ie = Object.freeze(Object.defineProperty({
        __proto__: null,
        FLOAT64_MAX: ye,
        INT32_MAX: we,
        INT64_MAX: Ae,
        INT64_MAX_UNSIGNED: Se,
        INT64_MIN: Me,
        UINT32_MAX: Te,
        bMath: ve,
        calcDecimalsCount: Ce,
        default: De,
        fmod: Ue,
        multiplyFloat: ke,
        toDouble: Ee,
        toDouble64: Oe
    }, Symbol.toStringTag, {
        value: "Module"
    }));
var _e = function(e) {
    function t(e, t) {
        return `incorrect type ${e}, expected ${t}`
    }

    function r(e, t = "", r = 0) {
        if (e) {
            e = new DataView(e);
            for (let n = 0, a = t.length; n < a; n++) e.setInt8(r, t.charCodeAt(n)), r += 1
        }
    }

    function n(e, t = 0, r = 0) {
        return e = new Uint8Array(e.slice(t, t + r)), String.fromCharCode(...e)
    }

    function a(e) {
        var r = 0;
        return e.forEach(e => {
            var n, a;
            switch (e.propType) {
                case o.Int8:
                case o.Uint8:
                    r += 1;
                    break;
                case o.Int16:
                case o.Uint16:
                    r += 2;
                    break;
                case o.Int32:
                case o.Uint32:
                case o.Float32:
                    r += 4;
                    break;
                case o.Float64:
                case o.FileTime:
                case o.Int64:
                case o.Uint64:
                    r += 8;
                    break;
                case o.Char:
                    e.propLength ? r += e.propLength : "string" == typeof e.propValue && (r += e.propValue.length);
                    break;
                case o.Wchar:
                    if (e.propLength) r += e.propLength;
                    else {
                        if ("string" != typeof e.propValue) throw e = t(typeof e.propValue, "string"), Error(e);
                        r += 2 * e.propValue.length
                    }
                    break;
                case o.Buffer:
                    if (e.propLength) r += e.propLength;
                    else {
                        if ((null == (n = e.propValue) ? void 0 : n.constructor) !== ArrayBuffer) throw e = t(typeof e.propValue, "ArrayBuffer"), Error(e);
                        r += e.propLength || (null == (a = e.propValue) ? void 0 : a.byteLength) || 0
                    }
            }
        }), r
    }
    Object.defineProperty(e, Symbol.toStringTag, {
        value: "Module"
    });
    var o = {
        Int8: 1,
        Int16: 2,
        Int32: 3,
        Int64: 17,
        Uint8: 4,
        Uint16: 5,
        Uint32: 6,
        Uint64: 18,
        Float32: 7,
        Float64: 8,
        FileTime: 9,
        Char: 10,
        Wchar: 11,
        Buffer: 12
    };
    return e.PROP_TYPES = o, e.concat = function(e, t) {
        var r = new Uint8Array(e.byteLength + t.byteLength);
        return r.set(new Uint8Array(e), 0), r.set(new Uint8Array(t), e.byteLength), r.buffer
    }, e.getCharString = n, e.getSeriesSize = a, e.getString16 = function(e, t, r) {
        e = new Uint8Array(e.slice(t, t + r)), t = "", r = (e = String.fromCharCode(...e)).length;
        for (var n = 0; n < r;) {
            let r = e.charCodeAt(n);
            n += 1;
            e: switch (r >> 4) {
                case 0:
                case 1:
                case 2:
                case 3:
                case 4:
                case 5:
                case 6:
                case 7:
                    n = {
                        h: e.charAt(n - 1),
                        i: n
                    };
                    break e;
                case 12:
                case 13:
                    n = {
                        h: String.fromCharCode((31 & r) << 6 | 63 & e.charCodeAt(n)),
                        i: n + 1
                    };
                    break e;
                case 14:
                    n = {
                        h: String.fromCharCode((15 & r) << 12 | (63 & e.charCodeAt(n)) << 6 | 63 & e.charCodeAt(n + 1)),
                        i: n + 2
                    };
                    break e;
                default:
                    n = {
                        h: "",
                        i: n
                    }
            }
            t += n.h, n = n.i
        }
        return t
    }, e.parse = function(e, t, r = 0) {
        var a = [],
            i = new DataView(e);
        return t.forEach((t, s) => {
            if (!(r >= e.byteLength)) {
                var u = 0;
                switch (t.propType) {
                    case o.Int8:
                        u = i.getInt8(r), r += 1;
                        break;
                    case o.Int16:
                        u = i.getInt16(r, !0), r += 2;
                        break;
                    case o.Int32:
                        u = i.getInt32(r, !0), r += 4;
                        break;
                    case o.Uint8:
                        u = i.getUint8(r), r += 1;
                        break;
                    case o.Uint16:
                        u = i.getUint16(r, !0), r += 2;
                        break;
                    case o.Uint32:
                        u = i.getUint32(r, !0), r += 4;
                        break;
                    case o.Float32:
                        u = i.getFloat32(r, !0), r += 4;
                        break;
                    case o.Float64:
                        u = i.getFloat64(r, !0), r += 8;
                        break;
                    case o.FileTime:
                        u = function(e, t = 0) {
                            e = new Uint8Array(e);
                            var r = 0;
                            for (let n = 7; n >= 0; n--) r = 256 * r + e[t + n];
                            return Math.floor(r / 1e4) - 116444736e5
                        }(e, r), r += 8;
                        break;
                    case o.Char:
                        u = n(e, r, t.propLength), t.propLength && (r += t.propLength);
                        break;
                    case o.Wchar:
                        u = function(e, t = 0, r = 0) {
                            if (!e) return "";
                            e = new DataView(e);
                            var n = "";
                            for (let a = t, o = t + r; a < o && 0 !== (t = e.getUint16(a, !0)); a += 2) n += String.fromCharCode(t);
                            return n
                        }(e, r, t.propLength), (null == t ? void 0 : t.propLength) && (r += t.propLength);
                        break;
                    case o.Buffer:
                        if (t.propLength || t.propLengthType) {
                            if (t.propLengthType) switch (t.propLengthType) {
                                case o.Uint8:
                                    t.propLength = i.getUint8(r), r += 1;
                                    break;
                                case o.Uint16:
                                    t.propLength = i.getUint16(r, !0), r += 2;
                                    break;
                                case o.Uint32:
                                    t.propLength = i.getUint32(r, !0), r += 4
                            }
                            if (!t.propLength) return;
                            u = e.slice(r, r + t.propLength), t.parser && u instanceof ArrayBuffer && (u = t.parser(u)), r += t.propLength
                        }
                        break;
                    case o.Int64:
                        u = i.getBigInt64(r, !0), r += 8;
                        break;
                    case o.Uint64:
                        u = i.getBigUint64(r, !0), r += 8
                }
                a[s] = u
            }
        }), a
    }, e.serialize = function(e) {
        if (!e.length) return null;
        var n = new ArrayBuffer(a(e.map(e => ({
                propType: e[0],
                propValue: e[1],
                propLength: e[2],
                propLengthType: e[3]
            })))),
            i = new Uint8Array(n),
            s = new DataView(n),
            u = 0;
        return e.forEach(e => {
            var a;
            switch (e[0]) {
                case o.Int8:
                    if ("number" != typeof e[1]) {
                        var c = t(typeof e[1], "number");
                        throw Error(c)
                    }
                    s.setInt8(u, e[1]), u += 1;
                    break;
                case o.Int16:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    s.setInt16(u, e[1], !0), u += 2;
                    break;
                case o.Int32:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    s.setInt32(u, e[1], !0), u += 4;
                    break;
                case o.Int64:
                    if ("bigint" != typeof e[1]) throw c = t(typeof e[1], "bigint"), Error(c);
                    s.setBigInt64(u, e[1], !0), u += 8;
                    break;
                case o.Uint8:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    s.setUint8(u, e[1]), u += 1;
                    break;
                case o.Uint16:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    s.setUint16(u, e[1], !0), u += 2;
                    break;
                case o.Uint32:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    s.setUint32(u, e[1], !0), u += 4;
                    break;
                case o.Uint64:
                    if ("bigint" != typeof e[1]) throw c = t(typeof e[1], "bigint"), Error(c);
                    s.setBigUint64(u, e[1], !0), u += 8;
                    break;
                case o.Float32:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    s.setFloat32(u, e[1], !0), u += 4;
                    break;
                case o.Float64:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    s.setFloat64(u, e[1], !0), u += 8;
                    break;
                case o.FileTime:
                    if ("number" != typeof e[1]) throw c = t(typeof e[1], "number"), Error(c);
                    c = u;
                    var l = e[1];
                    if (n) {
                        e = new DataView(n), l = 1e4 * (l + 116444736e5);
                        for (let t = 0; t < 8; t++) e.setInt8(c + t, l % 256), l /= 256
                    }
                    u += 8;
                    break;
                case o.Char:
                    if ("string" != typeof e[1]) throw c = t(typeof e[1], "string"), Error(c);
                    r(n, e[1], u), u += e[2] || e[1].length;
                    break;
                case o.Wchar:
                    if ("string" != typeof e[1]) throw c = t(typeof e[1], "string"), Error(c);
                    (function(e, t = "", r = 0) {
                        if (e) {
                            e = new DataView(e);
                            for (let n = 0, a = t.length; n < a; n++) e.setInt16(r, t.charCodeAt(n), !0), r += 2
                        }
                    })(n, e[1], u), u += e[2] || 2 * e[1].length;
                    break;
                case o.Buffer:
                    if ((null == (a = e[1]) ? void 0 : a.constructor) !== ArrayBuffer) throw c = t(typeof e[1], "ArrayBuffer"), Error(c);
                    i.set(new Uint8Array(e[1]), u), u += e[1].byteLength
            }
        }), n
    }, e.setCharString = r, e.toHex = function(e) {
        return [...new Uint8Array(e)].map(e => e.toString(16).padStart(2, "0")).join("")
    }, e
}({});
const xe = _e.PROP_TYPES,
    je = _e.concat,
    Fe = _e.getCharString,
    Ne = _e.getSeriesSize,
    Le = _e.getString16,
    Pe = _e.parse,
    ze = _e.serialize,
    Be = _e.setCharString,
    Re = _e.toHex,
    He = Object.freeze(Object.defineProperty({
        __proto__: null,
        PROP_TYPES: xe,
        concat: je,
        getCharString: Fe,
        getSeriesSize: Ne,
        getString16: Le,
        parse: Pe,
        serialize: ze,
        setCharString: Be,
        toHex: Re
    }, Symbol.toStringTag, {
        value: "Module"
    }));

function Ve(e) {
    const t = String(e);
    return t.includes("e") || t.includes("E") ? e.toLocaleString("en-US", {
        useGrouping: !1,
        maximumFractionDigits: 20
    }) : t
}
export {
    Ce as A, p as B, K as C, ne as D, y as E, S as F, Y as G, u as H, He as I, k as J, j as K, v as L, Ie as M, Ve as N, re as O, c as Q, H as S, I as a, P as b, z as c, x as d, _ as e, B as f, F as g, C as h, b as i, d as j, te as k, V as l, ae as m, A as n, U as o, oe as p, se as q, ue as r, J as s, T as t, X as u, pe as v, m as w, le as x, de as y, be as z
};