import {
    I as t,
    J as i,
    K as s,
    F as e,
    L as r,
    M as a
} from "./B-oVtWMG.js";
import {
    _ as h
} from "./CahYohgC.js";
import "./D0-zyANt.js";
import "./RGIp_GAm.js";
const n = function(i, s, e, r, a, h, n, o) {
    function l(t, i) {
        if ((t = t.toString()).length <= i) return s.normalize(parseFloat(`0.${t.padStart(i,"0")}`), i);
        var e = t.length - i;
        return s.normalize(parseFloat(`${t.substring(0,e)}.${t.substring(e)}`), i)
    }

    function c(t) {
        var i = new DataView(t);
        return {
            Nm: i.getUint16(2, !0),
            Dd: i = i.getUint8(4),
            Z: t.slice(5)
        }
    }
    async function u() {
        var t = window.screen,
            i = navigator.platform,
            s = window.devicePixelRatio,
            e = navigator.language || "";
        t = t ? `${Math.max(t.width,t.height)}x${Math.min(t.width,t.height)}` : "";
        t: try {
            let t = window.localStorage.getItem("u");
            t || (t = String(Math.round(1e6 * Math.random())), window.localStorage.setItem("u", t));
            var r = t;
            break t
        } catch {
            r = "";
            break t
        }
        i = [i, s, e, t, r].join(";"), i = (new TextEncoder).encode(i), Ls = (await crypto.subtle.digest("SHA-1", i)).slice(0, 16)
    }

    function p(t, i) {
        if (!t) return 2007;
        if (t.length < i) return 2e3;
        var s = i = 0,
            e = 0,
            r = 0;
        for (let h = 0; h < t.length; h++) {
            var a = t[h];
            let n = Number(/\d/gm.test(a[0])),
                o = Number(!/\d/gm.test(a[0]) && a[0].toUpperCase() === a[0]);
            a = Number(!/\d/gm.test(a[0]) && a[0].toLowerCase() === a[0]);
            let l = Number(o && a || !n && !o && !a);
            if (o && a && (a = o = 0), r += l, s += o, e += a, (i += n) && s && e && r) return 0
        }
        return e && s && i && r ? 0 : 2001
    }

    function m(t, i = 0) {
        return function(t, i = 0) {
            return {
                Pa: (t = Hi.parse(t, fe, i))[0],
                Ia: t[1],
                Cb: t[2],
                ac: t[3],
                mf: t[4],
                $h: t[5],
                ia: t[6],
                Qa: t[7],
                Pb: t[8],
                bb: t[9],
                fi: t[10],
                ze: t[11],
                bi: t[12],
                lf: t[13],
                di: t[14],
                ci: t[15],
                wb: t[16],
                ai: t[17],
                ei: t[18],
                Zh: t[19],
                De: t[20],
                Ld: t[21],
                Md: t[22],
                Ce: t[23],
                fe: t[24],
                S: t[25],
                P: t[26],
                Lb: t[27],
                Mb: t[28],
                Oa: t[29],
                yc: t[30],
                Za: t[31],
                Hd: t[32],
                hg: t[33],
                ig: t[34],
                re: t[35],
                ke: t[36],
                zd: t[37],
                qe: t[38]
            }
        }(t, i)
    }

    function f(t) {
        return new Float64Array(t)
    }

    function d(t, i = 0) {
        return (t = Hi.parse(t, ze, i))[24] || (t[24] = 8), t
    }

    function b(t, i = 0) {
        var s = new DataView(t);
        i = [...d(t, i)];
        var e = We,
            r = [];
        if (t.byteLength > e) {
            var a = s.getUint32(e, !0);
            if (a) {
                e += 4;
                for (var h = 0; h < a; h++) r.push(m(t, e)), e += de
            }
        }
        a = Zs.NONE, t.byteLength > e && (h = s.getInt32(e, !0), Number.isSafeInteger(h) && 0 === (h & ~Qs) && (a = h), e += 4), h = 0, t.byteLength > e && (h = s.getInt32(e, !0), e += 4);
        var n = 0n;
        t.byteLength > e && (n = s.getBigUint64(e, !0), e += 8), s = {
            fa: e
        };
        var o = new DataView(t);
        if (e = [], t.byteLength > s.fa) {
            var l = o.getInt32(s.fa, !0);
            s.fa += 4;
            for (var c = 0; c < l; c++) {
                var u = Hi.parse(t, ve, s.fa);
                s.fa += ke, o = t;
                var p = s,
                    f = u[4],
                    b = [];
                if (o.byteLength > p.fa)
                    for (var g = 0; g < f; g++) {
                        var y = Hi.parse(o, Me, p.fa);
                        p.fa += Te, b.push(y)
                    }
                e.push([...u, b])
            }
        }
        if (p = new DataView(t), o = [], t.byteLength > s.fa)
            for (f = p.getUint32(s.fa, !0), s.fa += 4, l = 0; l < f; l++) {
                if (c = Hi.parse(t, be, s.fa), s.fa += ge, p = t, u = [], b = new DataView(p), p.byteLength > s.fa)
                    for (b = b.getUint32(s.fa, !0), s.fa += 4, g = 0; g < b; g++) y = Hi.parse(p, ye, s.fa), s.fa += we, u.push(y);
                o.push([...c, u])
            }
        return [...i, r, a, h, n, e, o]
    }

    function g(t, i = 0) {
        return {
            aj: Hi.parse(t, Ke, i)[0]
        }
    }

    function y(t, i) {
        return 4 + new DataView(t).getUint32(i, !0) * or
    }

    function w(t, i, s = 0) {
        return i = Hi.parse(i, nr, s), new hr(t, i)
    }

    function v(t, i, s = 0) {
        var e = [],
            r = new DataView(i).getUint32(s, !0);
        s += 4;
        for (let a = 0; a < r; a++) e.push(w(t, i, s)), s += or;
        return e
    }

    function k(t, i = 0) {
        return t = Hi.parse(t, lr, i), new ar(t)
    }

    function M(t) {
        for (var i = [], s = new DataView(t), e = t.byteLength, r = 0; r < e;) {
            r += 4;
            let e = s.getUint32(r, !0);
            r += 4;
            for (let s = 0; s < e; s++) {
                let s = k(t, r);
                r += cr, 0 !== s.Mc && (s.ce = v(s, t, r), r += y(t, r), s.de = v(s, t, r), r += y(t, r), i.push(s))
            }
        }
        return i
    }

    function T(t) {
        return Uint32Array.from([t.length, ...t]).buffer
    }

    function z(t, i) {
        return t.h > i.h ? 1 : t.h < i.h ? -1 : t.Mc > i.Mc ? 1 : t.Mc < i.Mc ? -1 : 0
    }

    function W(t) {
        return 0 === t || 5 === t
    }

    function S(t, i) {
        return t.ta > i.ta ? 1 : t.ta < i.ta ? -1 : 0
    }

    function j(t, i) {
        return t.h > i.h ? 1 : t.h < i.h ? -1 : 0
    }

    function B(t, i) {
        i.forEach(i => {
            L(i.Pa, t.trade.Pa) && $(i, t)
        })
    }

    function $(t, i) {
        if (i.Qm(), i = i.trade) {
            t.Ia !== h.INT32_MAX && (i.Ia = t.Ia), t.Cb !== h.INT32_MAX && (i.Cb = t.Cb), t.ac < h.UINT32_MAX && (i.ac = t.ac), t.mf < h.INT32_MAX && (i.mf = t.mf), t.$h < h.INT32_MAX && (i.$h = t.$h), t.ia < h.UINT32_MAX && (i.ia = t.ia), t.Qa !== h.UINT32_MAX && (i.Qa = t.Qa), t.Pb !== h.UINT32_MAX && (i.Pb = t.Pb), t.bb !== h.UINT32_MAX && (i.bb = t.bb), t.fi !== h.UINT32_MAX && (i.fi = t.fi), t.ze !== h.UINT32_MAX && (i.ze = t.ze), t.bi !== h.UINT32_MAX && (i.bi = t.bi), t.lf !== h.UINT32_MAX && (i.lf = t.lf), t.di !== h.UINT32_MAX && (i.di = t.di), t.ci !== h.UINT32_MAX && (i.ci = t.ci), t.wb && t.wb !== h.INT64_MAX_UNSIGNED && (i.wb = t.wb), t.ai !== h.UINT32_MAX && (i.ai = t.ai), t.ei !== h.UINT32_MAX && (i.ei = t.ei), t.Zh !== h.UINT32_MAX && (i.Zh = t.Zh), t.De && t.De !== h.INT64_MAX_UNSIGNED && (i.De = t.De), t.Ld && t.Ld !== h.INT64_MAX_UNSIGNED && (i.Ld = t.Ld), t.Md && t.Md !== h.INT64_MAX_UNSIGNED && (i.Md = t.Md), t.Ce && t.Ce !== h.INT64_MAX_UNSIGNED && (i.Ce = t.Ce), t.fe !== h.UINT32_MAX && (i.fe = t.fe), t.S !== h.FLOAT64_MAX && (i.S = t.S), t.P !== h.FLOAT64_MAX && (i.P = t.P);
            for (var s = 0; s < t.Lb.length; s++) t.Lb[s] !== h.FLOAT64_MAX && (i.Lb[s] = t.Lb[s]);
            for (s = 0; s < t.Mb.length; s++) t.Mb[s] !== h.FLOAT64_MAX && (i.Mb[s] = t.Mb[s]);
            for (s = 0; s < t.qe.length; s++) t.qe[s] !== h.FLOAT64_MAX && (i.qe[s] = t.qe[s]);
            t.Oa !== h.FLOAT64_MAX && (i.Oa = t.Oa), t.yc !== h.FLOAT64_MAX && (i.yc = t.yc), t.Za !== h.FLOAT64_MAX && (i.Za = t.Za), t.Hd < h.UINT32_MAX && (i.Hd = t.Hd), t.hg !== h.FLOAT64_MAX && (i.hg = t.hg), t.ig !== h.FLOAT64_MAX && (i.ig = t.ig), t.re !== h.INT32_MAX && (i.re = t.re), t.ke < h.UINT32_MAX && (i.ke = t.ke), t.zd !== h.UINT32_MAX && (i.zd = t.zd)
        }
    }

    function L(t, i) {
        if (!t || !i) return !1;
        var s = !1;
        if ((t = t.split(",").map(t => t.trim())).length)
            for (let e = 0; e < t.length; e++) {
                let r = t[e];
                if ("!" === r.charAt(0) && N(r, i)) return !1;
                N(r, i) && (s = !0)
            }
        return s
    }

    function N(t, i) {
        if (!t || !i) return !1;
        for (;
            "!" === t[0];) t = t.substring(1);
        for (var s = !1, e = "", r = ""; t && "*" === t[0];) s = !0, e = t, t = t.substring(1);
        for (; i.length && t.length;) {
            if (i[0] !== t[0]) {
                if (!s) return !1
            } else {
                for (; t.length && i.length;) {
                    if ("*" === t[0]) {
                        r = `_${i}`;
                        break
                    }
                    if (i[0] !== t[0]) {
                        if (!s) return !1;
                        t = e;
                        break
                    }
                    r || (r = i), t = t.substring(1), i = i.substring(1)
                }
                if (!t.length && !i.length) return !0;
                if (!t.length) {
                    if (!s) return !1;
                    t = e
                }
                if (!i.length) {
                    if (t.length && "*" !== t[0]) return !1;
                    for (; t.length && "*" === t[0];) t = t.substring(1);
                    return 0 === t.length
                }
                for (; t.length && "*" === t[0];) e = t, t = t.substring(1);
                if (!t.length) return !0;
                s = !0, i = r, r = ""
            }
            i = i.substring(1)
        }
        return !t.length
    }

    function I(t) {
        return l(t, 8)
    }

    function A(t, i) {
        return s.normalize(I(t) * i, 8)
    }

    function C(t) {
        return t = s.normalize(t, 8).toFixed(8).split(".").join(""), BigInt(t)
    }

    function E(t, i = !0) {
        return i && t >= 1e6 ? (t = s.normalize(t / 1e6, 14).toFixed(14), (t = r.trimZeros(t, 12)) + "M") : i && t >= 1e3 ? (t = s.normalize(t / 1e3, 11).toFixed(11), (t = r.trimZeros(t, 9)) + "K") : (t = s.normalize(t, 8).toFixed(8), r.trimZeros(t, 6))
    }

    function D(t, i = !0) {
        return E(I(t), i)
    }

    function O(t = 0, i = 0, e = 0) {
        return t = s.normalize(t, i + e).toFixed(i + e), r.trimZeros(t, e)
    }

    function x(t, i) {
        return t = s.normalize(t, i).toFixed(i), r.trimZeros(t, i)
    }

    function F(t, i = !1, s = !1, e = !0) {
        if (!t) return "";
        var r = "" + (t = new Date(t)).getUTCFullYear();
        return r = (r = r + "." + (t.getUTCMonth() + 1).toString().padStart(2, "0")) + "." + t.getUTCDate().toString().padStart(2, "0"), i && (r = (r = r + " " + t.getUTCHours().toString().padStart(2, "0")) + ":" + t.getUTCMinutes().toString().padStart(2, "0"), e && (r = r + ":" + t.getUTCSeconds().toString().padStart(2, "0"), s && (r += t.getUTCMilliseconds().toString().padStart(3, "0")))), r
    }

    function U(t, i = 0) {
        return Hi.parse(t, sa, i)
    }

    function P(t) {
        var i = [],
            s = new DataView(t).getUint32(0, !0),
            e = 4;
        for (let r = 0; r < s; r++) i.push(U(t, e)), e += ea;
        return i
    }

    function q(t, i = 0) {
        return function(t, i = 0) {
            return Hi.parse(t, ra, i)
        }(t, i)
    }

    function _(t, i = 0) {
        return Hi.parse(t, la, i)
    }

    function X(t, i = 0) {
        return {
            ta: (t = Hi.parse(t, ya, i))[0],
            fields: t[1],
            Mf: 1e3 * t[2],
            i: t[3],
            yb: t[4],
            Wc: t[5],
            Xc: t[6],
            fc: t[7],
            Uc: t[8],
            Vc: t[9],
            nb: t[10],
            Kf: t[11],
            Lf: t[12],
            Qb: t[13],
            sg: t[14],
            tg: t[15],
            Mj: t[16],
            l: t[17],
            Oj: t[18],
            Nj: t[19],
            kg: t[20],
            lg: t[21],
            mg: t[22],
            ng: t[23],
            sa: t[24],
            D: t[25],
            Ch: t[26],
            yj: t[27],
            Lh: t[28],
            Kh: t[29],
            lj: t[30],
            Dh: t[31],
            Hh: t[32],
            Eh: t[33],
            Ih: t[34],
            Gh: t[35],
            Fh: t[36],
            Jh: t[37],
            flags: t[38]
        }
    }

    function R(t, i = 0) {
        return {
            ta: (t = Hi.parse(t, za, i))[0],
            Oc: 1e3 * t[1],
            fields: t[2],
            O: t[3],
            L: t[4],
            Na: t[5],
            mn: t[6],
            Vn: t[7],
            flags: t[8],
            ib: 1e3 * t[1] + t[7]
        }
    }

    function V(t, i, e) {
        var r = t;
        return i && (r = s.normalize(t / i, 0) * i), s.normalize(r, e)
    }

    function H(t, i, e, r, a, h) {
        return t && a && h ? (h = s.normalize((h - a) / e + t, 0), {
            O: a = t > 0 ? s.normalize(a - e * (t - Math.trunc(t / 2) - i), r) : s.normalize(a - e * (t - Math.trunc(t / 2) + i), r),
            L: h = s.normalize(a + e * h, r),
            result: a <= h
        }) : {
            result: !0,
            O: a,
            L: h
        }
    }

    function G(t, i, e, r, a) {
        return t > 0 ? s.normalize(a - e * (t - Math.trunc(t / 2) - i), r) : s.normalize(a - e * (t - Math.trunc(t / 2) + i), r)
    }

    function J(t, i, e, r, a) {
        return t > 0 ? s.normalize(a + e * (Math.trunc(t / 2) + i), r) : s.normalize(a + e * (Math.trunc(t / 2) - i), r)
    }

    function K(t, i, s) {
        return s ? t | i : t & ~i
    }

    function Y(t, i) {
        t: {
            var e = i.D;
            if (t.$g() && t.Ja && (e = t.Ja), e) {
                if (0 === t.jb && void 0 !== i.hd && void 0 !== i.yb) {
                    t = s.normalize((i.yb - e) / e * 100, 2);
                    break t
                }
                if (1 === t.jb && void 0 !== i.Na) {
                    t = s.normalize((i.nb - e) / e * 100, 2);
                    break t
                }
            }
            t = void 0
        }
        i.yj = t,
        e = 2,
        void 0 !== t && (t > 0 ? e = 0 : t < 0 && (e = 1)),
        i.$(BigInt(8388608), e)
    }

    function Z(t = 0, i = 0) {
        return t === i ? 2 : t >= i ? 0 : 1
    }

    function Q(t = 0n, i = 0n) {
        return i === t ? 2 : t >= i ? 0 : 1
    }

    function tt(t, i) {
        switch (t.jl(i)) {
            case 1:
                return -1;
            case 0:
                return 1
        }
        return 0
    }

    function it(t, i, s) {
        return Math.abs(t - i) < 10 ** -(s + 1) ? 0 : t > i ? 1 : -1
    }

    function st(t, i, e, r, a, n) {
        for (var o = e, l = 0; i.ub < t.ab.length;) {
            let c = t.ab[i.ub];
            if (c.Cd === h.FLOAT64_MAX || c.Bd === h.FLOAT64_MAX) break;
            let u = c.Cd - c.Bd;
            if (u > 0) {
                if (i.Rb && (u = Math.min(i.Rb, u)), o < u ? (i.Rb = u - o, u = o) : i.Rb = 0, l = s.normalize(l + u / e * r * (a ? c.Ye : c.Ze), n), u >= o) {
                    o = 0, i.Rb || (i.ub += 1);
                    break
                }
                o -= u
            }
            i.ub += 1
        }
        return o && (l = s.normalize(l + o / e * r * (a ? t.ab[t.ab.length - 1].Ye : t.ab[t.ab.length - 1].Ze), n)), l
    }

    function et(t, i, s, e, r) {
        s = i = 0;
        var [a] = e.Vl(t);
        return a && (i = a.Na, s = a.L), i || (i = r), i || "_TOD" !== t.substring(t.length - 4) || ([t] = e.Ef(`${t.substring(0,t.length-4)}_TOM`), t && (i = t.Na, s = t.L)), s || (s = i), [i, s]
    }

    function rt(t) {
        return [0, 4, 2, 6].includes(t)
    }

    function at(t) {
        return [1, 3, 5, 7].includes(t)
    }

    function ht(t) {
        return [0, 1].includes(t)
    }

    function nt(t) {
        return [4, 5, 2, 3, 6, 7].includes(t)
    }

    function ot(t) {
        return 2 === t || 3 === t
    }

    function lt(t) {
        return 4 === t || 5 === t
    }

    function ct(t) {
        return 6 === t || 7 === t
    }

    function ut(t) {
        return ot(t) || ct(t)
    }

    function pt(t) {
        switch (t) {
            case 0:
                return "buy";
            case 1:
                return "sell";
            case 2:
                return "buy limit";
            case 3:
                return "sell limit";
            case 4:
                return "buy stop";
            case 5:
                return "sell stop";
            case 6:
                return "buy stop limit";
            case 7:
                return "sell stop limit";
            case 8:
                return "close by";
            default:
                return "unknown"
        }
    }

    function mt(t, i, e, r, a, h, n) {
        switch (h ? h = t.trade.S : (h = t.trade.S, t.trade.P && (h = t.trade.P)), t.ga) {
            case 0:
                return h > 0 ? h * r / t.I / i : r / i;
            case 5:
                return h > 0 ? h * r / t.I : r;
            case 1:
            case 33:
                return h * r / t.I;
            case 3:
                return h > 0 ? h * r / t.I : t.N ? r * a / t.N * t.va : 0;
            case 64:
            default:
                return 0;
            case 4:
                return h > 0 ? h * r / t.I / i : r * a / i;
            case 2:
            case 32:
            case 38:
            case 35:
            case 36:
                return h > 0 ? h * r / t.I : r * a;
            case 34:
                if (t.N) switch (e) {
                    case 0:
                        i = t.I, e = t.Ja, h = t.va;
                        var o = t.N,
                            l = t.trade,
                            c = l.S;
                        return l = l.Za, n ? r / i * (c + h / o * (a - e) * (1 + .01 * l)) : r / i * (c + h / o * (t.bc - e) * (1 + .01 * l));
                    case 1:
                        return i = t.I, e = t.Ja, h = t.va, o = t.N, c = (l = t.trade).Za, l = l.P, n ? r / i * (l + h / o * (e - a) * (1 + .01 * c)) : r / i * (l + h / o * (e - t.cc) * (1 + .01 * c));
                    case 2:
                    case 6:
                        return n = t.trade, r / t.I * (n.S + t.va / t.N * (a - t.Ja) * (1 + .01 * n.Za));
                    case 3:
                    case 7:
                        return n = t.trade, r / t.I * (n.P + t.va / t.N * (t.Ja - a) * (1 + .01 * n.Za));
                    case 4:
                        return a = t.trade, r / t.I * (a.S + t.va / t.N * (t.bc - t.Ja) * (1 + .01 * a.Za));
                    case 5:
                        return a = t.trade, r / t.I * (a.P + t.va / t.N * (t.Ja - t.cc) * (1 + .01 * a.Za));
                    default:
                        return h * r / t.I
                }
                return 0;
            case 37:
            case 39:
                return h > 0 ? h * r / t.I : s.normalize(r * t.Ka * a / 100, t.Ha)
        }
    }

    function ft(t) {
        switch (t) {
            case 0:
                return "buy";
            case 1:
                return "sell";
            case 2:
                return "balance";
            case 3:
                return "credit";
            case 4:
                return "charge";
            case 5:
                return "correction";
            case 6:
                return "bonus";
            case 7:
                return "commission";
            case 8:
                return "daily commission";
            case 9:
                return "monthly commission";
            case 10:
                return "daily agent commission";
            case 11:
                return "monthly agent commission";
            case 12:
                return "interest rate";
            case 13:
                return "canceled buy";
            case 14:
                return "canceled sell";
            case 15:
                return "dividend";
            case 16:
                return "franked dividend";
            case 17:
                return "tax";
            default:
                return ""
        }
    }

    function dt(t) {
        return "number" == typeof t && [2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 15, 16, 17, 18].includes(t)
    }

    function bt(t) {
        return "number" == typeof t && [2, 3, 4, 5, 6, 7, 15, 16, 17, 18].includes(t)
    }

    function gt(t, i) {
        var s = Number(t.volume + i.volume);
        return [(t.price * Number(t.volume) + i.price * Number(i.volume)) / s, (t.G * Number(t.volume) + i.G * Number(i.volume)) / s]
    }

    function yt(t) {
        t.volume && (t.price /= Number(t.volume), t.G /= Number(t.volume))
    }

    function wt(t, i, e, r, a, h, n) {
        switch (h ? h = t.trade.S : (h = t.trade.S, t.trade.P && (h = t.trade.P)), t.ga) {
            case 0:
                return h > 0 ? h * r / t.I / i.zc : r / i.zc;
            case 5:
                return h > 0 ? h * r / t.I : r;
            case 1:
            case 33:
                return h * r / t.I;
            case 3:
                return h > 0 ? h * r / t.I : t.N ? r * a / t.N * t.va : 0;
            case 64:
            default:
                return 0;
            case 4:
                return h > 0 ? h * r / t.I / i.zc : r * a / i.zc;
            case 2:
            case 32:
            case 38:
            case 35:
            case 36:
                return h > 0 ? h * r / t.I : r * a;
            case 34:
                if (t.N) switch (e) {
                    case 0:
                        return n ? r / t.I * (t.trade.S + t.va / t.N * (a - t.Ja) * (1 + .01 * t.trade.Za)) : r / t.I * (t.trade.S + t.va / t.N * (t.bc - t.Ja) * (1 + .01 * t.trade.Za));
                    case 1:
                        return n ? r / t.I * (t.trade.P + t.va / t.N * (t.Ja - a) * (1 + .01 * t.trade.Za)) : r / t.I * (t.trade.P + t.va / t.N * (t.Ja - t.cc) * (1 + .01 * t.trade.Za));
                    case 2:
                    case 6:
                        return r / t.I * (t.trade.S + t.va / t.N * (a - t.Ja) * (1 + .01 * t.trade.Za));
                    case 3:
                    case 7:
                        return r / t.I * (t.trade.P + t.va / t.N * (t.Ja - a) * (1 + .01 * t.trade.Za));
                    case 4:
                        return r / t.I * (t.trade.S + t.va / t.N * (t.bc - t.Ja) * (1 + .01 * t.trade.Za));
                    case 5:
                        return r / t.I * (t.trade.P + t.va / t.N * (t.Ja - t.cc) * (1 + .01 * t.trade.Za));
                    default:
                        return h * r / t.I
                }
                return 0;
            case 37:
            case 39:
                return h > 0 ? h * r / t.I : s.normalize(r * t.Ka * a / 100, t.Ha)
        }
    }

    function vt(t, i) {
        i.length = 0, t.wc((t, s) => {
            i[s] = t.el()
        })
    }

    function kt(t, i, s, e) {
        if (e.ed = Number.MAX_VALUE, !i.Ve() && !s.length) return !0;
        var r;
        for (r = 0; r < s.length; r++) {
            let n = s[r];
            var a = !1;
            let o = i.Qi();
            for (let i = 0; i < o.length; i++) {
                let s = o[i];
                if (n.Hi(s.getName(), s.Tb(), s.symbol.ua) && (s.Nh(n), n.Sh && (a = s.Xd() / BigInt(n.Sh), e.ed = Number(h.bMath.min(BigInt(e.ed), a))), a = !0, t.xd !== er.pi || n.me !== rr.rf)) break
            }
            if (!a) break
        }
        return !(r < s.length && (i.wc(t => t.Nh()), 1))
    }

    function Mt(t, i = jh.Ie) {
        switch (i) {
            case jh.ti:
                return t.volume;
            case jh.ui:
                return t.volumePerSymbol;
            case jh.si:
                return t.valuePerSymbol;
            default:
                return t.value
        }
    }

    function Tt(t) {
        switch (t) {
            case wc.zg:
                return vc.zg;
            case wc.Cg:
                return vc.Cg;
            case wc.Ag:
                return vc.Ag;
            case wc.Bg:
                return vc.Bg;
            case wc.xg:
                return vc.xg;
            case wc.yg:
                return vc.yg;
            case wc.wg:
                return vc.wg;
            case wc.Eg:
                return vc.Eg;
            case wc.ck:
                return vc.ek;
            default:
                return 0
        }
    }

    function zt(t, i) {
        return (t = t.B.toString()) > (i = i.B.toString()) ? 1 : t < i ? -1 : 0
    }

    function Wt(t, i) {
        return (t = t.H.toString()) > (i = i.H.toString()) ? 1 : t < i ? -1 : 0
    }

    function St(t, i) {
        if (t.H.toString() > i.H.toString()) return 1;
        if (t.H.toString() < i.H.toString()) return -1;
        if (dt(t.u) !== dt(i.u)) {
            if (t.u > i.u) return 1;
            if (t.u < i.u) return -1
        }
        return 0
    }

    function jt(t, i) {
        return t.Ca > i.Ca ? 1 : t.Ca < i.Ca ? -1 : 0
    }

    function Bt(t, i) {
        return t.wa > i.wa ? 1 : t.wa < i.wa ? -1 : 0
    }

    function $t(t, i = 0) {
        return (t = Hi.parse(t, Jc, i))[3] = 1e3 * t[3] + t[28], t[4] *= 1e3, t[5] = 1e3 * t[5] + t[29], (i = new Kl).B = t[0], i.yd = t[1], i.h = t[2], i.kf = t[3], i.ua = t[4], i.jg = t[5], i.T = t[6], i.ea = t[7], i.ya = t[8], i.Pc = t[9], i.m = t[10], i.K = t[11], i.Nb = t[12], i.v = t[13], i.A = t[14], i.Ra = t[15], i.J = t[16], i.rc = t[17], i.eb = t[18], i.H = t[19], i.comment = t[20], i.U = t[21], i.i = t[22], i.ca = t[23], i.ma = t[24], i.na = t[25], i.G = t[26], i.mb = t[27], i
    }

    function Lt(t, i = 0) {
        var s = [],
            e = new DataView(t).getUint32(i, !0);
        i += 4;
        for (let r = 0; r < e; r++) s.push($t(t, i)), i += Kc;
        return s
    }

    function Nt(t, i = 0) {
        return t = Hi.parse(t, Yc, i), new $c({
            wa: t[0],
            Hb: t[1],
            B: t[2],
            Ca: 1e3 * t[3] + t[25],
            dd: 1e3 * t[4] + t[26],
            h: t[5],
            o: t[6],
            entry: t[7],
            sa: t[8],
            D: t[9],
            ka: t[10],
            la: t[11],
            l: t[12],
            profit: t[13],
            tb: t[14],
            gb: t[15],
            commission: t[16],
            M: t[17],
            eb: t[18],
            H: t[19],
            comment: t[20],
            U: t[21],
            i: t[22],
            ca: t[23],
            Eb: t[24],
            La: t[27]
        })
    }

    function It(t, i = 0) {
        return new DataView(t).getUint32(i, !0) * Zc + 4
    }

    function At(t, i = 0) {
        var s = [],
            e = new DataView(t).getUint32(i, !0);
        i += 4;
        for (let r = 0; r < e; r++) s.push(Nt(t, i)), i += Zc;
        return s
    }

    function Ct(t) {
        return t.H ? t.H.toString() : ""
    }

    function Et(t, i) {
        var s = D(t.l);
        return Dt(t, i)(s)
    }

    function Dt(t, i) {
        var s = "",
            e = "";
        return i && (s += `#${i} `), s += ft(t.o), e += `${t.h} ${O(t.sa,t.i,3)}`, t => `${s} ${t} ${e}`
    }

    function Ot(t) {
        return Et(t, Ct(t) || t.Hb)
    }

    function xt(t) {
        switch (t) {
            case 0:
            case 0:
                return "buy";
            case 1:
            case 1:
                return "sell";
            default:
                return "unknown"
        }
    }

    function Ft(t, i = !0) {
        var s = "",
            e = t.Ra,
            r = t.J;
        return i ? e >= r ? s += `${D(e)} / ${D(e-r)}` : s = (s += D(e)) + " / " + D(r) : (t = t.U, e = h.multiplyFloat(e, t), r = h.multiplyFloat(r, t), s = (s += D(e)) + " / " + D(e - r)), s
    }

    function Ut(t, i = !0) {
        var s = "",
            e = t.B.toString();
        return e && (s += `#${e} `), s += pt(t.T), s = t.Ra === t.J ? s + ` ${D(t.Ra)}` : s + ` ${Ft(t)}`, i && (s += ` ${t.h}`), s
    }

    function Pt(t, i) {
        t: switch (t.ga) {
            case 32:
            case 33:
            case 34:
            case 35:
            case 36:
            case 37:
            case 38:
            case 39:
                t = !0;
                break t;
            default:
                t = !1
        }
        return t ? {
            O: i.nb,
            L: i.nb
        } : {
            O: i.O,
            L: i.L
        }
    }

    function qt(t, i, e, r, a, h = !1) {
        if (e.$d() && t.Al()) {
            var n = A(i.l, i.U);
            h = s.normalize(i.sa * n * i.gb, t.zb), i.isBuy() ? (i.tb = a, t = s.normalize(i.D * n * a, t.zb), i.profit = s.normalize(t - h, e.j)) : (i.tb = r, t = s.normalize(i.D * n * r, t.zb), i.profit = s.normalize(h - t, e.j))
        } else t.Hc() ? (n = A(i.l, i.U), h = s.normalize(n * t.Ka * i.sa / 100 * i.gb, t.Ha), i.isBuy() ? (i.tb = a, t = s.normalize(n * t.Ka * i.D / 100 * i.gb, t.Ha), i.profit = s.normalize(t - h, e.j)) : (i.tb = r, t = s.normalize(n * t.Ka * i.D / 100 * i.gb, t.Ha), i.profit = s.normalize(h - t, e.j))) : (i.profit = function(t, i, e, r, a, h, n = !1) {
            var o = t.zb,
                l = t.va,
                c = t.N,
                u = t.Ka;
            switch (t.ga) {
                case 0:
                case 5:
                    c = A(e, r), i = i ? s.normalize(h * c, o) - s.normalize(a * c, o) : s.normalize(a * c, o) - s.normalize(h * c, o);
                    break;
                case 1:
                case 33:
                case 35:
                case 36:
                    u = I(e), i = i ? (h - a) * u * l : (a - h) * u * l, c && (i /= c);
                    break;
                case 34:
                    u = I(e), c ? (a = s.normalize(a * l / c, o), c = s.normalize(h * l / c, o)) : (a = s.normalize(a * l, o), c = s.normalize(h * l, o)), i = i ? (c - a) * u : (a - c) * u;
                    break;
                case 37:
                case 39:
                    c = A(e, r), i = i ? s.normalize(c * h * u / 100, o) - s.normalize(c * a * u / 100, o) : s.normalize(c * a * u / 100, o) - s.normalize(c * h * u / 100, o);
                    break;
                case 64:
                    n ? (c = A(e, r), i = i ? h * c - a * c : a * c - h * c) : i = 0;
                    break;
                default:
                    c = A(e, r), i = i ? h * c - a * c : a * c - h * c
            }
            return Math.abs(i) > 1e11 && (i = 0), (h < 0 || !h && !t.oa()) && (i = 0), s.normalize(i, o)
        }(t, i.isBuy(), i.l, i.U, i.sa, i.D, h), !t.Jb() || t.Db & jr.Fe ? i.profit > 0 ? (i.profit *= a, i.tb = a) : (i.profit *= r, i.tb = r) : i.isBuy() ? (i.profit *= r, i.tb = r) : (i.profit *= a, i.tb = a), i.profit = s.normalize(i.profit, e.j))
    }

    function _t(t, i = 0) {
        return t = Hi.parse(t, $u, i), new $c({
            H: t[0],
            B: t[1],
            Ca: 1e3 * t[2] + t[24],
            dd: 1e3 * t[3] + t[25],
            h: t[4],
            o: t[5],
            sa: t[6],
            D: t[7],
            ka: t[8],
            la: t[9],
            l: t[10],
            profit: t[11],
            tb: t[12],
            gb: t[13],
            commission: t[14],
            M: t[15],
            eb: t[16],
            Vd: t[17],
            comment: t[18],
            U: t[19],
            i: t[20],
            ca: t[21],
            Eb: t[22],
            Zc: t[23]
        })
    }

    function Xt(t, i = 0) {
        return new DataView(t).getUint32(i, !0) * Lu + 4
    }

    function Rt(t, i = 0) {
        var s = [],
            e = new DataView(t).getUint32(i, !0);
        i += 4;
        for (let r = 0; r < e; r++) s.push(_t(t, i)), i += Lu;
        return s
    }

    function Vt(t) {
        return {
            vc: t[0],
            ba: t[1],
            price: t[2],
            l: t[3]
        }
    }

    function Ht(t) {
        switch (t) {
            case 2:
                return 1;
            case 4:
                return 2;
            case 3:
                return 3;
            case 5:
                return 4;
            default:
                return 0
        }
    }

    function Gt(t) {
        return {
            i: t.i,
            Ga: t.Ga,
            Ij: t.Bc,
            uj: t.trade.zd,
            fg: t.trade.Ia,
            Fj: t.trade.Cb,
            qj: t.Ta(),
            Li: t.I
        }
    }

    function Jt(t, i) {
        return t.ba === Fu.Ge ? i.ba === Fu.fd || i.ba === Fu.Ee ? -1 : i.ba === Fu.Tc ? 1 : 0 : t.ba === Fu.Ee ? i.ba === Fu.fd ? -1 : i.ba === Fu.Tc || i.ba === Fu.Ge ? 1 : 0 : i.ba === Fu.Ge || i.ba === Fu.Ee ? t.ba === Fu.fd ? 1 : t.ba === Fu.Tc ? -1 : 0 : t.ba !== i.ba ? t.ba - i.ba : t.price > i.price ? -1 : t.price < i.price ? 1 : 0
    }

    function Kt(t, i = 0) {
        return Hi.parse(t, Mp, i)
    }

    function Yt(t = 0) {
        return t * Tp
    }

    function Zt(t, i = 0, s = 0) {
        var e = [];
        for (let r = 0; r < s; r++) e.push(Kt(t, i)), i += Tp;
        return e
    }

    function Qt(t, i = 0) {
        return Hi.parse(t, zp, i)
    }

    function ti(t, i = 0) {
        var s = Xp,
            e = 0 + s;
        return (e += s = It(t, i += s)) + Xt(t, i + s)
    }

    function ii(t, i = 0) {
        var s = function(t, i = 0) {
            return t = Hi.parse(t, _p, i), new qp(t)
        }(t, i);
        return i += Xp, s.deals = At(t, i), i += It(t, i), s.positions = Rt(t, i), Xt(t, i), s
    }

    function si(t, i = 0) {
        return t = Hi.parse(t, Vp, i), new Rp(t)
    }

    function ei(t, i) {
        if (t > 1e9 || !Number.isFinite(t) || t < 0 && !i.Ta()) i = !1;
        else {
            var e = s.normalize(t, i.i);
            e && i.N ? (t = 10 ** -(i.i + 1), i = (e = s.normalize(h.fmod(e, i.N), i.i)) <= t || e >= i.N) : i = !0
        }
        return i
    }

    function ri(t, i, s = !1) {
        if (t.trade.ia === Sr.uc || t.trade.ia === Sr.tc) return 5 === i.o || 201 === i.o ? (s && (i.ea = 2), 2 === i.ea) : (s && (i.ea = 0), 0 === i.ea);
        if (t.trade.ia === Sr.xa) return 5 === i.o || 201 === i.o ? (s && (i.ea = 2), 2 === i.ea) : 0 === i.ea ? !!(t.trade.Qa & Br.Qc) : 1 === i.ea && !!(t.trade.Qa & Br.Rc);
        switch (i.ea) {
            case 0:
                if ((5 === i.o || 201 === i.o) && 2 !== i.u && 3 !== i.u && 6 !== i.u && 7 !== i.u) {
                    if (s) return i.ya = 0, i.ea = 2, !0;
                    break
                }
                return !!(t.trade.Qa & Br.Qc);
            case 1:
                if ((5 === i.o || 201 === i.o) && 2 !== i.u && 3 !== i.u && 6 !== i.u && 7 !== i.u) {
                    if (s) return i.ya = 0, i.ea = 2, !0;
                    break
                }
                return !!(t.trade.Qa & Br.Rc);
            case 2:
                return !0;
            case 3:
                if (5 !== i.o && 201 !== i.o || 2 === i.u || 3 === i.u || 6 === i.u || 7 === i.u) return !!(t.trade.Qa & Br.nf);
                if (s) return i.ya = 0, i.ea = 2, !0
        }
        return !1
    }

    function ai(t, i) {
        return !(!(t.trade.bb & Lr.xa) && ht(i) || !(t.trade.bb & Lr.uf) && ut(i) || !(t.trade.bb & Lr.yf) && lt(i) || !(t.trade.bb & Lr.zf) && ct(i))
    }

    function hi(t, i, e, r, a, h) {
        if (!i) return 10011;
        var n = s.normalize(i.Ga * i.trade.mf, i.i);
        switch (e.u) {
            case 0:
                if (!i.Ta()) {
                    if (e.m < 0) return 10015;
                    if (e.v < 0 || e.A < 0) return 10016
                }
                if (!e.m) {
                    if (i.trade.ia === Sr.xa || i.trade.ia === Sr.Va) break;
                    return 10015
                }
                if (0 === (r = t.O)) break;
                if (t = s.normalize(r - n, i.i), e.v > 0) {
                    if (i.oa()) return 10017;
                    if (e.v !== a && e.v > t) return 10016
                }
                if (t = s.normalize(r + n, i.i), e.A > 0) {
                    if (i.oa()) return 10017;
                    if (e.A !== h && e.A < t) return 10016
                }
                break;
            case 1:
                if (e.m < 0) return 10015;
                if (e.v < 0 || e.A < 0) return 10016;
                if (!e.m) {
                    if (i.trade.ia === Sr.xa || i.trade.ia === Sr.Va) break;
                    return 10015
                }
                if (0 === (r = t.L)) break;
                if (t = s.normalize(r + n, i.i), e.v > 0) {
                    if (i.oa()) return 10017;
                    if (e.v !== a && e.v < t) return 10016
                }
                if (t = s.normalize(r - n, i.i), e.A > 0) {
                    if (i.oa()) return 10017;
                    if (e.A !== h && e.A > t) return 10016
                }
                break;
            case 2:
                if (t = t.L, !i.Ta()) {
                    if (e.m <= 0) return 10015;
                    if (e.v < 0 || e.A < 0) return 10016
                }
                if (i.trade.ia !== Sr.Va) {
                    var o = s.normalize(t - n, i.i);
                    if (0 !== t && e.m !== r && e.m > o) return 10015
                }
                if (t = s.normalize(e.m - n, i.i), e.v > 0 && (e.v !== a || r !== e.m) && e.v > t) return 10016;
                if (t = s.normalize(e.m + n, i.i), e.A > 0 && (e.A !== h || r !== e.m) && e.A < t) return 10016;
                break;
            case 3:
                if (t = t.O, !i.Ta()) {
                    if (e.m <= 0) return 10015;
                    if (e.v < 0 || e.A < 0) return 10016
                }
                if (i.trade.ia !== Sr.Va && (o = s.normalize(t + n, i.i), 0 !== t && e.m !== r && e.m < o)) return 10015;
                if (t = s.normalize(e.m + n, i.i), e.v > 0 && (e.v !== a || r !== e.m) && e.v < t) return 10016;
                if (t = s.normalize(e.m - n, i.i), e.A > 0 && (e.A !== h || r !== e.m) && e.A > t) return 10016;
                break;
            case 4:
                if (t = t.L, !i.Ta()) {
                    if (e.m <= 0) return 10015;
                    if (e.v < 0 || e.A < 0) return 10016
                }
                if (o = s.normalize(t + n, i.i), 0 !== t && e.m !== r && e.m < o) return 10015;
                if (o = s.normalize(e.m - n, i.i), e.v > 0 && (e.v !== a || r !== e.m) && e.v > o) return 10016;
                if (o = s.normalize(e.m + n, i.i), e.A > 0 && (e.A !== h || r !== e.m) && e.A < o) return 10016;
                break;
            case 5:
                if (t = t.O, !i.Ta()) {
                    if (e.m <= 0) return 10015;
                    if (e.v < 0 || e.A < 0) return 10016
                }
                if (o = s.normalize(t - n, i.i), 0 !== t && e.m !== r && e.m > o) return 10015;
                if (o = s.normalize(e.m + n, i.i), e.v > 0 && (e.v !== a || r !== e.m) && e.v < o) return 10016;
                if (o = s.normalize(e.m - n, i.i), e.A > 0 && (e.A !== h || r !== e.m) && e.A > o) return 10016;
                break;
            case 6:
                if (a = t.L, !i.Ta()) {
                    if (e.m <= 0 || e.K <= 0) return 10015;
                    if (e.v < 0 || e.A < 0) return 10016
                }
                if (h = s.normalize(a + n, i.i), 0 !== a && e.m !== r && e.m < h || i.trade.ia !== Sr.Va && (h = s.normalize(e.m - n, i.i), e.K > h)) return 10015;
                if (h = s.normalize(e.K - n, i.i), e.v > 0 && e.v > h) return 10016;
                if (h = s.normalize(e.K + n, i.i), e.A > 0 && e.A < h) return 10016;
                break;
            case 7:
                if (a = t.O, !i.Ta()) {
                    if (e.m <= 0 || e.K <= 0) return 10015;
                    if (e.v < 0 || e.A < 0) return 10016
                }
                if (h = s.normalize(a - n, i.i), 0 !== a && e.m !== r && e.m > h || i.trade.ia !== Sr.Va && (h = s.normalize(e.m + n, i.i), e.K < h)) return 10015;
                if (h = s.normalize(e.K + n, i.i), e.v > 0 && e.v < h) return 10016;
                if (h = s.normalize(e.K - n, i.i), e.A > 0 && e.A > h) return 10016
        }
        return 0
    }

    function ni(t, i) {
        return i.isBuy() && t.isBuy() || i.isSell() && t.isSell() ? Sc.oi : i.l >= t.J ? Sc.Sc : Sc.tf
    }

    function oi(t, i, s) {
        var e = new Kl;
        return e.T = t.u, e.Ra = t.l, !((t = e.J = t.l) <= 0 || ni(e, s) !== Sc.Sc && t < i.trade.De || t > i.trade.Ld || t % i.trade.Md)
    }

    function li(t, i, s) {
        var e = new Kl;
        return e.T = t.u, e.Ra = t.l, e.J = t.l,
            function(t, i, s) {
                switch (t.trade.ac) {
                    case 0:
                    default:
                        return 10017;
                    case 1:
                        return t.oa() ? 10017 : i.isBuy() || i.isSell() && ni(i, s) === Sc.Sc ? 0 : 10042;
                    case 2:
                        return t.oa() ? 10017 : i.isSell() || i.isBuy() && ni(i, s) === Sc.Sc ? 0 : 10043;
                    case 3:
                        return ni(i, s) === Sc.Sc ? 0 : 10044;
                    case 4:
                        return t.oa() ? 10017 : 0
                }
            }(i, e, s)
    }

    function ci(t) {
        return 0 === t ? "buy" : 1 === t ? "sell" : 2 === t ? "buy limit" : 3 === t ? "sell limit" : 4 === t ? "buy stop" : 5 === t ? "sell stop" : 6 === t ? "buy stop limit" : 7 === t ? "sell stop limit" : "unknown"
    }

    function ui(t, i, s, e = 0) {
        return i ? (t = "" + O(t, s, e), t += ` (${O(i,s)})`) : t ? O(t, s) : "market"
    }

    function pi(t, i) {
        switch (t) {
            case 0:
            case 1:
                return i("ok");
            case 2:
            case 10011:
                return i("common");
            case 3:
            case 4:
            case 10013:
                return i("invalidParameters");
            case 5:
            case 6:
                return i("serverProblem");
            case 7:
                return i("networkProblem");
            case 8:
                return i("permissions");
            case 9:
            case 10012:
                return i("timeout");
            case 10:
            case 10031:
                return i("noConnection");
            case 12:
                return i("frequentRequests");
            case 10001:
                return i("onTheWay");
            case 10002:
                return i("accepted");
            case 10003:
                return i("processed");
            case 10004:
                return i("requoted");
            case 10005:
                return i("prices");
            case 10006:
                return i("rejected");
            case 10007:
                return i("canceled");
            case 10008:
                return i("placed");
            case 10009:
                return i("done");
            case 10010:
            case 11001:
                return i("donePartially");
            case 10014:
                return i("invalidVolume");
            case 10015:
                return i("invalidPrices");
            case 10016:
                return i("invalidSLTP");
            case 10017:
                return i("tradeDisabled");
            case 10018:
                return i("marketClosed");
            case 10019:
                return i("notEnoughMoney");
            case 10020:
                return i("priceChanged");
            case 10021:
                return i("offQuotes");
            case 10022:
                return i("invalidExpiration");
            case 10023:
                return i("orderChanged");
            case 10024:
                return i("manyTradeRequests");
            case 10026:
                return i("automatedTradingDisabledServer");
            case 10027:
                return i("automatedTradingDisabledClient");
            case 10029:
                return i("modificationFailed");
            case 10030:
                return i("unsupportedFillingMode");
            case 10033:
                return i("ordersLimitReached");
            case 10034:
                return i("volumeLimitReached");
            case 10035:
                return i("invalidOrderType");
            case 10036:
                return i("positionClosed");
            case 1025:
                return i("demoAllocationDisabled");
            case 10039:
                return i("orderClosePositionExists");
            case 10040:
                return i("positionsLimitReached");
            case 10041:
                return i("requestRejectedOrderWillCanceled");
            case 10042:
                return i("allowedOnlyLongPositions");
            case 10043:
                return i("allowedOnlyShortPositions");
            case 10044:
                return i("allowedOnlyPositionsClosing");
            case 10045:
                return i("positionCloseProhibitedByFIFO")
        }
        return "Common error"
    }

    function mi(t) {
        return void 0 !== t && [10009, 10010, 11001, 10008].includes(t)
    }

    function fi(t, i, s, e, r, a, h, n) {
        if (!e) return "";
        var l = "",
            c = "";
        if (a.ql() && (r.isMarket() || r.isPending())) {
            var u = new Kl;
            u.B = a.B, u.T = r.u, u.i = r.i, u.m = a.price, u.v = r.v, u.A = r.A, u.h = r.h, u.Ra = a.volume, s = `#${u.B.toString()}`, s += ` ${ci(u.T)}`, s += ` ${u.J&&u.Ra===u.J?D(u.Ra):function(t=0n,i=0n){return t>=i?`${D(t)} / ${D(t-i)}`:`${D(t)} / ${D(i)}`}(u.Ra,u.J)}`, s += ` ${u.h}`, (u = ui(u.m, u.K, u.i)) && (s += ` at ${u}`), l = r.l === a.volume ? l + `${r.login}: order ${s} done` : l + `${r.login}: order ${s} done partially`
        } else u = c = null, (r.isPending() || r.tl() || r.wl()) && ((c = t.fb(r.B)) || (c = i.fb(r.B))), (r.isMarket() || 6 === r.o || 10 === r.o) && ((s = s.ha().nc()) && r.F ? u = t.Xa(r.F) : s || !(u = t.$c(r.h)) && r.F && (u = i.Pg(r.F))), c = function(t, i, s, e) {
            switch (t.o) {
                case 0:
                    return Fm.jk(t.h, D(t.l));
                case 1:
                    return Fm.uc({
                        order: i.B,
                        $a: ci(t.u),
                        volume: D(i.volume || t.l),
                        symbol: t.h,
                        price: O(i.price || t.m, t.i)
                    });
                case 2:
                    return Fm.tc({
                        order: i.B,
                        $a: ci(t.u),
                        volume: D(i.volume || t.l),
                        symbol: t.h,
                        price: O(i.price || t.m, t.i)
                    });
                case 3:
                    return i.price ? Fm.bk({
                        order: i.B,
                        $a: ci(t.u),
                        volume: D(i.volume || t.l),
                        symbol: t.h,
                        price: O(i.price, t.i)
                    }) : Fm.xa({
                        order: i.B,
                        $a: ci(t.u),
                        volume: D(i.volume || t.l),
                        symbol: t.h
                    });
                case 4:
                    return i.price ? Fm.Yj({
                        order: i.B,
                        $a: ci(t.u),
                        volume: D(i.volume || t.l),
                        symbol: t.h,
                        price: O(i.price, t.i)
                    }) : Fm.Va({
                        order: i.B,
                        $a: ci(t.u),
                        volume: D(i.volume || t.l),
                        symbol: t.h
                    });
                case 5:
                    return e = Fm.ik({
                        order: i.B,
                        $a: ci(t.u),
                        volume: D(i.volume || t.l),
                        symbol: t.h,
                        price: ui(t.m, t.K, t.i)
                    }), s = "", t.v && (s = Fm.gd(O(t.v, t.i))), t.A && (s += Fm.gd(O(t.A, t.i))), s && (e += `\n${s}`), e;
                case 6:
                    return s ? (e = "", e = s.Hb ? `#${s.Hb} ${xt(s.o)}` : e + xt(s.o), t = Fm.nk({
                        position: e,
                        volume: D(s.l),
                        symbol: s.h,
                        ka: O(t.v, t.i),
                        la: O(t.A, t.i)
                    })) : t = "", t;
                case 7:
                    return e ? Fm.dk({
                        order: t.B,
                        $a: ci(e.T),
                        volume: D(e.J),
                        symbol: t.h,
                        price: ui(t.m, t.K, t.i),
                        ka: O(t.v, t.i),
                        la: O(t.A, t.i)
                    }) : "";
                case 8:
                    return e ? (s = Fm.kk({
                        order: t.B,
                        $a: ci(e.T),
                        volume: D(e.J),
                        symbol: e.h,
                        price: ui(e.m, e.K, t.i)
                    }), i = "", t.v && (i = Fm.gd(O(e.v, t.i))), t.A && (i += Fm.He(O(e.A, t.i))), i && (s += `\n${i}`), t = s) : t = "", t
            }
            return ""
        }(r, a, u, c);
        switch (a.pa) {
            case 10001:
                l += `${r.login}: ${c}`, 10 === r.o && ((n = t.Xa(r.Ac)) || (n = i.Hf(r.Ac)), n && (l += ` ${xt(n.o)}`, l += ` ${D(n.l)}`, l += ` ${n.h}`));
                break;
            case 10002:
                l += `${r.login}: accepted ${c}`;
                break;
            case 10003:
                l += `${r.login}: processed ${c}`;
                break;
            case 10004:
                l += `${r.login}: requote`, l += ` ${O(a.O,e.i)}`, l += ` / ${O(a.L,e.i)}`, l += ` (${c})`;
                break;
            case 10005:
                l += `${r.login}: answer ${c}`, l += ` ${O(a.O,e.i)}`, l += ` / ${O(a.L,e.i)}`, n && (l += ` in ${n} ms`);
                break;
            case 10006:
                l += `${r.login}: rejected ${c}`, a.comment && (l += ` (${a.comment})`);
                break;
            case 10008:
                l += `${r.login}: ${c} placed for execution`, n && (l += ` in ${n} ms`);
                break;
            case 10009:
            case 10010:
            case 11001:
                switch (r.o) {
                    case 1:
                    case 2:
                    case 3:
                    case 4:
                    case 5:
                        break;
                    case 6:
                    case 7:
                    case 8:
                    case 10:
                        switch (i = l, l = r.login, t = "", r.o) {
                            case 0:
                                t += `prices for ${r.h} ${D(r.l)}`;
                                break;
                            case 1:
                                t += `request ${ci(r.u)}`, t += ` ${D(r.l)}`, t = (t += ` ${r.h}`) + " at" + O(r.m, r.i), r.F ? t += `, close #${r.F.toString()}` : (r.v && (t += ` sl: ${O(r.v,r.i)}`), r.A && (t += ` tp: ${O(r.A,r.i)}`));
                                break;
                            case 2:
                                t += `instant ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${O(r.m,r.i)}`, r.F ? t += `, close #${r.F.toString()}` : (r.v && (t += ` sl: ${O(r.v,r.i)}`), r.A && (t += ` tp: ${O(r.A,r.i)}`));
                                break;
                            case 3:
                                t += `market ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, r.F ? t += `, close #${r.F.toString()}` : (r.v && (t += ` sl: ${O(r.v,r.i)}`), r.A && (t += ` tp: ${O(r.A,r.i)}`));
                                break;
                            case 4:
                                t += `exchange ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${r.m?O(r.m,r.i):"market"}`, r.F ? t += `, close #${r.F.toString()}` : (r.v && (t += ` sl: ${O(r.v,r.i)}`), r.A && (t += ` tp: ${O(r.A,r.i)}`));
                                break;
                            case 5:
                                t += ci(r.u), t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,r.K,r.i)}`, r.v && (t += ` sl: ${O(r.v,r.i)}`), r.A && (t += ` tp: ${O(r.A,r.i)}`);
                                break;
                            case 6:
                                t += "modify", r.F && (t += ` #${r.F.toString()}`), t += ` ${xt(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` -> sl: ${O(r.v,r.i)}`, t += `, tp: ${O(r.A,r.i)}`;
                                break;
                            case 7:
                                t += `modify #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` -> price: ${ui(r.m,r.K,r.i)}`, t += `, sl: ${O(r.v,r.i)}`, t += `, tp: ${O(r.A,r.i)}`;
                                break;
                            case 8:
                                t += `cancel #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,r.K,r.i)}`;
                                break;
                            case 9:
                                t = (t += `transfer ${o.toMoney(r.m,2)}`) + " to ''" + r.comment;
                                break;
                            case 10:
                                t += "close position", r.F && (t += ` #${r.F.toString()}`), t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` by position #${r.Ac.toString()}`;
                                break;
                            case 100:
                                t += `activate  #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,r.K,r.i)}`;
                                break;
                            case 101:
                                t += "activate", r.F && (t += ` #${r.F.toString()}`), t += ` stop loss, ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,0,r.i)}`;
                                break;
                            case 102:
                                t += "activate", r.F && (t += ` #${r.F.toString()}`), t += ` take profit, ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,0,r.i)}`;
                                break;
                            case 103:
                                t += `activate stop-limit order #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,r.K,r.i)}`;
                                break;
                            case 104:
                                t += `delete stop-out order #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,r.K,r.i)}`;
                                break;
                            case 105:
                                t += "close stop-out position", r.F && (t += ` #${r.F.toString()}`), t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,0,r.i)}`;
                                break;
                            case 106:
                                t += `expire #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,0,r.i)}`;
                                break;
                            case 200:
                                t += `for ${r.login}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,0,r.i)}`, r.F ? t += `, close #${r.F.toString()}` : (r.v && (t += ` sl: ${O(r.v,r.i)}`), r.A && (t += ` tp: ${O(r.A,r.i)}`));
                                break;
                            case 201:
                                t += `for ${r.login}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` at ${ui(r.m,r.K,r.i)}`, r.v && (t += ` sl: ${O(r.v,r.i)}`), r.A && (t += ` tp: ${O(r.A,r.i)}`);
                                break;
                            case 202:
                                t += `for ${r.login}`, t += " modify position", r.F && (t += ` #${r.F.toString()}`), t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` -> price: ${ui(r.m,r.i,3)}`, t += ` sl: ${O(r.v,r.i)}`, t += ` tp: ${O(r.A,r.i)}`;
                                break;
                            case 203:
                                t += `for ${r.login}`, t += ` modify order #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` -> price: ${ui(r.m,r.K,r.i)}`, t += ` sl: ${O(r.v,r.i)}`, t += ` tp: ${O(r.A,r.i)}`;
                                break;
                            case 204:
                                t += `for ${r.login}`, t += ` cancel order #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`;
                                break;
                            case 205:
                                t += `for ${r.login}`, t += ` activate order #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`;
                                break;
                            case 207:
                                t += `for ${r.login}`, t += ` activate stop-limit order #${r.B.toString()}`, t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`;
                                break;
                            case 208:
                                t += `for ${r.login}`, t += " close position", r.F && (t += ` #${r.F.toString()}`), t += ` ${ci(r.u)}`, t += ` ${D(r.l)}`, t += ` ${r.h}`, t += ` by position #${r.Ac.toString()}`;
                                break;
                            case 206:
                                t += `for ${r.login}`, t += ` balance ${o.toMoney(r.m,2)}`, t += ` ${r.comment}`
                        }
                        l = i + `${l}: ${t} done`;
                        break;
                    default:
                        l += `${r.login}: ${c} done`
                }
                n && (l += ` in ${n} ms`);
                break;
            case 10025:
                l += `${r.login}: ${c} skipped as it changes nothing`;
                break;
            default:
                l += `${r.login}: failed ${c} [${pi(a.pa,h)}]`
        }
        return l
    }

    function di(t) {
        var i;
        return {
            priceOrder: t.m,
            priceTrigger: t.K,
            priceSL: t.v,
            priceTP: t.A,
            priceDeviation: t.Jc,
            symbol: t.h,
            volume: I(t.l),
            position: null == (i = t.F) ? void 0 : i.toString(),
            order: t.B ? t.B.toString() : void 0,
            expiration: t.ua,
            id: t.lb,
            typeName: pt(t.u),
            complete: t.complete,
            isBuy: t.isBuy(),
            isSell: t.isSell(),
            isMarket: t.isMarket(),
            isPending: t.isPending(),
            isClose: t.nd(),
            isCloseBy: t.Zd(),
            digits: t.i,
            tradeAction: t.o,
            comment: t.comment
        }
    }

    function bi(t) {
        return {
            code: t.pa,
            order: t.B ? t.B.toString() : "",
            volume: I(t.volume),
            price: t.price,
            time: t.Om,
            bid: t.O,
            ask: t.L,
            comment: t.comment
        }
    }

    function gi(t, i, s) {
        (t = t.request).h = s.h, t.o = 8, t.l = s.Ra, t.B = s.B, t.m = V(s.m, i.N, i.i), t.K = V(s.K, i.N, i.i), t.v = V(s.v, i.N, i.i), t.A = V(s.A, i.N, i.i), t.ya = s.ya, t.ua = Math.round((s.ua ?? 0) / 1e3), t.u = s.T
    }

    function yi(t, i, s, e, r, a, h) {
        var n;
        switch ((t = t.request).h = i.h, t.l = h ? C(h) : s.l, t.i = i.i, t.B = 0n, t.kb = pm.xa | pm.mi, t.F = s.H, t.m = s.D, t.K = 0, t.v = 0, t.A = 0, t.ya = 0, t.ua = 0, t.u = s.isBuy() ? 1 : 0, null == (n = i.trade) ? void 0 : n.ia) {
            case Sr.tc:
                if (t.ea = 0, a && !e && (s.isBuy() ? t.m = a.O : s.isSell() && (t.m = a.L)), i.trade && !i.trade.wb || t.l <= i.trade.wb) {
                    t.o = 2, t.Jc = mm.ni;
                    break
                }
            case Sr.uc:
                r ? (t.m = r, t.o = 1) : t.o = 0;
                break;
            case Sr.xa:
                t.o = 3, t.ea = i.trade && i.trade.Qa & Br.Rc ? 1 : i.trade && i.trade.Qa & Br.Qc ? 0 : 2;
                break;
            case Sr.Va:
                t.o = 4, t.ea = 2
        }
    }

    function wi(t, i, s, e) {
        t = t.request;
        var r = s.l;
        r >= e.l && (r = e.l), t.h = i.h, t.l = r, t.i = i.i, t.B = 0n, t.kb = pm.xa | pm.mi, t.F = s.H, t.Ac = e.H, t.m = s.D, t.K = 0, t.v = 0, t.A = 0, t.ya = 0, t.ua = 0, t.u = s.isBuy() ? 1 : 0, t.o = 10, t.ea = 0
    }

    function vi() {
        return {
            request: new Um,
            result: new Om
        }
    }

    function ki(t) {
        return {
            items: [],
            kn: 0,
            ln: 0,
            Rk: 0,
            Qh: [],
            aborted: !!t,
            ...t && {
                error: t
            }
        }
    }

    function Mi(t, i, s) {
        i.status = s, t.items.push(i), t[s] += 1
    }

    function Ti(t, i) {
        t.Qh.includes(i) || t.Qh.push(i)
    }

    function zi(t, i) {
        return t.Ca !== i.Ca ? t.Ca - i.Ca : t.H < i.H ? -1 : t.H > i.H ? 1 : 0
    }

    function Wi(t) {
        return {
            id: t.H,
            volume: t.l
        }
    }

    function Si(t) {
        switch (t) {
            case 2:
            case 3:
            case 4:
            case 5:
            case 6:
            case 7:
                return !0;
            default:
                return !1
        }
    }

    function ji() {
        return {
            request: new Um,
            result: new Om
        }
    }

    function Bi(t, i) {
        return i || (t.result.pa = 3, null)
    }

    function $i(t, i) {
        return i || (t.result.pa = 3, null)
    }

    function Li(t) {
        return {
            action: di(t.request),
            result: bi(t.result)
        }
    }

    function Ni(t) {
        return {
            items: t.items.map(t => ({
                status: t.status,
                targetIds: t.Uh,
                request: Li(t.transaction)
            })),
            submitted: t.kn,
            succeeded: t.ln,
            failed: t.Rk,
            skippedIds: t.Qh,
            aborted: t.aborted,
            ...t.error && {
                error: t.error
            }
        }
    }
    async function Ii(t) {
        var i, s = new js(Ys, {
            count: 1
        });
        await s.Le();
        try {
            var e = s.qa;
            let h = "",
                n = null;
            t.password && (320 === (null == (i = t.password) ? void 0 : i.length) ? n = r.hexToBuffer(t.password) : h = t.password.substring(0, 32));
            let o = [
                [6, 5],
                [18, BigInt(t.login ?? 0)],
                [11, h, 64],
                [11, (t.Vf || "").substring(0, 64), 128],
                [11, (t.lm || "").substring(0, 64), 128],
                [11, (t.nm || "").substring(0, 64), 128],
                [12, Ls, 16]
            ];
            n && o.push([12, n]);
            var a = Hi.serialize(o);
            await e.call(s, 43, a), s.close()
        } catch (h) {
            throw s.close(), h
        }
    }
    async function Ai(t, i, s, e, r) {
        await Ii({
            Tm: t,
            login: i,
            password: s,
            lm: e,
            nm: r
        })
    }
    async function Ci(t, i, s, e) {
        try {
            return await Ii({
                Tm: t,
                login: i,
                password: s,
                Vf: e
            }), !0
        } catch {
            return !1
        }
    }

    function Ei(t) {
        t.aa(10)
    }

    function Di(t, i, s) {
        t.aa(11, {
            event: {
                count: s.count,
                event: s.event,
                token: s.Xh
            },
            login: i
        })
    }

    function Oi(t, i) {
        t.aa(15, i)
    }

    function xi(t) {
        var i = [t.mt_firstName || "", t.mt_secondName || ""].join(" "),
            s = new URLSearchParams(window.self.location.search),
            e = s.get("utm_campaign") ?? "";
        return s = s.get("utm_source") ?? "", Hi.serialize([
            [11, i.substring(0, 128), 256],
            [11, t.mt_group.substring(0, 64), 128],
            [11, (t.mt_phonePassword || "").substring(0, 32), 64],
            [11, (t.mt_country || "").substring(0, 32), 64],
            [11, (t.mt_city || "").substring(0, 32), 64],
            [11, (t.mt_state || "").substring(0, 32), 64],
            [11, (t.mt_zipcode || "").substring(0, 16), 32],
            [11, (t.mt_address || "").substring(0, 128), 256],
            [11, (t.mt_phone || "").substring(0, 32), 64],
            [11, (t.mt_email || "").substring(0, 64), 128],
            [8, t.mt_deposit || 1e5],
            [6, t.mt_leverage || 100],
            [6, 0],
            [6, 1],
            [11, (t.mt_domain || "").substring(0, 64), 128],
            [11, e.substring(0, 32), 64],
            [11, s.substring(0, 32), 64],
            [6, t.mt_emailConfirmCode || 0],
            [6, t.mt_phoneConfirmCode || 0],
            [11, (t.mt_firstName || "").substring(0, 64), 128],
            [11, (t.mt_secondName || "").substring(0, 64), 128],
            [6, t.mt_agreements || 0]
        ])
    }

    function Fi(t) {
        return Hi.serialize([
            [6, t.version || 0],
            [11, (t.password || "").substring(0, 32), 64],
            [11, (t.Vf || "").substring(0, 64), 128],
            [12, t.Gk || Ls, 16],
            [11, "", 64],
            [11, "", 64],
            [18, 0n],
            [11, "", 128],
            [6, 0],
            [11, "", 256],
            [18, 0n]
        ])
    }

    function Ui(t) {
        return [(t = Hi.parse(t, qd))[0], t[1].toString(), t[2], t[3]]
    }

    function Pi(t) {
        return Hi.parse(t, _d)
    }

    function qi(t = []) {
        return t.map(t => {
            var i;
            return [12, Hi.serialize([
                [6, t.mt_dataType],
                [6, t.mt_documentType],
                [11, t.mt_frontName, 520],
                [6, t.mt_frontBuffer.byteLength],
                [11, t.mt_backName ?? "", 520],
                [6, (null == (i = t.mt_backBuffer) ? void 0 : i.byteLength) ?? 0],
                [12, t.mt_frontBuffer],
                [12, t.mt_backBuffer ?? new ArrayBuffer(0)]
            ])]
        })
    }
    var _i = (t, i, s) => {
            if (!i.has(t)) throw TypeError("Cannot read from private field");
            return s ? s.call(t) : i.get(t)
        },
        Xi = (t, i, s) => {
            if (i.has(t)) throw TypeError("Cannot add the same private member more than once");
            return i instanceof WeakSet ? i.add(t) : i.set(t, s)
        },
        Ri = (t, i, s, e) => {
            if (!i.has(t)) throw TypeError("Cannot write to private field");
            return i.set(t, s), s
        },
        Vi = (t, i, s) => {
            if (!i.has(t)) throw TypeError("Cannot access private method");
            return s
        },
        Hi = function(t) {
            var i = Object.create(null, {
                [Symbol.toStringTag]: {
                    value: "Module"
                }
            });
            if (t)
                for (let s in t)
                    if ("default" !== s) {
                        let e = Object.getOwnPropertyDescriptor(t, s);
                        Object.defineProperty(i, s, e.get ? e : {
                            enumerable: !0,
                            get: () => t[s]
                        })
                    } return i.default = t, Object.freeze(i)
        }(t);
    class Gi {
        constructor(t, i) {
            Xi(this, Ji), Xi(this, Ki), Xi(this, Yi), Xi(this, Zi), Ri(this, Ji, !1), this.start = 0, this.command = t, this.buffer = i, this.promise = new Promise((t, i) => {
                Ri(this, Ki, t), Ri(this, Yi, i)
            }), this.promise.request = this
        }
        Rm(t) {
            !_i(this, Ji) && _i(this, Ki) && (Ri(this, Ji, !0), _i(this, Ki).call(this, t), this.pe())
        }
        Aj(t) {
            !_i(this, Ji) && _i(this, Yi) && (Ri(this, Ji, !0), _i(this, Yi).call(this, t), this.pe())
        }
        Uf(t) {
            return Ri(this, Zi, globalThis.setTimeout(() => {
                t(this)
            }, 3e4)), this
        }
        pe() {
            return globalThis.clearTimeout(_i(this, Zi)), Ri(this, Ji, !0), Ri(this, Zi, void 0), Ri(this, Ki, void 0), Ri(this, Yi, void 0), this
        }
    }
    var Ji = new WeakMap,
        Ki = new WeakMap,
        Yi = new WeakMap,
        Zi = new WeakMap,
        Qi = [0, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 17, 18, 19, 20, 21, 22, 23, 24, 25, 27, 28, 29, 30, 33, 34, 37, 39, 40, 41, 42, 43, 44, 50, 51, 52, 100, 101, 102, 103, 104, 105, 106, 107, 108, 109, 110, 111, 112],
        ts = new Set(Qi),
        is = new WeakMap,
        ss = new WeakMap,
        es = new WeakMap,
        rs = new WeakMap,
        as = new WeakMap,
        hs = new WeakMap,
        ns = new WeakMap,
        os = new WeakMap,
        ls = new WeakMap,
        cs = new WeakMap,
        us = new WeakMap,
        ps = new WeakMap,
        ms = new WeakMap,
        fs = new WeakMap,
        ds = new WeakMap,
        bs = new WeakMap,
        gs = new WeakSet,
        ys = async function(t) {
            if (t = _i(this, rs).command(0, t), t = await e.enc(t, _i(this, ss)), 0 !== (t = await Vi(this, gs, ks).call(this, 0, t, !0, !1)).Dd) throw Error(JSON.stringify([0, t.Dd]));
            Ri(this, es, new DataView(t.Z).getUint16(0, !0)), Ri(this, is, t.Z.slice(2, 66)), Ri(this, ss, await e.initKey(t.Z.slice(66)))
        }, ws = function(t, i) {
            (t = _i(this, us).get(t)) && t.forEach(t => {
                t(i)
            })
        }, vs = function() {
            return Ri(this, hs, new Map), Ri(this, ns, new Map), Ri(this, os, new Map), Qi.forEach(t => {
                t = Number(t), isNaN(t) || (_i(this, ns).set(t, new Set), _i(this, os).set(t, []))
            }), this
        }, ks = function(t, i, s, e) {
            var r, a;
            return this.Ya || 0 === t ? (i = new Gi(t, _i(this, rs).om(t, i)), s && i.Uf(t => Vi(this, gs, Ss).call(this, t)), e ? (null == (r = _i(this, os).get(t)) || r.forEach(i => {
                i.Aj(Error(JSON.stringify([t, 1e4])))
            }), _i(this, os).set(t, [i])) : null == (a = _i(this, os).get(t)) || a.push(i), Vi(this, gs, Ts).call(this, t), i.promise) : (s = Error(JSON.stringify([t, 103])), Vi(this, gs, ws).call(this, "error", s), Promise.reject(Error(s.message)))
        }, Ms = function(t) {
            _i(this, hs).set(t.command, t), _i(this, as).send(t.buffer)
        }, Ts = function(t) {
            var i = _i(this, os).get(t);
            i && i.length && !_i(this, hs).get(t) && (t = i.shift()) && Vi(this, gs, Ms).call(this, t)
        }, zs = function(t, i) {
            return (t = _i(this, ns).get(t)) && t.forEach(t => {
                t.call(this, i)
            }), this
        }, Ws = new WeakMap, Ss = function(t) {
            t.Aj(Error(JSON.stringify([t.command, 408]))), _i(this, hs).delete(t.command), Vi(this, gs, Ts).call(this, t.command)
        }, js = class {
            constructor(t, i = {}) {
                Xi(this, gs), Xi(this, is), Xi(this, ss), Xi(this, es), Xi(this, rs), Xi(this, as), Xi(this, hs), Xi(this, ns), Xi(this, os), Xi(this, ls), Xi(this, cs), Xi(this, us), Xi(this, ps), Xi(this, ms), Xi(this, fs), Xi(this, ds), Xi(this, bs), Xi(this, Ws), Ri(this, es, 0), this.Ya = !1, Ri(this, hs, new Map), Ri(this, ns, new Map), Ri(this, os, new Map), Ri(this, us, new Map), Ri(this, ps, 0), Ri(this, ms, () => {
                    _i(this, ls) && _i(this, ls).call(this, Error(JSON.stringify([-1, 104])))
                }), Ri(this, fs, () => {
                    Vi(this, gs, ws).call(this, "open"), _i(this, cs) && _i(this, cs).call(this, this)
                }), Ri(this, ds, t => {
                    (t = t.data.slice(_i(this, rs).$j)).byteLength && e.dec(t, _i(this, ss)).then(c).then(_i(this, Ws))
                }), Ri(this, bs, t => {
                    _i(this, os).forEach(t => {
                        t.forEach(t => t.pe())
                    }), Ri(this, os, new Map), _i(this, hs).forEach(t => {
                        t.pe()
                    }), Ri(this, hs, new Map), this.Ya = !1, Vi(this, gs, ws).call(this, "close", {
                        count: _i(this, ps),
                        Xh: _i(this, is),
                        event: t
                    }), Vi(this, gs, vs).call(this)
                }), Ri(this, Ws, t => {
                    var i = t.Nm,
                        s = t.Dd;
                    t = t.Z, s > 0 && Vi(this, gs, ws).call(this, "error", Error(JSON.stringify([s, i])));
                    var e = _i(this, hs).get(i);
                    e && (e.Rm({
                        Dd: s,
                        Z: t
                    }), _i(this, hs).delete(i)), Vi(this, gs, Ts).call(this, i), Vi(this, gs, zs).call(this, i, {
                        Dd: s,
                        Z: t
                    })
                }), Ri(this, rs, t), Ri(this, is, i.Xh ?? new ArrayBuffer(64)), Ri(this, es, i.Tn ?? 0), Ri(this, ps, i.count ?? 0), Ri(this, hs, i.Rn ?? _i(this, hs)), Ri(this, ns, i.Pn ?? _i(this, ns)), Ri(this, os, i.Qn ?? _i(this, os)), Ri(this, us, i.Un ?? _i(this, us)), Vi(this, gs, vs).call(this)
            }
            get readyState() {
                var t;
                return null == (t = _i(this, as)) ? void 0 : t.readyState
            }
            async Le() {
                var t = `wss://${location.host}/terminal`;
                return this.Ya = !1, Ri(this, ss, await e.initKey(r.hexToBuffer(r.obfuscation("13ef13b2b76dd8:5795gdcfb2fdc1ge85bf768f54773d22fff996e3ge75g5:75")))), await new Promise((i, s) => {
                    Ri(this, ls, s), Ri(this, cs, i), Ri(this, as, new WebSocket(t)), _i(this, as).binaryType = "arraybuffer", _i(this, as).addEventListener("message", _i(this, ds)), _i(this, as).addEventListener("close", _i(this, bs), {
                        once: !0
                    }), _i(this, as).addEventListener("error", _i(this, ms), {
                        once: !0
                    }), _i(this, as).addEventListener("open", _i(this, fs), {
                        once: !0
                    }), this.Ii = t => {
                        _i(this, as).removeEventListener("message", _i(this, ds)), _i(this, as).removeEventListener("error", _i(this, ms)), _i(this, as).removeEventListener("open", _i(this, fs)), t && _i(this, as).removeEventListener("close", _i(this, bs))
                    }
                }), await Vi(this, gs, ys).call(this, _i(this, is)), this.Ya = !0, this
            }
            close(t = !1) {
                return new Promise(i => {
                    _i(this, os).forEach(t => {
                        t.forEach(t => t.pe())
                    }), Ri(this, os, new Map), _i(this, hs).forEach(t => {
                        t.pe()
                    }), Ri(this, hs, new Map), this.Ii && this.Ii(t), t ? (_i(this, bs).call(this), i()) : _i(this, as).addEventListener("close", () => i()), _i(this, as).close()
                })
            }
            async qa(t, i, s = !0) {
                if (!ts.has(t)) throw Error(JSON.stringify([t, 102]));
                var r = _i(this, ss);
                if (i = _i(this, rs).command(t, i), r = await e.enc(i, r), 0 !== (s = await Vi(this, gs, ks).call(this, t, r, s, !1)).Dd) throw Error(JSON.stringify([t, s.Dd]));
                return s
            }
            V(t, i) {
                var s;
                return null == (s = _i(this, ns).get(t)) || s.add(i), this
            }
            da(t, i) {
                var s = _i(this, ns).get(t);
                return s && i && s.has(i) && s.delete(i), i || _i(this, ns).set(t, new Set), this
            }
            subscribe(t, i) {
                var s = _i(this, us).get(t);
                return s || (s = new Set, _i(this, us).set(t, s)), s.add(i), this
            }
            unsubscribe(t, i) {
                return i ? (t = _i(this, us).get(t)) && t.delete(i) : _i(this, us).set(t, new Set), this
            }
        };
    class Bs {
        constructor() {
            Xi(this, $s, new Map), this.V = this.V.bind(_i(this, $s)), this.da = this.da.bind(_i(this, $s))
        }
        aa(t, i) {
            (t = _i(this, $s).get(t)) && t.forEach(t => t(i))
        }
        V(t, i) {
            var s = this.get(t);
            s || (s = new Set, this.set(t, s)), s.add(i)
        }
        da(t, i) {
            "number" != typeof t ? this.clear() : i ? (t = this.get(t)) && t.delete(i) : this.has(t) && this.delete(t)
        }
    }
    var $s = new WeakMap,
        Ls = new ArrayBuffer(0),
        Ns = [{
            propType: 12,
            propLength: 160
        }, {
            propType: 18
        }];
    class Is {
        constructor(t) {
            this.C = t
        }
    }
    class As extends Is {
        constructor() {
            super(...arguments), Xi(this, Cs, new Set), Xi(this, Es, t => {
                var i = new Uint32Array(t.Z)[0];
                _i(this, Cs).forEach(t => t(i))
            })
        }
        V(t) {
            _i(this, Cs).add(t)
        }
        da(t) {
            t ? _i(this, Cs).delete(t) : _i(this, Cs).clear()
        }
        async login(t, i, s, e, a) {
            var h, n;
            t = {
                login: t,
                password: i,
                url: s,
                Um: e,
                Vf: a
            }, i = (s = new URLSearchParams(window.self.location.search)).get("utm_campaign") ?? "", s = s.get("utm_source") ?? "", e = "";
            var o = t.Gk || Ls;
            return 320 === (null == (h = t.password) ? void 0 : h.length) ? a = r.hexToBuffer(t.password) : (e = (null == (n = t.password) ? void 0 : n.substring(0, 32)) ?? "", a = new ArrayBuffer(160)), t = Hi.serialize([
                [6, t.version || 0],
                [11, e, 64],
                [11, (t.Vf || "").substring(0, 64), 128],
                [12, o, 16],
                [11, i.substring(0, 32), 64],
                [11, s.substring(0, 32), 64],
                [18, t.On || 0n],
                [11, (t.Nn || "").substring(0, 64), 128],
                [6, Math.min(t.url ? t.url.length : 0, 128)],
                [11, (t.url || "").substring(0, 128), 256],
                [18, BigInt(t.login ?? 0)],
                [12, a, 160],
                [18, t.Um || 0n]
            ]), t = await this.C.V(15, _i(this, Es)).qa(28, t), t = Hi.parse(t.Z, Ns), [Hi.toHex(t[0]), t[1] ?? 0n]
        }
        destroy() {
            this.C.da(15, _i(this, Es)), this.da()
        }
        async sh() {
            return this.destroy(), await this.C.qa(2)
        }
        async Dk(t, i, s = !1) {
            return t = Hi.serialize([
                [4, Number(s ?? !1)],
                [11, (t ?? "").substring(0, 32), 64],
                [11, (i ?? "").substring(0, 32), 64]
            ]), ({
                Z: t
            } = await this.C.qa(24, t)), new DataView(t).getInt32(0, !0)
        }
        async ping() {
            await this.C.qa(51)
        }
        Xg() {
            return 1 === this.C.readyState
        }
        Hk() {
            this.C.close(!0)
        }
    }
    var Cs = new WeakMap,
        Es = new WeakMap;
    class Ds {
        constructor() {
            this.state = 0
        }
        $m(t) {
            this.state = t
        }
    }
    class Os {
        constructor(t, i) {
            Xi(this, xs), Xi(this, Fs), Xi(this, Us), Xi(this, Ps, 0), Xi(this, qs, 0), Xi(this, _s, null), Xi(this, Xs, null), Xi(this, Rs, () => {
                _i(this, _s) && Ri(this, qs, _i(this, Ps)), _i(this, qs) && Date.now() - _i(this, qs) > 15e3 ? (_i(this, Fs).Hk(), Ri(this, qs, 0), Ri(this, Ps, 0)) : (Ri(this, _s, _i(this, Fs).ping()), _i(this, _s).then(() => {
                    Ri(this, _s, null), Ri(this, qs, 0), Ri(this, Ps, Date.now())
                }), Ri(this, Xs, setTimeout(_i(this, Rs), 5e3)))
            }), Xi(this, Vs, () => {
                _i(this, Xs) && (clearTimeout(_i(this, Xs)), Ri(this, Xs, null))
            }), Xi(this, Hs, t => {
                _i(this, Us).$m(t), _i(this, xs).aa(16, t)
            }), Ri(this, Us, new Ds), Ri(this, xs, t), Ri(this, Fs, i), _i(this, xs).V(11, _i(this, Vs)), _i(this, Fs).V(_i(this, Hs))
        }
        async login(t, i, s, e, r) {
            return t = await _i(this, Fs).login(t, i, s, e, r), _i(this, Xs) && clearTimeout(_i(this, Xs)), _i(this, Rs).call(this), t
        }
        async Ek(t, i, s, e) {
            return 0 !== (s = p(t, s)) ? s : _i(this, Fs).Dk(t, i, e)
        }
        async sh() {
            "number" == typeof _i(this, Xs) && clearTimeout(_i(this, Xs)), await _i(this, Fs).sh(), "number" == typeof _i(this, Xs) && clearTimeout(_i(this, Xs))
        }
        destroy() {
            _i(this, Fs).destroy()
        }
        ml() {
            return 0 === _i(this, Us).state
        }
        Xg() {
            return _i(this, Fs).Xg()
        }
    }
    var xs = new WeakMap,
        Fs = new WeakMap,
        Us = new WeakMap,
        Ps = new WeakMap,
        qs = new WeakMap,
        _s = new WeakMap,
        Xs = new WeakMap,
        Rs = new WeakMap,
        Vs = new WeakMap,
        Hs = new WeakMap;
    class Gs {
        constructor(t) {
            Xi(this, Js), Ri(this, Js, t)
        }
        async logout() {
            return _i(this, Js).sh()
        }
        async changePassword(t, i, s, e) {
            return _i(this, Js).Ek(t, i, s, e)
        }
    }
    var Js = new WeakMap;
    class Ks {
        constructor(t, i) {
            this.controller = new Os(t, new As(i)), this.view = new Gs(this.controller)
        }
    }
    var Ys = {
            om: function(t, i) {
                t = i && i.byteLength || 0;
                var s = new Uint8Array(8 + t);
                return i && s.set(new Uint8Array(i), 8), (i = new DataView(s.buffer)).setUint32(0, t, !0), i.setUint32(4, 1, !0), s.buffer
            },
            command: function(t, i) {
                var s = new Uint8Array(4 + (i && i.byteLength || 0));
                return i && s.set(new Uint8Array(i), 4), (i = new DataView(s.buffer)).setUint8(0, Math.floor(255 * Math.random())), i.setUint8(1, Math.floor(255 * Math.random())), i.setUint16(2, t, !0), s.buffer
            },
            $j: 8
        },
        Zs = {
            NONE: 0,
            In: 1,
            Jn: 2,
            zn: 4,
            An: 8,
            Dn: 16,
            En: 32,
            Gn: 64,
            pk: 128,
            Zj: 256,
            Bn: 512,
            xn: 1024,
            Hn: 2048
        },
        Qs = Object.values(Zs).reduce((t, i) => t | i, 0);
    class te {
        static Kg(t) {
            return t.map(t => new te(t))
        }
        constructor(t) {
            this.path = t[0], this.zj = t[1], this.Yf = t[2], this.Km = t[3], this.ab = t[5].map(t => ({
                Bd: t[0],
                Cd: t[1],
                Ye: t[2],
                Ze: t[3]
            }))
        }
    }
    class ie {
        static Kg(t) {
            return t.map(t => new ie(t))
        }
        constructor(t) {
            this.path = t[0], this.mode = t[1], this.bm = t[2], this.Zl = t[3], this.$l = t[4], this.am = t[5], this.ab = t[6].map(t => ({
                mode: t[0],
                type: t[1],
                value: t[2],
                Bd: t[3],
                Cd: t[4],
                Yl: t[5],
                Xl: t[6],
                currency: t[7]
            }))
        }
        pl() {
            return 1 === this.mode
        }
    }
    var se = class {
            constructor(t, i) {
                Xi(this, ee), this.credit = this.balance = this.Nd = 0, this.ra = "", this.zc = this.j = 0, this.wi = "", this.Cj = 0, this.Ki = this.Dj = "", this.Sb = this.na = this.ma = this.Xe = this.af = this.bf = this.$e = this.th = this.ge = this.Lg = this.Wh = 0, this.Db = Zs.NONE, this.ke = this.ef = 0, this.og = [], this.hc = this.collateral = this.liabilities = this.assets = this.equity = this.floating = this.P = this.S = this.margin = this.M = this.commission = this.profit = this.Ic = this.R = 0, this.Ig = 8, this.W = this.$b = this.Hj = 0, this.rules = [], this.Ji = [], this.sj = this.Bb = 0, this.login = i, Ri(this, ee, t), this.pg(t)
            }
            pg(t) {
                Ri(this, ee, t), this.Nd = t[0], this.ef = t[1], this.ke = t[2], this.balance = t[3], this.credit = t[4], this.ra = t[5], this.j = t[6], this.zc = t[7], this.wi = t[8], this.Cj = t[9], this.Dj = t[10], this.Ki = t[11], this.Wh = t[12], this.Lg = t[13], this.ge = t[14], this.th = t[15], this.$e = t[16], this.bf = t[17], this.af = t[18], this.Xe = t[20], this.Sb = t[21], this.ma = t[22], this.na = t[23], this.Ig = t[24], this.sj = t[25], this.og = t[26].map(t => ({
                    ...t
                })), this.Db = t[27], this.Hj = t[28], this.rules = te.Kg(t[30]), this.Ji = ie.Kg(t[31])
            }
            Cf() {
                return new se(_i(this, ee), this.login)
            }
            ej() {
                return !!(8 & this.ef)
            }
            jj() {
                return !!(4 & this.ef)
            }
            hj() {
                return !!(512 & this.ef)
            }
            fh() {
                return !!(1024 & this.ef)
            }
            nc() {
                return 2 === this.ge
            }
            ae() {
                return this.nc() && !!(this.Db & Zs.Zj)
            }
            $d() {
                return 1 === this.ge
            }
            Ue() {
                return 3600 * this.Lg + this.Wh
            }
            Sm() {
                return !!(16 & this.ke)
            }
        },
        ee = new WeakMap,
        re = se;
    class ae {
        constructor(t) {
            Xi(this, he), Ri(this, he, t)
        }
        ha() {
            return _i(this, he)
        }
    }
    var he = new WeakMap;
    class ne {
        constructor(t, i, s, e) {
            Xi(this, oe), Xi(this, le), Xi(this, ce), Xi(this, ue, t => {
                this.pg(t.detail), _i(this, oe).aa(14)
            }), Ri(this, oe, t), Ri(this, le, i), Ri(this, ce, new ae(new re([...s], e))), t = _i(this, ce).ha(), _i(this, oe).aa(13, {
                isInvestor: t.ej(),
                isResetPass: t.fh(),
                isTradeDisabled: t.jj(),
                isReadOnly: t.hj(),
                isHedgedMargin: t.nc(),
                isFifo: t.ae()
            }), _i(this, le).V("800", _i(this, ue))
        }
        destroy() {
            _i(this, le).da("800", _i(this, ue)), _i(this, le).destroy()
        }
        pg(t) {
            this.ha().pg(t)
        }
        ha() {
            return _i(this, ce).ha()
        }
        checkPassword(t) {
            return p(t, this.ha().Ig)
        }
    }
    var oe = new WeakMap,
        le = new WeakMap,
        ce = new WeakMap,
        ue = new WeakMap;
    class pe {
        constructor(t) {
            Xi(this, me), Ri(this, me, t)
        }
        checkPassword(t) {
            return _i(this, me).checkPassword(t)
        }
        getAccount() {
            var t = _i(this, me).ha();
            return {
                type: t.Nd,
                isReal: 0 === t.Nd,
                isDemo: 1 === t.Nd,
                isContest: 2 === t.Nd,
                isPreliminary: 3 === t.Nd,
                name: t.wi,
                login: t.login,
                company: t.Ki,
                timezoneShift: t.Wh,
                dayLightMode: t.Lg,
                currency: t.ra,
                digits: t.j,
                serverBuild: t.Cj,
                serverName: t.Dj,
                balance: t.balance,
                credit: t.credit,
                profit: t.profit,
                commission: t.W,
                storage: t.M,
                margin: t.margin,
                marginFree: t.R,
                marginInitial: t.S,
                marginMaintenance: t.P,
                marginLeverage: t.zc,
                marginLevel: s.normalize(t.Ic, t.j),
                floating: t.floating,
                equity: t.equity,
                assets: t.assets,
                liabilities: t.liabilities,
                collateral: t.collateral,
                isInvestor: t.ej(),
                isTradeDisabled: t.jj(),
                isReadOnly: t.hj(),
                isHedgedMargin: t.nc(),
                isFifo: t.ae(),
                isResetPass: t.fh(),
                passwordMin: t.Ig,
                serverOffsetTime: t.Ue(),
                riskWarning: t.Sm(),
                otpStatus: t.sj
            }
        }
    }
    var me = new WeakMap,
        fe = [{
            propType: 11,
            propLength: 256
        }, {
            propType: 3
        }, {
            propType: 3
        }, {
            propType: 6
        }, {
            propType: 3
        }, {
            propType: 3
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 18
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 18
        }, {
            propType: 18
        }, {
            propType: 18
        }, {
            propType: 18
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 12,
            propLength: 64,
            parser: f
        }, {
            propType: 12,
            propLength: 64,
            parser: f
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 3
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 12,
            propLength: 56,
            parser: f
        }],
        de = Hi.getSeriesSize(fe),
        be = [{
            propType: 11,
            propLength: 256
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 32
        }, {
            propType: 6
        }],
        ge = Hi.getSeriesSize(be),
        ye = [{
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 11,
            propLength: 32
        }],
        we = Hi.getSeriesSize(ye),
        ve = [{
            propType: 11,
            propLength: 256
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 32
        }, {
            propType: 6
        }, {
            propType: 3
        }],
        ke = Hi.getSeriesSize(ve),
        Me = [{
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }],
        Te = Hi.getSeriesSize(Me),
        ze = [{
            propType: 4
        }, {
            propType: 3
        }, {
            propType: 3
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 256
        }, {
            propType: 5
        }, {
            propType: 11,
            propLength: 128
        }, {
            propType: 11,
            propLength: 256
        }, {
            propType: 3
        }, {
            propType: 1
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 6
        }],
        We = Hi.getSeriesSize(ze);
    class Se {
        constructor(t = "") {
            Xi(this, Le), Xi(this, je), Xi(this, Be), Xi(this, $e, new Map), Ri(this, Be, t), Ri(this, je, new EventTarget)
        }
        V(t, i) {
            Vi(this, Le, Ne).call(this, t, i), _i(this, je).addEventListener(t, i)
        }
        once(t, i) {
            _i(this, je).addEventListener(t, i, {
                once: !0
            })
        }
        da(t, i) {
            Vi(this, Le, Ie).call(this, t, i), _i(this, je).removeEventListener(t, i)
        }
        aa(t, i) {
            _i(this, je).dispatchEvent(new CustomEvent(t, {
                detail: i,
                cancelable: !0
            }))
        }
        destroy() {
            _i(this, $e).forEach((t, i) => {
                t.forEach(t => {
                    t && _i(this, je).removeEventListener(i, t)
                })
            }), _i(this, $e).clear()
        }
    }
    var je = new WeakMap,
        Be = new WeakMap,
        $e = new WeakMap,
        Le = new WeakSet,
        Ne = function(t, i) {
            var s = _i(this, $e).get(t) || new Set;
            s.add(i), _i(this, $e).set(t, s)
        },
        Ie = function(t, i) {
            (t = _i(this, $e).get(t)) && t.delete(i)
        };
    class Ae extends Se {
        constructor(t) {
            super("api_account"), Xi(this, Ce), Xi(this, Ee, t => {
                t = b(t.Z), this.aa("800", t)
            }), Ri(this, Ce, t), _i(this, Ce).V(14, _i(this, Ee))
        }
        async ha() {
            return b((await _i(this, Ce).qa(3)).Z)
        }
    }
    var Ce = new WeakMap,
        Ee = new WeakMap;
    class De {
        static async Mk(t, i, s) {
            i = new Ae(i);
            var e = await i.ha();
            return new De(t, i, e, s)
        }
        constructor(t, i, s, e) {
            this.controller = new ne(t, i, s, e), this.view = new pe(this.controller)
        }
    }
    class Oe {
        constructor(t) {
            Xi(this, xe), Ri(this, xe, t)
        }
        async Mh(t) {
            await _i(this, xe).Mh(t)
        }
    }
    var xe = new WeakMap;
    class Fe extends Is {
        async Mh(t) {
            await this.C.qa(42, Hi.serialize([
                [6, t ?? 0]
            ]))
        }
    }
    class Ue {
        constructor(t) {
            Xi(this, Pe), Ri(this, Pe, t)
        }
        async send(t) {
            await _i(this, Pe).Mh(t)
        }
    }
    var Pe = new WeakMap;
    class qe {
        constructor(t) {
            this.controller = new Oe(new Fe(t)), this.view = new Ue(this.controller)
        }
    }
    class _e {
        constructor() {
            Xi(this, Xe, new Map), Xi(this, Re, {
                count: 0,
                path: "",
                label: "",
                children: new Map
            })
        }
        Og() {
            return new Map(_i(this, Xe))
        }
        If() {
            return {
                ..._i(this, Re)
            }
        }
        Di(t) {
            t.forEach(t => {
                var i = _i(this, Re).children;
                for (let s = 0; s < t.je.length && (i = i.get(t.je[s])); s++) i.count += 1, i = i.children
            })
        }
        Ea() {
            _i(this, Xe).clear(), _i(this, Re).children.clear(), _i(this, Re).count = 0
        }
        bn(t, i) {
            _i(this, Xe).set(t, i.aj), this.an(i.aj)
        }
        an(t) {
            var i = t.split("\\"),
                s = _i(this, Re).children;
            i.forEach((t, e) => {
                var r = s.get(t);
                r || (r = {
                    count: 0,
                    children: new Map,
                    path: i.slice(0, e + 1).join("\\"),
                    label: t
                }, s.set(t, r)), s = r.children
            })
        }
    }
    var Xe = new WeakMap,
        Re = new WeakMap;
    class Ve {
        constructor(t) {
            Xi(this, He), Xi(this, Ge, new _e), Xi(this, Je, t => {
                t.forEach((t, i) => {
                    _i(this, Ge).bn(i, t)
                })
            }), Ri(this, He, t)
        }
        async init() {
            this.destroy();
            var t = await _i(this, He).Ul();
            _i(this, Je).call(this, t)
        }
        destroy() {
            _i(this, Ge).Ea()
        }
        Di(t) {
            t.forEach(t => {
                var i = _i(this, Ge).If().children;
                for (let s = 0; s < t.je.length && (i = i.get(t.je[s])); s++) i.count += 1, i = i.children
            })
        }
        Og() {
            return _i(this, Ge).Og()
        }
        If() {
            return _i(this, Ge).If()
        }
    }
    var He = new WeakMap,
        Ge = new WeakMap,
        Je = new WeakMap,
        Ke = [{
            propType: 11,
            propLength: 256
        }],
        Ye = Hi.getSeriesSize(Ke);
    class Ze extends Is {
        async Ul() {
            var t = (await this.C.qa(9)).Z,
                i = [],
                s = new DataView(t).getUint32(0, !0),
                e = 4;
            for (let r = 0; r < s; r++) i.push(g(t, e)), e += Ye;
            return i
        }
    }
    class Qe {
        constructor(t, i, s = !0) {
            this.catagories = [], (i = i.split("\\")).forEach(i => {
                (i = t.children.get(i)) && (t = i)
            }), this.parentPath = i.slice(0, -1).join("\\"), s && (this.catagories = [...t.children].filter(t => t[1].count).map(i => new Qe(t, i[1].path, !1))), this.label = t.label, this.count = t.count, this.path = t.path
        }
    }
    class tr {
        constructor(t) {
            Xi(this, ir), Ri(this, ir, t)
        }
        getBranch(t = "") {
            return new Qe(_i(this, ir).If(), t)
        }
        getTypes() {
            return _i(this, ir).Og()
        }
    }
    var ir = new WeakMap;
    class sr {
        constructor(t) {
            this.controller = new Ve(new Ze(t)), this.view = new tr(this.controller)
        }
    }
    var er = {
            Ie: 0,
            pi: 1,
            ug: 2,
            vg: 3
        },
        rr = {
            Dg: 0,
            rf: 1
        };
    class ar {
        constructor(t) {
            this.ce = [], this.de = [], this.Mc = t[0], this.vc = t[1], this.S = t[2], this.P = t[3], this.xd = t[4]
        }
        xj(t) {
            return !(this.xd !== er.ug && this.xd !== er.vg || t !== er.ug && t !== er.vg) && this.xd > t
        }
    }
    class hr {
        constructor(t, i) {
            this.Mc = t.Mc, this.spread = t, this.me = i[0], this.vc = i[1], this.h = i[2], this.Jj = i[3], this.Kj = i[4], this.Sh = i[5]
        }
        Hi(t, i, s) {
            if (s < 0) return !1;
            switch (this.me) {
                case rr.Dg:
                    return this.h === t;
                case rr.rf:
                    return (!this.Jj || s >= this.Jj) && (!this.Kj || s <= this.Kj) && this.h === i;
                default:
                    return !1
            }
        }
    }
    var nr = [{
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }],
        or = Hi.getSeriesSize(nr),
        lr = [{
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }],
        cr = Hi.getSeriesSize(lr);
    class ur extends Is {
        constructor() {
            super(...arguments), Xi(this, mr), Xi(this, pr, new WeakMap)
        }
        async fl(t) {
            return t = T(t), M((t = await this.C.qa(20, t)).Z)
        }
        V(t) {
            var i = _i(this, pr).get(t);
            return i || (i = Vi(this, mr, fr).bind(this, t), _i(this, pr).set(t, i)), this.C.V(20, i), this
        }
        da(t) {
            return (t = _i(this, pr).get(t)) && this.C.da(20, t), this
        }
    }
    var pr = new WeakMap,
        mr = new WeakSet,
        fr = function(t, i) {
            t(M(i.Z))
        };
    class dr {
        constructor() {
            Xi(this, br), Xi(this, gr), Xi(this, yr), Xi(this, wr), Xi(this, vr), Ri(this, br, []), Ri(this, gr, {}), Ri(this, yr, []), Ri(this, wr, []), Ri(this, vr, []), this.path = ""
        }
        Il() {
            Ri(this, vr, [])
        }
        El(t) {
            _i(this, vr).push(t)
        }
        jh() {
            return _i(this, vr).length
        }
        ih(t) {
            return _i(this, vr).filter(i => i.h === t)
        }
        Jl(t) {
            _i(this, vr).sort(t)
        }
        Ll() {
            return [..._i(this, yr)]
        }
        Kl() {
            Ri(this, yr, [])
        }
        nj(t) {
            _i(this, yr).push(t)
        }
        Gl() {
            return [..._i(this, wr)]
        }
        Fl() {
            Ri(this, wr, [])
        }
        mj(t) {
            _i(this, wr).push(t)
        }
        jn(t) {
            this.fn(), t.forEach(t => {
                this.en(t)
            })
        }
        en(t) {
            _i(this, br).push(t), _i(this, gr)[t.Mc] = t
        }
        fn() {
            Ri(this, br, []), Ri(this, gr, {})
        }
        hn(t) {
            return _i(this, gr)[t] ?? _i(this, br).find(i => i.Mc === t)
        }
        gn(t) {
            _i(this, br).forEach(t)
        }
        Ml(t) {
            _i(this, yr).sort(t)
        }
        Hl(t) {
            _i(this, wr).sort(t)
        }
    }
    var br = new WeakMap,
        gr = new WeakMap,
        yr = new WeakMap,
        wr = new WeakMap,
        vr = new WeakMap;
    class kr {
        constructor(t, i) {
            Xi(this, Mr), Xi(this, Tr, new dr), Xi(this, zr), Ri(this, Mr, t), Ri(this, zr, i)
        }
        async Sl(t) {
            if (t.length) {
                var i = [],
                    s = [];
                t.forEach(t => {
                    var e = _i(this, zr).Ma(t);
                    e && (s.push(e.ta), _i(this, zr).Ba(t) || i.push(e.ta))
                }), s.length && (i.length && await _i(this, zr).cd(s), t = await _i(this, Mr).fl(s), this.qk(s), _i(this, Tr).jn(t), this.wk())
            }
        }
        ih(t) {
            return _i(this, Tr).ih(t)
        }
        Ti(t) {
            return _i(this, Tr).hn(t)
        }
        jh() {
            return _i(this, Tr).jh()
        }
        qk(t) {
            var i = [];
            t.forEach(t => {
                (t = _i(this, zr).Vi(t)) && i.push(t)
            }), _i(this, Tr).Il(), i.forEach(t => {
                this.Ci(_i(this, Tr).Ll(), t, t.h), this.Ci(_i(this, Tr).Gl(), t, t.Tb)
            })
        }
        wk() {
            _i(this, Tr).Kl(), _i(this, Tr).Fl(), _i(this, Tr).gn(t => {
                t.ce.forEach(t => {
                    t.me === rr.Dg ? _i(this, Tr).nj(t) : t.me === rr.rf && _i(this, Tr).mj(t)
                }), t.de.forEach(t => {
                    t.me === rr.Dg ? _i(this, Tr).nj(t) : t.me === rr.rf && _i(this, Tr).mj(t)
                })
            }), _i(this, Tr).Ml(z), _i(this, Tr).Hl(z)
        }
        Ci(t, i, s) {
            s && (t.filter(t => t.h === s).forEach(t => {
                t.Hi(i.h, i.Tb, i.ua) && _i(this, Tr).El(t)
            }), _i(this, Tr).Jl(z))
        }
    }
    var Mr = new WeakMap,
        Tr = new WeakMap,
        zr = new WeakMap;
    class Wr {
        constructor(t, i) {
            this.controller = new kr(new ur(t), i)
        }
    }
    var Sr = {
            uc: 0,
            tc: 1,
            xa: 2,
            Va: 3
        },
        jr = {
            NONE: 0,
            Fe: 1
        },
        Br = {
            NONE: 0,
            Qc: 1,
            Rc: 2,
            nf: 4,
            Cc: 7
        },
        $r = {
            NONE: 0,
            sf: 1,
            qf: 2,
            wf: 4,
            xf: 8,
            Cc: 15
        },
        Lr = {
            NONE: 0,
            xa: 1,
            uf: 2,
            yf: 4,
            zf: 8,
            gd: 16,
            He: 32,
            pf: 64,
            Cc: 127
        };
    class Nr {
        constructor(t) {
            this.Tb = "", this.i = 0, this.se = "", this.ta = 0, this.Pa = "", this.zh = [], this.je = [], this.h = this.ie = "", this.le = this.ga = 0, this.h = t[0] ?? this.h, this.se = t[1] ?? this.se, this.i = t[2] ?? this.i, this.ta = t[3] ?? this.ta, this.gf(t[4] ?? this.Pa), this.ga = t[5] ?? this.ga, this.Tb = t[6] ?? this.Tb, this.le = t[7] ?? this.le
        }
        gf(t = "") {
            this.Pa = t, this.zh = this.Pa.split("\\"), this.je = this.zh.slice(0, -1), this.ie = this.je.join("\\")
        }
        Be(t) {
            this.Tb = t.Tb ?? this.Tb, this.i = t.i ?? this.i, this.se = t.se ?? this.se, this.ta = t.ta ?? this.ta, this.ga = t.ga ?? this.ga, this.h = t.h ?? this.h, this.le = t.le ?? this.le, this.gf((null == t ? void 0 : t.Pa) ?? this.Pa)
        }
        Jb() {
            return W(this.ga)
        }
        qd() {
            return 34 === this.ga
        }
        Hc() {
            return 37 === this.ga || 39 === this.ga
        }
        Al() {
            return 32 === this.ga || 38 === this.ga
        }
        oa() {
            return 64 === this.ga
        }
        dh() {
            return 35 === this.ga || 36 === this.ga
        }
        $g() {
            return [1, 33, 34].includes(this.ga)
        }
    }
    class Ir extends Nr {
        constructor(t) {
            super([t[0], t[2], t[21], t[24], t[46].Pa, t[35], t[4], t[10]]), Xi(this, Ar), this.ua = 0, this.mc = this.Aa = this.Gb = this.country = this.we = this.Qd = this.ue = this.Yd = this.be = "", this.jb = this.Bc = this.ve = this.te = this.Ga = this.kd = this.zb = this.Ha = 0, this.Db = jr.NONE, this.I = this.N = this.va = this.dc = this.xb = 0, this.xe = 0, this.Id = this.Ob = this.Ka = this.Jd = this.ye = this.bc = this.cc = this.Ja = 0, this.gf(t[46].Pa || this.Pa), this.be = t[1] ?? this.be, this.Yd = t[3] ?? this.Yd, this.ue = t[6] ?? this.ue, this.Qd = t[7] ?? this.Qd, this.we = t[8] ?? this.we, this.country = t[12] ?? this.country, this.Gb = t[13] ?? this.Gb, this.Aa = t[14] ?? this.Aa, this.mc = t[15] ?? this.mc, this.Ha = t[16] ?? this.Ha, this.zb = t[17] ?? this.zb, this.kd = t[18] ?? this.kd, this.Ga = t[22] ?? this.Ga, this.te = t[23] ?? this.te, this.ve = t[25] ?? this.ve, this.Bc = t[26] ?? this.Bc, this.jb = t[27] ?? this.jb, this.Db = t[28] ?? this.Db, this.xb = t[29] ?? this.xb, this.dc = t[30] ?? this.dc, this.va = t[31] ?? this.va, this.N = t[32] ?? this.N, this.I = t[33] ?? this.I, this.xe = t[34] ?? this.xe, this.Ja = t[36] ?? this.Ja, this.cc = t[37] ?? this.cc, this.bc = t[38] ?? this.bc, this.ye = t[39] ?? this.ye, this.Jd = t[40] ?? this.Jd, this.Ka = t[41] ?? this.Ka, this.Ob = t[42] ?? this.Ob, this.Id = t[44] ?? this.Id, this.ua = t[45] ?? this.ua, this.trade = {
                ...t[46]
            }, this.ff = {
                Ad: [...t[47].Ad],
                Kd: [...t[47].Kd]
            }, this.Bh = {
                ...t[46]
            }, this.Gd = t[48]
        }
        Be(t) {
            var i;
            super.Be(t), this.gf(t.Pa || (null == (i = t.trade) ? void 0 : i.Pa) || this.Pa), this.be = t.be ?? this.be, this.Yd = t.Yd ?? this.Yd, this.ue = t.ue ?? this.ue, this.Qd = t.Qd ?? this.Qd, this.we = t.we ?? this.we, this.country = t.country ?? this.country, this.Gb = t.Gb ?? this.Gb, this.Aa = t.Aa ?? this.Aa, this.mc = t.mc ?? this.mc, this.Ha = t.Ha ?? this.Ha, this.zb = t.zb ?? this.zb, this.kd = t.kd ?? this.kd, this.Ga = t.Ga ?? this.Ga, this.te = t.te ?? this.te, this.ve = t.ve ?? this.ve, this.Bc = t.Bc ?? this.Bc, this.jb = t.jb ?? this.jb, this.Db = t.Db ?? this.Db, this.xb = t.xb ?? this.xb, this.dc = t.dc ?? this.dc, this.va = t.va ?? this.va, this.N = t.N ?? this.N, this.I = t.I ?? this.I, this.xe = t.xe ?? this.xe, this.Ja = t.Ja ?? this.Ja, this.cc = t.cc ?? this.cc, this.bc = t.bc ?? this.bc, this.ye = t.ye ?? this.ye, this.Jd = t.Jd ?? this.Jd, this.Ka = t.Ka ?? this.Ka, this.Ob = t.Ob ?? this.Ob, this.Id = t.Id ?? this.Id, this.trade = {
                ...t.trade
            }, this.Bh = {
                ...t.trade
            }, this.trade = {
                ...t.trade ?? this.trade
            }, this.ff = {
                Ad: [...t.ff.Ad],
                Kd: [...t.ff.Kd]
            }, this.Gd = t.Gd ?? this.Gd
        }
        Qm() {
            this.trade && this.Bh && Object.assign(this.trade, this.Bh)
        }
        Fa(t, i) {
            var s = this.trade;
            if (s) switch (t) {
                case 0:
                    t = s.Lb[0], s = s.Mb[0];
                    break;
                case 1:
                    t = s.Lb[1], s = s.Mb[1];
                    break;
                case 2:
                    t = s.Lb[2], s = s.Mb[2];
                    break;
                case 4:
                    t = s.Lb[4], s = s.Mb[4];
                    break;
                case 6:
                    t = s.Lb[6], s = s.Mb[6];
                    break;
                case 3:
                    t = s.Lb[3], s = s.Mb[3];
                    break;
                case 5:
                    t = s.Lb[5], s = s.Mb[5];
                    break;
                case 7:
                    t = s.Lb[7], s = s.Mb[7];
                    break;
                default:
                    s = t = 0
            } else s = t = 0;
            return i ? t : s || t
        }
        ah() {
            return !!(4 & this.trade.fe)
        }
        Jf() {
            return !!(8 & this.trade.fe)
        }
        Ta() {
            return !!(8 & this.ve)
        }
        Bl() {
            var t = this.trade;
            return !!t && 0 !== t.ac && (64 !== this.ga || 3 === t.ac)
        }
        eh(t) {
            var i = this.trade;
            return !!i && 0 !== (i.bb & t)
        }
        od() {
            return Vi(this, Ar, Cr).call(this) && 0 === this.Gd.level
        }
        cj() {
            return 1 === this.jb || 255 === this.jb
        }
    }
    var Ar = new WeakSet,
        Cr = function() {
            return 1 === this.Gd.status || 2 === this.Gd.status
        };
    class Er {
        constructor() {
            Xi(this, Dr, new Map), Xi(this, Or, []), Xi(this, xr, []), Xi(this, Fr, new Map)
        }
        Ea() {
            Ri(this, Dr, new Map), Ri(this, Fr, new Map), Ri(this, Or, []), Ri(this, xr, [])
        }
        tk(t) {
            _i(this, Dr).has(t.h), _i(this, Dr).set(t.h, t);
            var i = _i(this, Fr).get(t.ie);
            i || (i = [], _i(this, Fr).set(t.ie, i)), i.push(t)
        }
        xi(t, i = !1) {
            var s = _i(this, Dr).has(t.h);
            _i(this, Dr).set(t.h, t);
            var e = _i(this, Fr).get(t.ie);
            e || (e = [], _i(this, Fr).set(t.ie, e)), e.push(t), t.gf(t.trade.Pa), s && i && this.hb()
        }
        Kk(t) {
            t && t.forEach(t => this.tk(t)), this.hb()
        }
        Be(t) {
            var i = t.h;
            i && ((i = this.Ui(i)) ? !(i instanceof Ir) && t instanceof Ir ? this.xi(t, !0) : i.Be(t) : this.xi(t))
        }
        hb() {
            Ri(this, Or, [..._i(this, Dr).values()].sort(S)), Ri(this, xr, [..._i(this, Dr).values()].sort(j))
        }
        Ui(t) {
            return _i(this, Dr).get(t)
        }
        Sg(t) {
            return (t = _i(this, Dr).get(t)) instanceof Ir ? t : null
        }
        Ti(t) {
            for (var i = 0, s = _i(this, Or).length; i <= s;) {
                let e = Math.floor(i + (s - i) / 2),
                    r = _i(this, Or)[e] && _i(this, Or)[e].ta;
                if (r === t) return _i(this, Or)[e];
                r > t ? s = e - 1 : i = e + 1
            }
            return null
        }
        Yk(t) {
            for (var i = 0, s = _i(this, Or).length; i <= s;) {
                let e = Math.floor(i + (s - i) / 2),
                    r = _i(this, Or)[e],
                    a = null == r ? void 0 : r.ta;
                if (a === t && r instanceof Ir) return r;
                a > t ? s = e - 1 : i = e + 1
            }
            return null
        }
        Ff() {
            return [..._i(this, Dr).values()]
        }
        uk() {
            var t = [];
            return _i(this, Dr).forEach(i => {
                i instanceof Ir && t.push(i)
            }), t
        }
    }
    var Dr = new WeakMap,
        Or = new WeakMap,
        xr = new WeakMap,
        Fr = new WeakMap,
        Ur = {
            Ai: B,
            upgrade: function(t, i) {
                return t.forEach(t => {
                    B(t, i)
                }), !0
            },
            apply: $,
            check: L,
            Ln: N
        };
    class Pr {
        constructor(t, i, s, e) {
            Xi(this, qr), Xi(this, _r, new Er), Xi(this, Xr), Xi(this, Rr), Xi(this, Vr), Xi(this, Hr, t => {
                var i = _i(this, Rr).ha(),
                    s = [];
                null == t || t.forEach(t => {
                    t = new Ir(t), s.push(t.h), _i(this, _r).Be(t);
                    var e = _i(this, _r).Sg(t.h);
                    return e && Ur.Ai(e, i.og), t
                }), _i(this, qr).aa(17, s)
            }), Xi(this, Gr, () => {
                var t = _i(this, Rr).ha(),
                    i = this.Uk(),
                    s = new Map(i.map(t => [t.h, {
                        fg: t.trade.Ia,
                        dn: t.trade.Cb,
                        qm: t.trade.zd
                    }]));
                Ur.upgrade(i, t.og), (t = i.filter(t => {
                    var i = s.get(t.h);
                    return (null == i ? void 0 : i.fg) !== t.trade.Ia || i.dn !== t.trade.Cb || i.qm !== t.trade.zd
                })).length && _i(this, qr).aa(17, t.map(t => t.h))
            }), Ri(this, qr, t), Ri(this, Xr, i), Ri(this, Rr, s), Ri(this, Vr, e), _i(this, Xr).V(_i(this, Hr)), _i(this, qr).V(14, _i(this, Gr))
        }
        async init() {
            this.destroy();
            var t = _i(this, Rr).ha();
            t = await _i(this, Xr).Tl(t.Hj > 256), this.fm(t)
        }
        destroy() {
            _i(this, _r).Ea()
        }
        async cd(t) {
            if (t.length) {
                t = await _i(this, Xr).Pl(t);
                var i = _i(this, Rr).ha();
                t && t.forEach(t => {
                    t = new Ir(t), _i(this, _r).Be(t), (t = _i(this, _r).Sg(t.h)) && Ur.Ai(t, i.og)
                })
            }
        }
        fm(t) {
            t = t.map(t => new Nr(t)), _i(this, _r).Kk(t), _i(this, Vr).Di(t)
        }
        Ma(t) {
            return _i(this, _r).Ui(t)
        }
        Ba(t) {
            return _i(this, _r).Sg(t)
        }
        Xi(t) {
            return _i(this, _r).Ti(t)
        }
        Vi(t) {
            return _i(this, _r).Yk(t)
        }
        Ff() {
            return _i(this, _r).Ff()
        }
        Uk() {
            return _i(this, _r).uk()
        }
    }
    var qr = new WeakMap,
        _r = new WeakMap,
        Xr = new WeakMap,
        Rr = new WeakMap,
        Vr = new WeakMap,
        Hr = new WeakMap,
        Gr = new WeakMap,
        Jr = class {
            constructor(t, i, s) {
                if (Xi(this, Kr), Xi(this, Yr), this.maxInstantVolume = this.lotsMax = this.lotsMin = 0, this.lotsStep = 1, this.swapRates = [], this.id = t.ta, this.symbol = t.h, this.description = t.se, this.digits = t.i, this.sector = t.le, this.path = t.Pa, this.pathList = t.zh, this.pathCategory = t.ie, this.delay = 0, Ri(this, Yr, s), Ri(this, Kr, i), this.currencyBase = "", t instanceof Ir) {
                    this.requestTimeout = t.trade.ze, this.requoteTimeout = t.trade.lf, this.ticksBookDepth = t.Bc, this.schedule = {
                        quote_sessions: [...t.ff.Ad],
                        trade_sessions: [...t.ff.Kd]
                    }, this.international = t.Yd, this.isFull = !0, this.multiply = t.te;
                    let s = t.trade;
                    if (this.contractSize = t.I, this.page = t.ue, this.isin = t.be || "", this.category = t.Qd || "", this.exchange = t.we || "", this.isNegativePrices = t.Ta(), t.oa() || (this.spread = t.xb && t.xb > 0 ? t.xb : "floating", this.stopsLevel = s.mf, this.currencyMargin = t.mc, this.currencyBase = t.Gb), this.currencyProfit = t.Aa, this.calcMode = t.ga, this.tradeMode = s.ac, t.oa()) this.marginRateLiqudity = s.Oa, this.tickChartMode = t.jb;
                    else {
                        if ((t.$g() || t.dh()) && (t.Tb && (this.basis = t.Tb), this.tradePriceLimitMin = t.cc, this.tradePriceLimitMax = t.bc), t.dh() && (this.optionType = function(t) {
                                switch (t) {
                                    case 0:
                                    case 2:
                                        return "Call";
                                    case 1:
                                    case 3:
                                        return "Put";
                                    default:
                                        return ""
                                }
                            }(t.Jd), this.optionMode = function(t) {
                                switch (t.Jd) {
                                    case 0:
                                    case 1:
                                        return "European";
                                    case 2:
                                    case 3:
                                        return "American";
                                    default:
                                        return ""
                                }
                            }(t), this.priceStrike = t.ye), t.Jb() || (this.tickSize = t.N, "number" == typeof t.va && (this.tickValue = x(t.va, 8))), t.Hc() && (t.Ka && t.Ka > 0 && (this.faceValue = Number(t.Ka.toFixed(t.Ha))), t.Ob && t.Ob > 0 && (this.accruedInterest = Number(t.Ob.toFixed(t.Ha)))), s.S > 0 && (this.marginInitial = x(s.S, 8)), s.P > 0 && (this.marginMaintenance = x(s.P, 8)), _i(this, Yr) && (4 & s.fe ? this.marginLargeLeg = !0 : s.yc > 0 && (this.marginHedged = x(s.yc, 8))), this.chartMode = t.jb, this.marginRate = function(t) {
                                switch (t) {
                                    case 0:
                                        return "By bid price";
                                    case 1:
                                        return "By last price";
                                    case 255:
                                        return "By default";
                                    default:
                                        return ""
                                }
                            }(t.jb), s.Oa > 0 && (this.trade = s.ac), s.ac > 0) {
                            switch (this.isRequestExecution = s.ia === Sr.uc, this.isInstantExecution = s.ia === Sr.tc, this.isMarketExecution = s.ia === Sr.xa, this.isExchangeExecution = s.ia === Sr.Va, this.gtc = function(t) {
                                    switch (t) {
                                        case 0:
                                            return "Good till cancelled";
                                        case 1:
                                            return "Good till today including SL/TP";
                                        case 2:
                                            return "Good till today excluding SL/TP";
                                        default:
                                            return ""
                                    }
                                }(t.xe), this.isFillingFOK = !!(s.Qa & Br.Qc), this.isFillingIOC = !!(s.Qa & Br.Rc), this.isFillingBOC = !!(s.Qa & Br.nf), s.Qa & Br.Cc) {
                                case Br.NONE:
                                    this.filling = "None";
                                    break;
                                case Br.Cc:
                                    this.filling = "All";
                                    break;
                                default:
                                    this.filling = [Br.Qc, Br.Rc, Br.nf].filter(t => s && s.Qa & t).map(t => function(t) {
                                        switch (t) {
                                            case Br.NONE:
                                                return "None";
                                            case Br.Cc:
                                                return "All";
                                            case Br.Qc:
                                                return "Fill or Kill";
                                            case Br.Rc:
                                                return "Immediate or Cancel";
                                            case Br.nf:
                                                return "Book or Cancel";
                                            default:
                                                return ""
                                        }
                                    }(t)).join(",")
                            }
                            switch (this.isGTCExpiration = !!(s.Pb & $r.sf), this.isDayExpiration = !!(s.Pb & $r.qf), this.isSpecifiedExpiration = !!(s.Pb & $r.wf), this.isSpecifiedDayExpiration = !!(s.Pb & $r.xf), s.Pb & $r.Cc) {
                                case $r.NONE:
                                    this.expiration = "None";
                                    break;
                                case $r.Cc:
                                    this.expiration = "All";
                                    break;
                                default:
                                    this.expiration = [$r.sf, $r.qf, $r.wf, $r.xf].filter(t => s && s.Pb & t).map(t => function(t) {
                                        switch (t) {
                                            case $r.sf:
                                                return "GTC";
                                            case $r.qf:
                                                return "Today";
                                            case $r.wf:
                                                return "Specified";
                                            case $r.xf:
                                                return "Specified day";
                                            default:
                                                return ""
                                        }
                                    }(t)).join(", ")
                            }
                            switch (s.bb & Lr.Cc) {
                                case Lr.NONE:
                                    this.orders = "None";
                                    break;
                                case Lr.Cc:
                                    this.orders = "All";
                                    break;
                                default:
                                    this.orders = [Lr.xa, Lr.uf, Lr.yf, Lr.zf, Lr.gd, Lr.He].filter(t => s && s.bb & t).map(t => function(t) {
                                        switch (t) {
                                            case Lr.xa:
                                                return "Market";
                                            case Lr.uf:
                                                return "Limit";
                                            case Lr.yf:
                                                return "Stop";
                                            case Lr.zf:
                                                return "Stop Limit";
                                            case Lr.gd:
                                                return "Stop Loss";
                                            case Lr.He:
                                                return "Take Profit";
                                            default:
                                                return ""
                                        }
                                    }(t)).join(",")
                            }(null == s ? void 0 : s.bb) && (s.bb & Lr.xa && (this.isOrderMarketAllowed = !0), s.bb & Lr.uf && (this.isOrderLimitAllowed = !0), s.bb & Lr.yf && (this.isOrderStopAllowed = !0), s.bb & Lr.zf && (this.isOrderStopLimitAllowed = !0), s.bb & Lr.gd && (this.isOrderSlAllowed = !0), s.bb & Lr.He && (this.isOrderTpAllowed = !0)), this.lotsMin = I(s.De), this.lotsMax = I(s.Ld), this.maxInstantVolume = I(s.wb), this.lotsStep = I(s.Md), s.Ce > 0 && (this.lotsLimit = D(s.Ce, !0))
                        }
                        for (s.Hd > 0 && (i = function(t) {
                                switch (t.Hd) {
                                    case 1:
                                        return "In points";
                                    case 2:
                                    case 3:
                                    case 4:
                                    default:
                                        return "";
                                    case 5:
                                        return "In percentage terms, using current price";
                                    case 6:
                                        return "In percentage terms, using open price";
                                    case 7:
                                        return "In points, reopen position by close price";
                                    case 8:
                                        return "In points, reopen position by bid price"
                                }
                            }(s), 3 === s.Hd && t.mc && (i = t.mc), 2 === s.Hd && t.Gb && (i = t.Gb), this.swapType = i, this.swapLong = x(s.hg, 8), this.swapShort = x(s.ig, 8), s.re >= 0 && s.re <= 7 && (this.swap3Day = "Sunday Monday Tuesday Wednesday Thursday Friday Saturday Disabled".split(" ")[s.re])), t.Id && (this.timeStart = F(1e3 * t.Id, !0, !1, !1)), i = 0; i < t.trade.qe.length; i++) this.swapRates.push(t.trade.qe[i]);
                        t.ua && (this.timeExpiration = F(1e3 * t.ua, !0, !1, !1))
                    }
                    this.isCollateral = t.oa(), this.isFuture = t.$g(), this.isFORTS = t.qd(), this.isOption = t.dh(), this.isForex = t.Jb(), this.isBond = t.Hc(), this.isTradeEnabled = t.Bl(), this.isCloseByOrderEnabled = t.eh(Lr.pf), t.od() && (this.delay = t.Gd.delay)
                }
            }
            static from(t, i, s) {
                return new Jr(t, i, s)
            }
            isMarketClosed(t = new Date) {
                var i = this.schedule;
                if (i) {
                    let s = _i(this, Kr) - -60 * t.getTimezoneOffset();
                    t = new Date(t);
                    let e = (t = new Date(t.getTime() + 1e3 * s)).getMinutes() + 60 * t.getHours();
                    return (i.trade_sessions[t.getDay()] || []).every(t => !(e >= t[0] && e < t[1]))
                }
                return !1
            }
            marketOpenTime() {
                var t = this.schedule;
                if (t) {
                    if (!this.isMarketClosed()) return 0;
                    let s = _i(this, Kr),
                        e = new Date(Date.now() + 1e3 * s);
                    e.setUTCMilliseconds(0), e.setUTCSeconds(0);
                    let r = e.getUTCMinutes() + 60 * e.getUTCHours();
                    t = t.trade_sessions;
                    for (let a = 0; a < 7; a++) {
                        var i = t[e.getUTCDay()];
                        if (i && (i = 0 === a ? i.find(t => t[0] > r) : i[0])) return e.setUTCHours(Math.floor(i[0] / 60), i[0] % 60, 0, 0), e.getTime() - 1e3 * s;
                        e.setUTCDate(e.getUTCDate() + 1)
                    }
                }
                return 0
            }
        },
        Kr = new WeakMap,
        Yr = new WeakMap,
        Zr = Jr;
    class Qr {
        constructor(t, i) {
            Xi(this, ta), Xi(this, ia), Ri(this, ta, t), Ri(this, ia, i)
        }
        async get(t) {
            var i = _i(this, ta).Ma(t),
                s = _i(this, ia);
            if (i) {
                if (i instanceof Ir) return Zr.from(i, s.Ue(), s.$d());
                if (await _i(this, ta).cd([i.ta]), t = _i(this, ta).Ma(t)) return new Zr(t, s.Ue(), s.$d())
            }
            return null
        }
        all() {
            var t = _i(this, ia);
            return _i(this, ta).Ff().map(i => Zr.from(i, t.Ue(), t.$d()))
        }
        async getMany(t) {
            var i = [],
                s = [],
                e = [];
            t.forEach((t, r) => {
                var a = _i(this, ta).Ma(t);
                a && (a instanceof Ir ? s.push(a) : (s.push(null), e.push({
                    Yg: r,
                    symbol: t
                }), i.push(a.ta)))
            }), i.length && (await _i(this, ta).cd(i), e.forEach(({
                Yg: t,
                symbol: i
            }) => {
                (i = _i(this, ta).Ma(i)) && i instanceof Ir && (s[t] = i)
            })), t = [];
            for (let r = 0; r < s.length; r++) {
                let i = s[r];
                null !== i && t.push(new Zr(i, _i(this, ia).Ue(), _i(this, ia).$d()))
            }
            return t
        }
    }
    var ta = new WeakMap,
        ia = new WeakMap,
        sa = [{
            propType: 11,
            propLength: 64
        }, {
            propType: 11,
            propLength: 128
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 256
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 5
        }],
        ea = Hi.getSeriesSize(sa),
        ra = [{
            propType: 5
        }, {
            propType: 5
        }],
        aa = Hi.getSeriesSize(ra),
        ha = 16 * aa * 7 * 2,
        na = [{
            propType: 6
        }, {
            propType: 4
        }, {
            propType: 4
        }, {
            propType: 5
        }],
        oa = Hi.getSeriesSize(na),
        la = [{
            propType: 11,
            propLength: 64
        }, {
            propType: 11,
            propLength: 32
        }, {
            propType: 11,
            propLength: 128
        }, {
            propType: 11,
            propLength: 128
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 11,
            propLength: 512
        }, {
            propType: 11,
            propLength: 128
        }, {
            propType: 11,
            propLength: 128
        }, {
            propType: 11,
            propLength: 16
        }, {
            propType: 5
        }, {
            propType: 5
        }, {
            propType: 11,
            propLength: 8
        }, {
            propType: 11,
            propLength: 32
        }, {
            propType: 11,
            propLength: 32
        }, {
            propType: 11,
            propLength: 32
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 3
        }, {
            propType: 3
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 3
        }, {
            propType: 3
        }, {
            propType: 12,
            propLength: de,
            parser: m
        }, {
            propType: 12,
            propLength: ha,
            parser: function(t, i = 0) {
                for (var s = {
                        Ad: [],
                        Kd: []
                    }, e = 0; e < 7; e++) {
                    s.Ad[e] = [];
                    for (var r = 0; r < 16; r++) s.Ad[e][r] = q(t, i), i += aa
                }
                for (e = 0; e < 7; e++)
                    for (s.Kd[e] = [], r = 0; r < 16; r++) s.Kd[e][r] = q(t, i), i += aa;
                return s
            }
        }, {
            propType: 12,
            propLength: oa,
            parser: function(t, i) {
                return {
                    delay: (t = Hi.parse(t, na, i))[0],
                    status: t[1],
                    level: t[2],
                    Sn: t[3]
                }
            }
        }],
        ca = Hi.getSeriesSize(la);
    class ua extends Is {
        constructor() {
            super(...arguments), Xi(this, ma), Xi(this, pa, new WeakMap)
        }
        async Tl(t = !0) {
            return t ? Vi(this, ma, da).call(this) : Vi(this, ma, fa).call(this)
        }
        async Pl(t) {
            t = (await this.C.qa(18, T(t))).Z;
            var i = [],
                s = new DataView(t).getUint32(0, !0),
                e = 4;
            for (let r = 0; r < s; r++) i.push(_(t, e)), e += ca;
            return i
        }
        V(t) {
            var i = _i(this, pa).get(t);
            return i || (i = Vi(this, ma, ba).bind(this, t), _i(this, pa).set(t, i)), this.C.V(13, i), this
        }
        da(t) {
            return (t = _i(this, pa).get(t)) && this.C.da(13, t), this
        }
    }
    var pa = new WeakMap,
        ma = new WeakSet,
        fa = async function() {
            return P((await this.C.qa(6)).Z)
        }, da = async function() {
            var t = await this.C.qa(34);
            try {
                let i = await n(),
                    s = new Uint8Array(t.Z.slice(4));
                return P(i.ungzip(s).buffer)
            } catch {
                return Vi(this, ma, fa).call(this)
            }
        }, ba = function(t, i) {
            i = i.Z;
            var s = [],
                e = Math.floor(i.byteLength / ca),
                r = 0;
            for (let a = 0; a < e; a++) s.push(_(i, r)), r += ca;
            t(s)
        };
    class ga {
        constructor(t, i, s, e) {
            this.controller = new Pr(t, new ua(i), e, s), this.view = new Qr(this.controller, e.ha())
        }
    }
    var ya = [{
            propType: 6
        }, {
            propType: 17
        }, {
            propType: 3
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 6
        }, {
            propType: 18
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 17
        }, {
            propType: 6
        }, {
            propType: 17
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 5
        }],
        wa = Hi.getSeriesSize(ya);
    class va extends Is {
        constructor() {
            super(...arguments), Xi(this, Ma), Xi(this, ka, new WeakMap)
        }
        V(t) {
            var i = _i(this, ka).get(t);
            i || (i = Vi(this, Ma, Ta).bind(this, t), _i(this, ka).set(t, i)), this.C.V(17, i)
        }
        da(t) {
            (t = _i(this, ka).get(t)) && this.C.da(17, t)
        }
    }
    var ka = new WeakMap,
        Ma = new WeakSet,
        Ta = function(t, i) {
            i = i.Z;
            var s = [],
                e = Math.floor(i.byteLength / wa),
                r = 0;
            for (let a = 0; a < e; a++) s.push(X(i, r)), r += wa;
            t(s)
        },
        za = [{
            propType: 6
        }, {
            propType: 3
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 17
        }, {
            propType: 6
        }, {
            propType: 5
        }],
        Wa = Hi.getSeriesSize(za);
    class Sa extends Is {
        constructor() {
            super(...arguments), Xi(this, Ba), Xi(this, ja, new WeakMap)
        }
        subscribe(t) {
            return t = T(t), this.C.qa(7, t, !1)
        }
        V(t) {
            var i = _i(this, ja).get(t);
            i || (i = Vi(this, Ba, $a).bind(this, t), _i(this, ja).set(t, i)), this.C.V(8, i)
        }
        da(t) {
            (t = _i(this, ja).get(t)) && this.C.da(8, t)
        }
    }
    var ja = new WeakMap,
        Ba = new WeakSet,
        $a = function(t, i) {
            i = i.Z;
            var s = [],
                e = Math.floor(i.byteLength / Wa);
            for (let r = 0; r < e; r++) s.push(R(i, r * Wa));
            t(s)
        };
    class La {
        constructor(t) {
            this.vd = this.wd = 0n, this.ib = this.Oc = 0, this.id = t.id, this.h = t.h, this.i = t.i, this.high = t.high, this.low = t.low, this.O = t.O, this.L = t.L, this.nb = t.nb, this.Qb = t.Qb, this.Oe = t.Oe ?? !1
        }
        $(t, i) {
            switch (i) {
                case 0:
                    this.wd |= t, this.vd &= ~t;
                    break;
                case 1:
                    this.vd |= t, this.wd &= ~t;
                    break;
                default:
                    this.wd &= ~t, this.vd &= ~t
            }
        }
        jl(t) {
            return this.wd & t ? 0 : this.vd & t ? 1 : 2
        }
    }
    class Na {
        constructor() {
            Xi(this, Ia, new Map), Xi(this, Aa, new Map), Xi(this, Ca, new Set), Xi(this, Ea, new Set), Xi(this, Da, new Map), Xi(this, Oa, new Map)
        }
        Fd(t) {
            _i(this, Ea).clear(), t.forEach(t => _i(this, Ea).add(t))
        }
        Zi() {
            return [..._i(this, Ea)]
        }
        Ph(t) {
            return _i(this, Ca).has(t)
        }
        sk(t) {
            _i(this, Ca).add(t)
        }
        Pk(t) {
            _i(this, Ca).delete(t)
        }
        Ri() {
            return [..._i(this, Ca)]
        }
        Ea() {
            _i(this, Ia).clear(), _i(this, Aa).clear(), _i(this, Da).clear(), _i(this, Ca).clear()
        }
        Wk(t, i) {
            return i ? _i(this, Aa).get(t) : _i(this, Ia).get(t)
        }
        Na(t, i = !1) {
            return i ? _i(this, Oa).get(t) : _i(this, Da).get(t)
        }
        Yi(t, i = !1) {
            var s = i ? _i(this, Aa).get(t.h) : _i(this, Ia).get(t.h);
            return s || (s = new La({
                h: t.h,
                i: t.i,
                id: t.ta,
                high: 0,
                low: 0,
                O: 0,
                L: 0,
                nb: 0,
                Qb: 0n,
                Oe: i
            }), i ? _i(this, Aa).set(t.h, s) : _i(this, Ia).set(t.h, s)), s
        }
        Ej(t, i = !1) {
            i ? _i(this, Aa).set(t.h, t) : _i(this, Ia).set(t.h, t)
        }
        Zk(t, i = !1) {
            var s = i ? _i(this, Oa).get(t) : _i(this, Da).get(t);
            return s || (s = new Set, i ? _i(this, Oa).set(t, s) : _i(this, Da).set(t, s)), s
        }
    }
    var Ia = new WeakMap,
        Aa = new WeakMap,
        Ca = new WeakMap,
        Ea = new WeakMap,
        Da = new WeakMap,
        Oa = new WeakMap,
        xa = BigInt(1) | BigInt(8) | BigInt(64) | BigInt(512);
    class Fa {
        constructor(t, i, s, e, r) {
            Xi(this, Za), Xi(this, Ua), Xi(this, Pa, new Map), Xi(this, qa), Xi(this, _a), Xi(this, Xa), Xi(this, Ra, new Na), Xi(this, Va, new Set), Xi(this, Ha), Xi(this, Ga), Xi(this, Ja, async () => {
                var t = new Set;
                [..._i(this, Ra).Ri(), ..._i(this, Ra).Zi()].forEach(i => {
                    !(i = _i(this, Ha).Ma(i)) || i instanceof Ir || t.add(i.ta)
                }), await _i(this, Ha).cd([...t]);
                var i = new Set;
                [..._i(this, Ra).Ri(), ..._i(this, Ra).Zi()].forEach(t => {
                    (t = _i(this, Ha).Ba(t)) && i.add(t.ta)
                }), _i(this, _a).subscribe([...i])
            }), Xi(this, Ka, t => {
                Vi(this, Za, th).call(this, t)
            }), Xi(this, Ya, t => {
                Vi(this, Za, ih).call(this, t)
            }), Ri(this, qa, t), Ri(this, _a, i), Ri(this, Xa, s), Ri(this, Ha, e), Ri(this, Ga, r), Ri(this, Ja, _i(this, Ja).bind(this)), _i(this, _a).V(_i(this, Ka)), _i(this, Xa).V(_i(this, Ya))
        }
        Fd(t = []) {
            _i(this, Ra).Fd(t), _i(this, Ga).Sl(t)
        }
        destroy() {
            _i(this, _a).da(_i(this, Ka)), _i(this, Xa).da(_i(this, Ya)), _i(this, Ra).Ea(), _i(this, Va).clear(), _i(this, Pa).clear()
        }
        sign(t) {
            t && _i(this, Ha).Ma(t) && !_i(this, Ra).Ph(t) && (_i(this, Ra).sk(t), clearTimeout(_i(this, Ua)), Ri(this, Ua, setTimeout(_i(this, Ja), 500)))
        }
        rn(t) {
            t && _i(this, Ra).Ph(t) && (_i(this, Ra).Pk(t), clearTimeout(_i(this, Ua)), Ri(this, Ua, setTimeout(_i(this, Ja), 500)))
        }
        V(t, i) {
            var s = _i(this, Pa).get(t);
            s || (s = new Set, _i(this, Pa).set(t, s)), s.add(i)
        }
        da(t, i) {
            if (_i(this, Pa).has(t))
                if (void 0 === i) _i(this, Pa).delete(t);
                else {
                    let s = _i(this, Pa).get(t);
                    s ? s.delete(i) : _i(this, Pa).delete(t)
                }
        }
        ad(t, i) {
            return _i(this, Ra).Wk(t, i)
        }
        $k(t) {
            return _i(this, Ra).Na(t)
        }
        yl(t) {
            return _i(this, Ra).Ph(t)
        }
    }
    var Ua = new WeakMap,
        Pa = new WeakMap,
        qa = new WeakMap,
        _a = new WeakMap,
        Xa = new WeakMap,
        Ra = new WeakMap,
        Va = new WeakMap,
        Ha = new WeakMap,
        Ga = new WeakMap,
        Ja = new WeakMap,
        Ka = new WeakMap,
        Ya = new WeakMap,
        Za = new WeakSet,
        Qa = function(t, i) {
            (t = _i(this, Pa).get(t)) && t.forEach(t => t(i))
        },
        th = function(t) {
            t && t.forEach(t => {
                var i = !!(512 & t.flags),
                    s = t.ta;
                if (s = _i(this, Ha).Xi(s)) {
                    var e = _i(this, Ra).Yi(s, i);
                    if (_i(this, Va).has(s.h)) {
                        var r = s.i,
                            a = t.fields;
                        if (!(t.Oc > Date.now() + 2592e6 || e.hh && t.ib < e.hh && (1 & a || 2 & a) || e.kj && t.ib < e.kj && 4 & a)) {
                            if (e.Oc = Math.max(t.Oc, e.Oc), e.ib = Math.max(t.ib, e.ib), e.Dl = !1, null == e.fields && (e.fields = 0), e.fields = K(e.fields, 1, !1), e.fields = K(e.fields, 2, !1), e.fields = K(e.fields, 4, !1), e.fields = K(e.fields, 8, !1), 1 & a) {
                                var n = h.toDouble(t.O, r);
                                s instanceof Ir && s.cj() || e.$(BigInt(64), Z(n, e.hd)), e.$(BigInt(1), Z(n, e.hd)), e.hd = n, e.yb = n, e.hh = t.ib, e.fields = K(e.fields, 1, !0), s instanceof Ir && e.D && 0 === s.jb && Y(s, e)
                            }
                            if (2 & a && (n = h.toDouble(t.L, r), s instanceof Ir && s.cj() || e.$(BigInt(64), Z(n, e.Pd)), e.$(BigInt(8), Z(n, e.Pd)), e.Pd = n, e.hh = t.ib, e.fields = K(e.fields, 2, !0)), 4 & a && (r = h.toDouble(t.Na, r), e.$(BigInt(64), Z(r, e.nb)), e.nb = r, e.Na = r, e.kj = t.ib, e.fields = K(e.fields, 4, !0), s instanceof Ir && e.D && 1 === s.jb && Y(s, e)), 8 & a && (t = t.mn, e.$(BigInt(512), Q(t, e.Qb)), e.Qb = t, e.fields = K(e.fields, 8, !0)), e.O = (null == e ? void 0 : e.hd) ?? e.O, e.L = (null == e ? void 0 : e.Pd) ?? e.L, s instanceof Ir && s.trade.Ia) {
                                if (!(t = H((t = s.trade).Ia, t.Cb, s.Ga || 0, s.i, e.O, e.L)).result) return;
                                e.O = t.O, e.L = t.L
                            }
                            e.yb = e.O, e.fc = e.L, (t = _i(this, Ra).Zk(s.h, i)) && (a = t.add, r = new La({
                                h: e.h,
                                i: e.i,
                                id: e.id,
                                high: e.high,
                                low: e.low,
                                O: e.O,
                                L: e.L,
                                nb: e.nb,
                                Qb: e.Qb,
                                Oe: e.Oe
                            }), Object.assign(r, e), a.call(t, r), t.size > 125 && ((a = t.values().next()).done || t.delete(a.value))), _i(this, Ra).Ej(e, i), Vi(this, Za, Qa).call(this, s.h, e), _i(this, qa).aa(0, [s.h, i])
                        }
                    }
                }
            })
        },
        ih = function(t) {
            t && t.forEach(t => {
                var i = t.ta,
                    s = !!(1 & t.flags);
                if ((i = _i(this, Ha).Xi(i)) && i instanceof Ir && !(t.Mf > Date.now() + 2592e6)) {
                    var e = _i(this, Ra).Yi(i, s),
                        r = e.i,
                        a = i.trade,
                        n = t.fields;
                    e.fields = 0, e.Oc = e.Oc ? Math.max(t.Mf, e.Oc) : t.Mf;
                    var o = t.lj > 0n ? Number(t.lj) : t.Mf;
                    e.ib = e.ib ? Math.max(o, e.ib) : o, e.Dl = !0, e.Mn = !0, n & BigInt(1) && (o = h.toDouble(t.yb, r), e.$(BigInt(1), Z(o, e.yb)), e.yb = o, e.hd = o, e.O = o, e.fields |= 1, e.D && 0 === i.jb && Y(i, e)), n & BigInt(2) && (o = h.toDouble(t.Wc, r), e.$(BigInt(2), Z(o, e.Wc)), e.Wc = o, a && a.Ia && (e.Wc = G(a.Ia, a.Cb, i.Ga || 0, i.i, e.Wc), !i.Ta() && e.Wc <= 0 && (e.Wc = o))), n & BigInt(4) && (o = h.toDouble(t.Xc, r), e.$(BigInt(4), Z(o, e.Xc)), e.Xc = o, a && a.Ia && (e.Xc = G(a.Ia, a.Cb, i.Ga || 0, i.i, e.Xc), !i.Ta() && e.Xc <= 0 && (e.Xc = o))), n & BigInt(8) && (o = h.toDouble(t.fc, r), e.$(BigInt(8), Z(o, e.fc)), e.fc = o, e.Pd = o, e.L = o, e.fields |= 2), n & BigInt(16) && (o = h.toDouble(t.Uc, r), e.$(BigInt(16), Z(o, e.Uc)), e.Uc = o, a && a.Ia && (e.Uc = J(a.Ia, a.Cb, i.Ga || 0, i.i, e.Uc), !i.Ta() && e.Uc <= 0 && (e.Uc = o))), n & BigInt(32) && (o = h.toDouble(t.Vc, r), e.$(BigInt(32), Z(o, e.Vc)), e.Vc = o, a && a.Ia && (e.Vc = J(a.Ia, a.Cb, i.Ga || 0, i.i, e.Vc), !i.Ta() && e.Vc <= 0 && (e.Vc = o))), n & BigInt(64) && (o = h.toDouble(t.nb, r), e.$(BigInt(64), Z(o, e.nb)), e.nb = o, e.Na = o, e.fields |= 4, e.D && 1 === i.jb && Y(i, e)), n & BigInt(128) && (o = h.toDouble(t.Kf, r), e.$(BigInt(128), Z(o, e.Kf)), e.Kf = o), n & BigInt(256) && (o = h.toDouble(t.Lf, r), e.$(BigInt(256), Z(o, e.Lf)), e.Lf = o), n & BigInt(512) && (e.$(BigInt(512), Q(t.Qb, e.Qb)), e.Qb = t.Qb, e.fields |= 8), n & BigInt(1024) && (e.$(BigInt(1024), Q(t.sg, e.sg)), e.sg = t.sg), n & BigInt(2048) && (e.$(BigInt(2048), Q(t.tg, e.tg)), e.tg = t.tg), n & BigInt(65536) && (e.Mj = t.Mj), n & BigInt(131072) && (e.l = t.l), n & BigInt(262144) && (e.Oj = t.Oj), n & BigInt(524288) && (e.Nj = t.Nj), n & BigInt(16384) && (e.$(BigInt(16384), Z(t.kg, e.kg)), e.kg = t.kg), n & BigInt(4096) && (e.$(BigInt(4096), Q(t.lg, e.lg)), e.lg = t.lg), n & BigInt(32768) && (e.$(BigInt(32768), Z(t.mg, e.mg)), e.mg = t.mg), n & BigInt(8192) && (e.$(BigInt(8192), Q(t.ng, e.ng)), e.ng = t.ng), n & BigInt(1048576) && (e.$(BigInt(1048576), 2), e.sa = h.toDouble(t.sa, r)), n & BigInt(2097152) && (e.$(BigInt(2097152), 2), e.D = h.toDouble(t.D, r), e.D && Y(i, e)), n & BigInt(4194304) && (o = h.toDouble(t.Ch, r), e.$(BigInt(4194304), Z(o, e.Ch)), e.Ch = o), n & BigInt(16777216) && (o = h.toDouble(t.Lh, 3), e.$(BigInt(16777216), Z(o, e.Lh)), e.Lh = o), n & BigInt(33554432) && (r = h.toDouble(t.Kh, r), e.$(BigInt(33554432), Z(r, e.Kh)), e.Kh = r), n & BigInt(17179869184) && (r = h.toDouble(Number(t.Dh), 5), e.$(BigInt(17179869184), Z(r, e.Dh)), e.Dh = r), n & BigInt(34359738368) && (r = h.toDouble(Number(t.Hh), 5), e.$(BigInt(34359738368), Z(r, e.Hh)), e.Hh = r), n & BigInt(68719476736) && (r = h.toDouble(Number(t.Eh), 5), e.$(BigInt(68719476736), Z(r, e.Eh)), e.Eh = r), n & BigInt(137438953472) && (r = h.toDouble(Number(t.Ih), 5), e.$(BigInt(137438953472), Z(r, e.Ih)), e.Ih = r), n & BigInt(274877906944) && (r = h.toDouble(Number(t.Gh), 5), e.$(BigInt(274877906944), Z(r, e.Gh)), e.Gh = r), n & BigInt(549755813888) && (r = h.toDouble(Number(t.Fh), 5), e.$(BigInt(549755813888), Z(r, e.Fh)), e.Fh = r), n & BigInt(1099511627776) && (r = h.toDouble(Number(t.Jh), 5), e.$(BigInt(1099511627776), Z(r, e.Jh)), e.Jh = r), r = e.hd, o = e.Pd, r && o && (t.yb || t.fc) && a.Ia && (e.yb = r, e.fc = o, (t = H(a.Ia, a.Cb, i.Ga || 0, i.i, e.yb, e.fc)).result && (e.yb = t.O, e.fc = t.L)), _i(this, Ra).Ej(e, s), i.od() === s && _i(this, Va).add(i.h), n & xa && Vi(this, Za, Qa).call(this, i.h, e), _i(this, qa).aa(0, [i.h, s])
                }
            })
        };
    class sh {
        constructor(t) {
            Xi(this, rh), Xi(this, eh), Ri(this, eh, t)
        }
        getTick(t, i) {
            return t = _i(this, eh).ad(t, i), Vi(this, rh, ah).call(this, t)
        }
        subscribe(t) {
            _i(this, eh).sign(t)
        }
        unSubscribe(t) {
            _i(this, eh).rn(t)
        }
        signed(t) {
            return _i(this, eh).yl(t)
        }
    }
    var eh = new WeakMap,
        rh = new WeakSet,
        ah = function(t) {
            if (!t) return null;
            if (t.ib) var i = t.ib;
            else {
                var s = new Date;
                s.setUTCHours(0), s.setUTCMinutes(0, 0, 0), i = s.getTime()
            }
            s = t.h;
            var e = t.Oc,
                r = t.yj ?? null,
                a = t.O ?? 0,
                h = tt(t, BigInt(1)),
                n = t.yb ?? 0,
                o = t.Wc ?? 0,
                l = tt(t, BigInt(2)),
                c = t.Xc ?? 0,
                u = tt(t, BigInt(4)),
                p = t.hd ?? 0,
                m = t.L ?? 0,
                f = tt(t, BigInt(8)),
                d = t.fc ?? 0,
                b = t.Uc ?? 0,
                g = tt(t, BigInt(16)),
                y = t.Vc ?? 0,
                w = tt(t, BigInt(32)),
                v = t.Pd ?? 0,
                k = t.Na ?? 0,
                M = t.nb || 0,
                T = t.Kf || 0,
                z = t.Lf || 0,
                W = tt(t, BigInt(64)),
                S = D(t.Qb),
                j = tt(t, BigInt(512)),
                B = t.i,
                $ = t.fc,
                L = t.yb;
            return {
                symbol: s,
                time: e,
                timeMs: i,
                change: r,
                bid: a,
                bidTrend: h,
                bidLast: n,
                bidHigh: o,
                bidHighTrend: l,
                bidLow: c,
                bidLowTrend: u,
                bidOriginal: p,
                ask: m,
                askTrend: f,
                askLast: d,
                askHigh: b,
                askHighTrend: g,
                askLow: y,
                askLowTrend: w,
                askOriginal: v,
                last: k,
                lastLast: M,
                lastHigh: T,
                lastLow: z,
                lastTrend: W,
                volume: S,
                volumeTrend: j,
                spread: $ && L ? Math.round(($ - L) * 10 ** B) : null,
                fields: t.fields || 0,
                volLast: D(t.Qb),
                delayed: t.Oe,
                priceOpen: t.sa ?? 0,
                priceClose: t.D ?? 0,
                low: t.low ?? 0,
                high: t.high ?? 0
            }
        };
    class hh {
        constructor(t, i, s, e) {
            this.controller = new Fa(t, new Sa(i), new va(i), s, e), this.view = new sh(this.controller)
        }
    }
    class nh {
        constructor(t, i) {
            Xi(this, ph), Xi(this, oh, new Map), Xi(this, lh, new Set), Xi(this, ch), Xi(this, uh), Ri(this, uh, i), Ri(this, ch, t)
        }
        ee(t) {
            var i = _i(this, ch).Ma(t);
            return i ? ((t = _i(this, ch).Ba(t)) || _i(this, ch).cd([i.ta]), t) : null
        }
        sc(t, i, s) {
            return i && s ? Vi(this, ph, mh).call(this, i, s) ? 1 : Vi(this, ph, fh).call(this, i, s, t, void 0) || (i = Vi(this, ph, fh).call(this, i, "USD", t, void 0), t = Vi(this, ph, fh).call(this, "USD", s, t, void 0), i && t ? t * i : 0) : 0
        }
        Kc(t, i, s) {
            return i && s ? Vi(this, ph, mh).call(this, i, s) ? 1 : Vi(this, ph, dh).call(this, i, s, t, void 0) || (i = Vi(this, ph, dh).call(this, i, "USD", t, void 0), t = Vi(this, ph, dh).call(this, "USD", s, t, void 0), i && t ? t * i : 0) : 0
        }
        Zf(t, i, s) {
            var e = t.mc;
            return e && i ? Vi(this, ph, mh).call(this, e, i) ? 1 : Vi(this, ph, bh).call(this, e, i, t, s) || (e = Vi(this, ph, bh).call(this, e, "USD", t, s), t = Vi(this, ph, bh).call(this, "USD", i, t, s), e && t ? t * e : 0) : 0
        }
        $f(t, i, s) {
            var e = t.mc;
            return e && i ? Vi(this, ph, mh).call(this, e, i) ? 1 : Vi(this, ph, gh).call(this, e, i, t, s) || (e = Vi(this, ph, gh).call(this, e, "USD", t, s), t = Vi(this, ph, gh).call(this, "USD", i, t, s), e && t ? t * e : 0) : 0
        }
        md(t, i = !1) {
            var s = 0;
            return i && (s = this.Ni(t, !1)), s <= 0 && (t = Vi(this, ph, yh).call(this, t)) && (s = this.Ni(t, !0)), s
        }
        ld(t, i = !1) {
            var s = 0;
            return i && (s = Vi(this, ph, wh).call(this, t, !1)), s <= 0 && (t = Vi(this, ph, yh).call(this, t)) && (s = Vi(this, ph, wh).call(this, t, !0)), s
        }
        Ni(t, i) {
            Vi(this, ph, Th).call(this, t);
            var [s, e] = this.Ef(t);
            return 0 === e && W(s.jd) ? s.O : (i && 13 === e && _i(this, lh).add(t), 0)
        }
        Vl(t) {
            var [i, s] = Vi(this, ph, vh).call(this, t);
            return [i, 0 === s]
        }
        Ef(t) {
            var i = _i(this, ch).Ma(t);
            return i ? (t = _i(this, ch).Ba(t)) ? (i = _i(this, uh).ad(t.h, !1)) ? [{
                L: i.L,
                O: i.O,
                Na: i.nb,
                jd: t.ga
            }, 0] : [{
                L: 0,
                O: 0,
                Na: 0,
                jd: t.ga
            }, 10021] : (_i(this, ch).cd([i.ta]), [{
                L: 0,
                O: 0,
                Na: 0,
                jd: 0
            }, 1e3]) : [{
                L: 0,
                O: 0,
                Na: 0,
                jd: 0
            }, 13]
        }
    }
    var oh = new WeakMap,
        lh = new WeakMap,
        ch = new WeakMap,
        uh = new WeakMap,
        ph = new WeakSet,
        mh = function(t, i) {
            if (t === i) return !0;
            var s = [
                ["RUB", "RUR"]
            ];
            for (let e = 0, r = s.length; e < r; e++) {
                let r = s[e];
                if (r && r.includes(t) && r.includes(i)) return !0
            }
            return !1
        },
        fh = function(t, i, s, e) {
            var [{
                Nc: r,
                Fc: a
            }, h] = Vi(this, ph, kh).call(this, {
                from: t,
                to: i,
                config: s
            });
            if (h) {
                if (e && s && s.Jb() && !(s.Db & jr.Fe) && r === s.h) return e;
                let t = this.ld(r, a);
                if (0 !== t) return t
            }
            if ([{
                    Nc: r,
                    Fc: a
                }, h] = Vi(this, ph, kh).call(this, {
                    from: i,
                    to: t,
                    config: s
                }), h) {
                if (s && e && s.Jb() && !(s.Db & jr.Fe) && r === s.h) return 1 / e;
                if ((t = this.md(r, a)) > 0) return 1 / t
            }
            return 0
        },
        dh = function(t, i, s, e) {
            var [{
                Nc: r,
                Fc: a
            }, h] = Vi(this, ph, kh).call(this, {
                from: t,
                to: i,
                config: s
            });
            if (h) {
                if (s && e && s.Jb() && !(s.Db & jr.Fe) && r === s.h) return e;
                let t = this.md(r, a);
                if (t > 0) return t
            }
            if ([{
                    Nc: r,
                    Fc: a
                }, h] = Vi(this, ph, kh).call(this, {
                    from: i,
                    to: t,
                    config: s
                }), h) {
                if (s && e && s.Jb() && !(s.Db & jr.Fe) && r === s.h) return 1 / e;
                if ((t = this.ld(r, a)) > 0) return 1 / t
            }
            return 0
        },
        bh = function(t, i, s, e) {
            var [{
                Nc: r,
                Fc: a
            }, h] = Vi(this, ph, kh).call(this, {
                from: t,
                to: i,
                config: s
            });
            if (h) {
                if (e && s.Jb() && r === s.h) return e;
                let t = this.ld(r, a);
                if (t > 0) return t
            }
            if ([{
                    Nc: r,
                    Fc: a
                }, h] = Vi(this, ph, kh).call(this, {
                    from: i,
                    to: t,
                    config: s
                }), h) {
                if (e && s.Jb() && r === s.h) return 1 / e;
                if ((t = this.md(r, a)) > 0) return 1 / t
            }
            return 0
        },
        gh = function(t, i, s, e) {
            var [{
                Nc: r,
                Fc: a
            }, h] = Vi(this, ph, kh).call(this, {
                from: t,
                to: i,
                config: s
            });
            if (h) {
                if (e && s.Jb() && r === s.h) return e;
                let t = this.md(r, a);
                if (t > 0) return t
            }
            if ([{
                    Nc: r,
                    Fc: a
                }, h] = Vi(this, ph, kh).call(this, {
                    from: i,
                    to: t,
                    config: s
                }), h) {
                if (e && s.Jb() && r === s.h) return 1 / e;
                if ((t = this.ld(r, a)) > 0) return 1 / t
            }
            return 0
        },
        yh = function(t) {
            var i = _i(this, oh).get(t);
            return i || (_i(this, lh).has(t) ? null : ((i = _i(this, ch).Ff().filter(i => Vi(this, ph, Mh).call(this, t, i))).sort((t, i) => t.h > i.h ? 1 : t.h < i.h ? -1 : 0), i && i.length ? (i = i[0].h, _i(this, oh).set(t, i), i) : (_i(this, lh).add(t), null)))
        },
        wh = function(t, i) {
            Vi(this, ph, Th).call(this, t);
            var [s, e] = this.Ef(t);
            return 0 === e && W(s.jd) ? s.L : (i && 13 === e && _i(this, lh).add(t), _i(this, uh).sign(t), 0)
        },
        vh = function(t) {
            var [i, s] = this.Ef(t);
            return 0 === s ? [i, 0] : _i(this, ch).Ma(t) ? (_i(this, uh).sign(t), [{
                L: 0,
                O: 0,
                Na: 0,
                jd: 0
            }, 10021]) : [{
                L: 0,
                O: 0,
                Na: 0,
                jd: 0
            }, 13]
        },
        kh = function(t) {
            var i = t.from,
                s = t.to;
            t = t.config;
            var e = "",
                r = !1;
            return i && s && t ? (e += i.substring(0, 3), e += s.substring(0, 3), (null == t ? void 0 : t.Jb()) && (r = !0, t.h[6] && (e += t.h.substring(6))), [{
                Nc: e,
                Fc: r
            }, !_i(this, lh).has(e)]) : [{
                Nc: e,
                Fc: r
            }, !1]
        },
        Mh = function(t, i) {
            return i.Jb() && i.h.startsWith(t.substring(0, 6))
        },
        Th = function(t) {
            if (!_i(this, ch).Ba(t)) {
                let i = _i(this, ch).Ma(t);
                i && _i(this, ch).cd([i.ta])
            }
            _i(this, uh).sign(t)
        };
    class zh {
        constructor(t, i) {
            this.controller = new nh(t, i)
        }
    }
    class Wh {
        constructor(t, i) {
            this.account = t, this.prices = i
        }
    }
    class Sh {
        constructor(t, i, s, e) {
            this.Ud = 0, this.Of = t, this.Pf = i, this.Qf = s, this.Rf = e
        }
        Ea() {
            this.Of.Ub(), this.Pf.Ub(), this.Qf.Ub(), this.Rf.Ub(), delete this.Zb, delete this.dm, this.Ud = 0
        }
    }
    var jh = {
        ti: 0,
        ui: 1,
        Ie: 2,
        si: 3
    };
    class Bh {
        constructor(t, i) {
            Xi(this, Ih), Xi(this, $h), Xi(this, Lh), Xi(this, Nh, []), Ri(this, $h, t), Ri(this, Lh, i), Ri(this, Nh, [])
        }
        Ea() {
            Ri(this, Nh, [])
        }
        zi(t) {
            return !(_i(this, Lh) && !Ur.check(_i(this, Lh).path, t.symbol.Pa) || (t.Ym(_i(this, Lh)), _i(this, Nh).push(t), 0))
        }
        Wa() {
            if (_i(this, Lh) && _i(this, Lh).ab.length) switch (_i(this, Lh).zj) {
                case jh.ti:
                    return Vi(this, Ih, Ah).call(this, _i(this, Lh));
                case jh.ui:
                    return Vi(this, Ih, Ch).call(this, _i(this, Lh));
                case jh.Ie:
                    return Vi(this, Ih, Eh).call(this, _i(this, Lh));
                case jh.si:
                    return Vi(this, Ih, Dh).call(this, _i(this, Lh));
                default:
                    return 0
            }
            var t = _i(this, $h).j;
            return _i(this, Nh).reduce((i, e) => (e = e.Wa(), s.normalize(i + e, t)), 0)
        }
    }
    var $h = new WeakMap,
        Lh = new WeakMap,
        Nh = new WeakMap,
        Ih = new WeakSet,
        Ah = function(t) {
            var i, e = _i(this, $h),
                r = {
                    ub: 0,
                    Rb: 0
                },
                a = 0,
                h = 0,
                n = 0;
            if (_i(this, Nh).forEach(t => {
                    t.Wa(), i = I(t.Ab), h += i, n += t.Kb, t.bd(i)
                }), h && n) {
                var o = Vi(this, Ih, Oh).call(this, t, r, h, n, !1, e.j);
                a += s.normalize(a + o, e.j)
            }
            var l = 0,
                c = 0;
            _i(this, Nh).forEach(t => {
                i = I(t.xc), l += i, c += t.Wb, t.bd(i)
            }), l && c && (o = Vi(this, Ih, Oh).call(this, t, r, l, c, !0, e.j), a = s.normalize(a + o, e.j));
            var u = 0,
                p = 0;
            return _i(this, Nh).forEach(t => {
                i = I(t.Ua), u += i, p += t.ob, t.bd(i)
            }), u && p && (o = Vi(this, Ih, Oh).call(this, t, r, u, p, !0, e.j), a = s.normalize(a + o, e.j)), a
        },
        Ch = function(t) {
            var i, e = _i(this, $h),
                r = 0;
            return _i(this, Nh).forEach(a => {
                var h = {
                    ub: 0,
                    Rb: 0
                };
                a.Wa(), a.Ab && a.Kb && (i = st(t, h, I(a.Ab), a.Kb, !1, e.j), r = s.normalize(r + i, e.j)), a.xc && a.Wb && (i = st(t, h, I(a.xc), a.Wb, !0, e.j), r = s.normalize(r + i, e.j)), a.Ua && a.ob && (i = st(t, h, I(a.Ua), a.ob, !0, e.j), r = s.normalize(r + i, e.j))
            }), r
        },
        Eh = function(t) {
            var i, e = _i(this, $h),
                r = {
                    ub: 0,
                    Rb: 0
                },
                a = 0,
                h = 0,
                n = 0;
            if (_i(this, Nh).forEach(t => {
                    t.Wa(), i = t.oh(), h += i, n += t.Kb, t.bd(i)
                }), h && n) {
                var o = Vi(this, Ih, Oh).call(this, t, r, h, n, !1, e.j);
                a = s.normalize(a + o, e.j)
            }
            var l = 0,
                c = 0;
            _i(this, Nh).forEach(t => {
                i = t.nh(), l += i, c += t.Wb, t.bd(i)
            }), l && c && (o = Vi(this, Ih, Oh).call(this, t, r, l, c, !0, e.j), a = s.normalize(a + o, e.j));
            var u = 0,
                p = 0;
            return _i(this, Nh).forEach(t => {
                i = t.mh(), u += i, p += t.ob, t.bd(i)
            }), u && p && (o = Vi(this, Ih, Oh).call(this, t, r, u, p, !0, e.j), a = s.normalize(a + o, e.j)), a
        },
        Dh = function(t) {
            var i, e = _i(this, $h),
                r = 0;
            return _i(this, Nh).forEach(a => {
                var h = {
                    ub: 0,
                    Rb: 0
                };
                a.Wa(), a.oh() && a.Kb && (i = st(t, h, a.oh(), a.Kb, !1, e.j), r = s.normalize(r + i, e.j)), a.nh() && a.Wb && (i = st(t, h, a.nh(), a.Wb, !0, e.j), r = s.normalize(r + i, e.j)), a.mh() && a.ob && (i = st(t, h, a.mh(), a.ob, !0, e.j), r = s.normalize(r + i, e.j))
            }), r
        },
        Oh = function(t, i, e, r, a, n) {
            var o = 1;
            _i(this, Nh).forEach((t, i) => {
                t.bd() ? i < _i(this, Nh).length - 1 ? (i = t.bd() / e, t.We(i), o -= i) : t.We(o) : t.We(0)
            });
            for (var l = e, c = 0; i.ub < t.ab.length;) {
                let o = t.ab[i.ub];
                if (o.Cd === h.FLOAT64_MAX || o.Bd === h.FLOAT64_MAX) break;
                let u = o.Cd - o.Bd;
                if (u > 0) {
                    i.Rb && (u = Math.min(i.Rb, u)), l < u ? (i.Rb = u - l, u = l) : i.Rb = 0;
                    let t = u / e * r,
                        h = 0;
                    if (_i(this, Nh).forEach(i => {
                            i.We() && (i = t * i.We() * (a ? o.Ye : o.Ze), h += i)
                        }), c = s.normalize(c + h, n), u >= l) {
                        l = 0, i.Rb || (i.ub += 1);
                        break
                    }
                    l -= u
                }
                i.ub += 1
            }
            return l && (c = s.normalize(c + l / e * r * (a ? t.ab[t.ab.length - 1].Ye : t.ab[t.ab.length - 1].Ze), n)), c
        };
    class xh {
        constructor(t, i) {
            Xi(this, Ph), Xi(this, Fh), Xi(this, Uh), Ri(this, Fh, []), Ri(this, Uh, {}), this.ud = [], this.account = t, this.prices = i, this.Nf = new Bh(this.account)
        }
        at(t) {
            return _i(this, Fh)[t]
        }
        wc(t) {
            _i(this, Fh).forEach(t)
        }
        Gg(t) {
            _i(this, Fh).push(t), _i(this, Uh)[t.getName()] = t
        }
        Qi() {
            return [..._i(this, Fh)]
        }
        Wd(t) {
            if (t) return this.Pe(t) ?? Vi(this, Ph, qh).call(this, t)
        }
        Me(t) {
            return t = this.Td(t), this.Gg(t), Vi(this, Ph, Xh).call(this, t), t
        }
        Pe(t) {
            return _i(this, Uh)[t] ?? _i(this, Fh).find(i => i.getName() === t)
        }
        Pm() {
            Ri(this, Fh, []), Ri(this, Uh, {}), this.ud = [], this.Nf.Ea()
        }
        Ub() {
            this.Pm()
        }
        Ve() {
            return _i(this, Fh).length
        }
        ja() {
            var t = this.Nf.Wa();
            for (let i = 0; i < this.ud.length; i++) t = s.normalize(t + this.ud[i].Wa(), this.account.j);
            return t
        }
    }
    var Fh = new WeakMap,
        Uh = new WeakMap,
        Ph = new WeakSet,
        qh = function(t) {
            if (t = this.prices.ee(t)) return this.Me(t)
        },
        _h = function() {
            this.ud = this.account.rules.map(t => new Bh(this.account, t)), this.Nf = new Bh(this.account)
        },
        Xh = function(t) {
            !this.ud.length && this.account.rules.length && Vi(this, Ph, _h).call(this);
            for (let i = 0; i < this.ud.length; i++)
                if (this.ud[i].zi(t)) return;
            this.Nf.zi(t)
        };
    class Rh {
        constructor(t, i, s) {
            this.xc = this.Ab = 0n, this.rd = this.Wb = this.Kb = this.qh = this.rh = this.sd = 0, this.Ua = 0n, this.pj = this.oj = this.pb = this.ob = this.ph = this.qb = 0, this.account = t, this.symbol = i, this.prices = s
        }
        getName() {
            return this.symbol.h
        }
        Tb() {
            return this.symbol.Tb
        }
        Fa(t, i) {
            return this.symbol.Fa(t, i)
        }
        oa() {
            return this.symbol.oa()
        }
        ah() {
            return this.symbol.ah()
        }
        qd() {
            return this.symbol.qd()
        }
        Hc() {
            return this.symbol.Hc()
        }
        Jf() {
            return this.symbol.Jf()
        }
        Zg() {
            return !!this.td
        }
        Ym(t) {
            this.td = t
        }
        oh() {
            return this.rh || (this.rh = this.kh(this.Ab, this.Kb, this.sd, this.rd)), this.rh
        }
        nh() {
            return this.qh || (this.qh = this.kh(this.xc, this.Wb, this.sd, this.rd)), this.qh
        }
        mh() {
            return this.ph || (this.ph = this.kh(this.Ua, this.ob, this.qb, this.pb)), this.ph
        }
        We(t) {
            if ("number" != typeof t) return this.oj;
            this.oj = t
        }
        bd(t) {
            if (!t) return this.pj;
            this.pj = t
        }
        kh(t, i, e, r) {
            return t && i ? (t = this.kc(0, t, A(t, this.symbol.I), e), i = 1, e = this.account.j, this.td && (this.symbol.Gb !== this.symbol.mc || "" !== this.td.Yf && this.account.ra !== this.td.Yf ? (i = this.td.Yf[0] ? this.prices.sc(this.symbol, this.symbol.Gb, this.td.Yf) : this.prices.sc(this.symbol, this.symbol.Gb, this.account.ra), e = this.td.Km) : i = r), s.normalize(t * i, e)) : 0
        }
        kc(t, i, e, r) {
            var a = this.symbol,
                h = this.prices;
            switch (a.ga) {
                case 0:
                case 5:
                    return e;
                case 1:
                case 33:
                case 34:
                    return a.N && a.va ? (e = I(i), s.normalize(e * r * a.va / a.N, a.Ha)) : 0;
                case 2:
                case 3:
                case 4:
                case 32:
                case 38:
                case 35:
                case 36:
                case 64:
                    return s.normalize(e * r, a.zb);
                case 37:
                case 39:
                    return r = s.normalize(e * a.Ka * r / 100, a.Ha), t = 0 === t ? h.sc(a, a.Gb, a.Aa) : h.Kc(a, a.Gb, a.Aa), r = s.normalize(r * t, a.zb), e = s.normalize(e * a.Ob, a.zb), s.normalize(r + e, a.zb);
                default:
                    return 0
            }
        }
    }
    class Vh extends Rh {
        vl() {
            return 32 !== this.symbol.ga && 35 !== this.symbol.ga && 36 !== this.symbol.ga && 37 !== this.symbol.ga && 38 !== this.symbol.ga && 39 !== this.symbol.ga
        }
    }
    class Hh extends Vh {
        constructor() {
            super(...arguments), Xi(this, Gh, 0), Xi(this, Jh, 0), Xi(this, Kh, 0), Xi(this, Yh, 0n), Xi(this, Zh, 0), Xi(this, Qh, 0), Xi(this, tn, 0), Xi(this, sn, 0), Xi(this, en, 0), Xi(this, rn, h.FLOAT64_MAX), Xi(this, an, 0), Xi(this, hn, 0), Xi(this, nn, 0), Xi(this, on, 0), Xi(this, ln, 0), Xi(this, cn, 0), Xi(this, un, 0), Xi(this, pn, 0)
        }
        Da(t, i) {
            var e = t.T,
                r = t.m;
            if (i && (1 === t.mb && t.isStop() && (e = t.isBuy() ? 0 : 1), 2 === t.mb && t.isStopLimit() && (e = t.isBuy() ? 2 : 3, r = t.K)), 0 !== e && 1 !== e && 2 !== e && 3 !== e) return !0;
            if (!_i(this, Gh)) {
                let [i, s] = et(this.symbol.h, this.symbol.xb, this.symbol.dc, this.prices, t.Nb);
                Ri(this, Gh, i), Ri(this, Jh, s)
            }
            if (0 === e || 2 === e) {
                let a, h;
                return i = A(t.J, t.U), Ri(this, tn, s.normalize(_i(this, tn) + i, 8)), h = 0 === e ? _i(this, Jh) : r, a = this.kc(0, t.J, i, h), Ri(this, sn, s.normalize(_i(this, sn) + a, this.symbol.Ha)), h = 0 === e ? _i(this, Gh) : Math.min(r, _i(this, Gh)), a = this.kc(0, t.J, i, h), Ri(this, en, s.normalize(_i(this, en) + a, this.symbol.Ha)), Ri(this, rn, Math.min(_i(this, rn), h)), !0
            }
            return (1 === e || 3 === e) && (i = A(t.J, t.U), Ri(this, an, s.normalize(_i(this, an) + i, 8)), e = 1 === e ? _i(this, Gh) : Math.max(r, _i(this, Gh)), t = this.kc(1, t.J, i, e), Ri(this, hn, s.normalize(_i(this, hn) + t, this.symbol.Ha)), Ri(this, nn, Math.max(_i(this, nn), e)), !0)
        }
        Fb(t) {
            if (!_i(this, Gh)) {
                let [i, s] = et(this.symbol.h, this.symbol.xb, this.symbol.dc, this.prices, t.D);
                Ri(this, Gh, i), Ri(this, Jh, s)
            }
            return Ri(this, Kh, 0 === t.o ? 0 : 1), Ri(this, Yh, t.l), Ri(this, Zh, A(t.l, t.U)), Ri(this, Qh, this.kc(_i(this, Kh), _i(this, Yh), _i(this, Zh), _i(this, Gh))), !0
        }
        Wa() {
            var t = this.account;
            if (!_i(this, Zh) && !_i(this, tn) && !_i(this, an)) return 0;
            var i = this.prices.sc(this.symbol, this.symbol.Aa, this.account.ra),
                e = this.prices.Kc(this.symbol, this.symbol.Aa, this.account.ra);
            if (this.symbol.oa()) {
                if (Ri(this, cn, 0), Ri(this, ln, 0), Ri(this, on, 0), Ri(this, un, 0), Ri(this, pn, 0), 0n !== _i(this, Yh)) {
                    if (0 === _i(this, Kh)) {
                        var r = s.normalize(_i(this, Zh) * _i(this, Gh), this.account.j);
                        r *= this.symbol.trade.Oa, r = s.normalize(r * i, this.account.j), Ri(this, un, r), t.assets = s.normalize(t.assets + r, this.account.j), t.collateral = s.normalize(t.collateral + r, this.account.j)
                    }
                    1 === _i(this, Kh) && (r = s.normalize(_i(this, Zh) * _i(this, Gh), this.account.j), r = s.normalize(r * e, this.account.j), Ri(this, pn, -r), t.liabilities = s.normalize(t.liabilities - r, this.account.j), t.collateral = s.normalize(t.collateral - r, this.account.j))
                }
                return _i(this, on)
            }
            if (r = 0, _i(this, Zh) ? (Ri(this, cn, this.ja(_i(this, Kh), _i(this, Zh), _i(this, Qh), !1)), Ri(this, ln, this.ja(_i(this, Kh), _i(this, Zh), _i(this, Qh), !0)), Ri(this, on, _i(this, ln)), 0 === _i(this, Kh) && (Ri(this, cn, s.normalize(_i(this, cn) * i, this.account.j)), Ri(this, ln, s.normalize(_i(this, ln) * i, this.account.j)), Ri(this, on, _i(this, ln)), this.symbol.trade.Oa && (Ri(this, un, _i(this, Qh) * this.symbol.trade.Oa), Ri(this, un, s.normalize(_i(this, un) * i, this.account.j))), r = _i(this, Zh)), 1 === _i(this, Kh) && (Ri(this, cn, s.normalize(_i(this, cn) * e, this.account.j)), Ri(this, ln, s.normalize(_i(this, ln) * e, this.account.j)), Ri(this, on, _i(this, ln)), Ri(this, pn, s.normalize(_i(this, Qh) * e, this.account.j)), r = -_i(this, Zh))) : (Ri(this, cn, 0), Ri(this, ln, 0), Ri(this, on, 0), Ri(this, un, 0), Ri(this, pn, 0)), _i(this, tn))
                if (r + _i(this, tn) <= 0) var a = 0;
                else {
                    a = Math.min(_i(this, rn), _i(this, Gh));
                    var h = _i(this, Gh),
                        n = this.symbol.Fa(0, !0);
                    if (n) {
                        if (this.symbol.Hc()) {
                            var o = this.symbol.Ka,
                                l = this.symbol.Ob;
                            a = o * a / 100 + l, h = o * h / 100 + l
                        }
                        a = r * (h - a) + (r + _i(this, tn)) * a * n + (_i(this, en) - _i(this, tn) * a), a = s.normalize(a * i, this.account.j)
                    } else a = s.normalize(_i(this, sn) * i, this.account.j)
                }
            else a = _i(this, ln);
            return _i(this, an) ? r >= _i(this, an) ? r = 0 : (i = Math.max(_i(this, nn), _i(this, Gh)), h = _i(this, Gh), (n = this.symbol.Fa(1, !0)) ? (this.symbol.Hc() && (i = (o = this.symbol.Ka) * i / 100 + (l = this.symbol.Ob), h = o * h / 100 + l), r = -r * (i - h) - (r - (o = _i(this, an))) * i * n + (o * i - (l = _i(this, hn))), r = s.normalize(r * e, this.account.j)) : r = s.normalize(_i(this, ln) * e, this.account.j)) : r = _i(this, ln), (a || r) && Ri(this, on, Math.max(a, r)), e = this.account.j, t.margin = s.normalize(t.margin + _i(this, on), e), t.S = s.normalize(t.S + _i(this, ln), e), t.P = s.normalize(t.P + _i(this, cn), e), t.assets = s.normalize(t.assets + _i(this, un), e), t.liabilities = s.normalize(t.liabilities - _i(this, pn), e), _i(this, on)
        }
        ja(t, i, e, r) {
            if (r) var a = this.symbol.trade.S;
            else a = this.symbol.trade.S, this.symbol.trade.P && (a = this.symbol.trade.P);
            return s.normalize(a > 0 ? a * i / this.symbol.I * this.symbol.Fa(t, r) : e * this.symbol.Fa(t, r), this.symbol.kd)
        }
    }
    var Gh = new WeakMap,
        Jh = new WeakMap,
        Kh = new WeakMap,
        Yh = new WeakMap,
        Zh = new WeakMap,
        Qh = new WeakMap,
        tn = new WeakMap,
        sn = new WeakMap,
        en = new WeakMap,
        rn = new WeakMap,
        an = new WeakMap,
        hn = new WeakMap,
        nn = new WeakMap,
        on = new WeakMap,
        ln = new WeakMap,
        cn = new WeakMap,
        un = new WeakMap,
        pn = new WeakMap;
    class mn extends xh {
        Td(t) {
            return new Hh(this.account, t, this.prices)
        }
    }
    class fn extends Vh {
        constructor() {
            super(...arguments), Xi(this, dn, 0), Xi(this, bn, 0), Xi(this, gn, 0), Xi(this, yn, 0n), Xi(this, wn, 0), Xi(this, vn, 0), Xi(this, kn, 0), Xi(this, Mn, 0), Xi(this, Tn, 0), Xi(this, zn, 0), Xi(this, Wn, 0), Xi(this, Sn, 0), Xi(this, jn, 0), Xi(this, Bn, 0)
        }
        Da(t, i) {
            var e = t.T,
                r = t.m;
            if (i && (1 === t.mb && t.isStop() && (e = t.isBuy() ? 0 : 1), 2 === t.mb && t.isStopLimit() && (e = t.isBuy() ? 2 : 3, r = t.K)), 0 !== e && 1 !== e && 2 !== e && 3 !== e) return !0;
            if (!_i(this, dn)) {
                let [i, s] = et(this.symbol.h, this.symbol.xb, this.symbol.dc, this.prices, t.Nb);
                Ri(this, dn, i), Ri(this, bn, s)
            }
            return 0 === e || 2 === e ? (i = A(t.J, t.U), Ri(this, kn, s.normalize(_i(this, kn) + i, 8)), e = 0 === e ? _i(this, bn) : r, t = this.kc(0, t.J, i, e), Ri(this, Mn, s.normalize(_i(this, Mn) + t, this.symbol.Ha)), !0) : (1 === e || 3 === e) && (t = A(t.J, t.U), Ri(this, Tn, s.normalize(_i(this, Tn) + t, 8)), !0)
        }
        Fb(t) {
            if (!_i(this, dn)) {
                let [i, s] = et(this.symbol.h, this.symbol.xb, this.symbol.dc, this.prices, t.D);
                Ri(this, dn, i), Ri(this, bn, s)
            }
            return Ri(this, gn, 0 === t.o ? 0 : 1), Ri(this, yn, t.l), Ri(this, wn, A(t.l, t.U)), Ri(this, vn, this.kc(_i(this, gn), _i(this, yn), _i(this, wn), _i(this, dn))), !0
        }
        Wa() {
            if (!_i(this, wn) && !_i(this, kn) && !_i(this, Tn)) return 0;
            var t = this.account,
                i = this.prices.sc(this.symbol, this.symbol.Aa, t.ra),
                e = this.prices.Kc(this.symbol, this.symbol.Aa, t.ra),
                r = t.j;
            if (this.symbol.oa()) {
                if (Ri(this, Sn, 0), Ri(this, Wn, 0), Ri(this, zn, 0), Ri(this, jn, 0), Ri(this, Bn, 0), 0n !== _i(this, yn)) {
                    if (0 === _i(this, gn)) {
                        var a = s.normalize(_i(this, wn) * _i(this, dn), r);
                        a *= this.symbol.trade.Oa, a = s.normalize(a * i, r), Ri(this, jn, a), t.assets = s.normalize(t.assets + a, r), t.collateral = s.normalize(t.collateral + a, r)
                    }
                    1 === _i(this, gn) && (a = s.normalize(_i(this, wn) * _i(this, dn), r), a = s.normalize(a * e, r), Ri(this, Bn, -a), t.liabilities = s.normalize(t.liabilities - a, r), t.collateral = s.normalize(t.collateral - a, r))
                }
                return _i(this, zn)
            }
            if (a = 0, _i(this, wn) ? (Ri(this, Sn, this.Ei(0 === _i(this, gn) ? 0 : 1, _i(this, wn), _i(this, vn), !1)), Ri(this, Wn, this.Ei(0 === _i(this, gn) ? 0 : 1, _i(this, wn), _i(this, vn), !0)), Ri(this, zn, _i(this, Wn)), 0 === _i(this, gn) && (Ri(this, Sn, s.normalize(_i(this, Sn) * i, r)), Ri(this, Wn, s.normalize(_i(this, Wn) * i, r)), Ri(this, zn, _i(this, Wn)), this.symbol.trade.Oa && (Ri(this, jn, _i(this, vn) * this.symbol.trade.Oa), Ri(this, jn, s.normalize(_i(this, jn) * i, r))), a = _i(this, wn)), 1 === _i(this, gn) && (Ri(this, Sn, s.normalize(_i(this, Sn) * e, r)), Ri(this, Wn, s.normalize(_i(this, Wn) * e, r)), Ri(this, zn, _i(this, Wn)), Ri(this, Bn, s.normalize(_i(this, vn) * e, r)), a = -_i(this, wn))) : (Ri(this, Sn, 0), Ri(this, Wn, 0), Ri(this, zn, 0), Ri(this, jn, 0), Ri(this, Bn, 0)), _i(this, kn))
                if (a + _i(this, kn) <= 0) var h = 0;
                else {
                    if (h = this.symbol.Fa(0, !0)) {
                        var n = _i(this, dn);
                        let t = this.symbol.Ka,
                            i = this.symbol.Ob;
                        this.symbol.Hc() && (n = t * n / 100 + i), h = (a + _i(this, kn)) * h * n
                    } else h = _i(this, Mn);
                    h = s.normalize(h * i, r)
                }
            else h = _i(this, Wn);
            return _i(this, Tn) ? a >= _i(this, Tn) ? a = 0 : (i = _i(this, dn), n = this.symbol.Fa(1, !0), this.symbol.Hc() && (i = this.symbol.Ka * i / 100 + this.symbol.Ob), a = n ? (-a + _i(this, Tn)) * n * i : (-a + _i(this, Tn)) * i, a = s.normalize(a * e, r)) : a = _i(this, Wn), (h || a) && Ri(this, zn, Math.max(h, a)), t.margin = s.normalize(t.margin + _i(this, zn), r), t.S = s.normalize(t.S + _i(this, Wn), r), t.P = s.normalize(t.P + _i(this, Sn), r), t.assets = s.normalize(t.assets + _i(this, jn), r), t.liabilities = s.normalize(t.liabilities - _i(this, Bn), this.account.j), _i(this, zn)
        }
        Ei(t, i, e, r) {
            if (r) var a = this.symbol.trade.S;
            else a = this.symbol.trade.S, this.symbol.trade.P && (a = this.symbol.trade.P);
            return s.normalize(a > 0 ? a * i / this.symbol.I : this.symbol.Fa(t, r) ? e * this.symbol.Fa(t, r) : 1 === t ? e : 0, this.account.j)
        }
        ja(t, i, e, r, a) {
            var h = this.symbol;
            if (a) var n = h.trade.S;
            else n = h.trade.S, h.trade.P && (n = h.trade.P);
            switch (h.ga) {
                case 32:
                case 35:
                case 36:
                case 37:
                case 38:
                case 39:
                    t = n > 0 ? n * e / h.I : this.kc(t, i, e, r) * h.Fa(t, a);
                    break;
                default:
                    t = 0
            }
            return s.normalize(t, h.kd)
        }
    }
    var dn = new WeakMap,
        bn = new WeakMap,
        gn = new WeakMap,
        yn = new WeakMap,
        wn = new WeakMap,
        vn = new WeakMap,
        kn = new WeakMap,
        Mn = new WeakMap,
        Tn = new WeakMap,
        zn = new WeakMap,
        Wn = new WeakMap,
        Sn = new WeakMap,
        jn = new WeakMap,
        Bn = new WeakMap;
    class $n extends xh {
        Td(t) {
            return new fn(this.account, t, this.prices)
        }
    }
    class Ln extends Vh {
        constructor() {
            super(...arguments), Xi(this, Nn, 0), Xi(this, In, 0), Xi(this, An, 0), Xi(this, Cn, 0), Xi(this, En, 0n), Xi(this, Dn, 0), Xi(this, On, 0), Xi(this, xn, 0), Xi(this, Fn, 0), Xi(this, Un, 0), Xi(this, Pn, 0), Xi(this, qn, 0), Xi(this, _n, 0), Xi(this, Xn, 0), Xi(this, Rn, 0), Xi(this, Vn, 0)
        }
        Da(t, i = !1) {
            var e = t.T,
                r = t.m;
            return i && (1 === t.mb && t.isStop() && (e = t.isBuy() ? 0 : 1), 2 === t.mb && t.isStopLimit() && (e = t.isBuy() ? 2 : 3, r = t.K)), 0 !== e && 1 !== e && 2 !== e && 3 !== e || (0 === e || 2 === e ? (i = A(t.J, t.U), Ri(this, xn, s.normalize(_i(this, xn) + i, 8)), 0 === e ? (_i(this, In) || (e = et(this.symbol.h, this.symbol.xb, this.symbol.dc, this.prices, t.Nb), Ri(this, In, e[1])), e = _i(this, In)) : e = r, t = this.kc(0, t.J, i, e), Ri(this, Fn, s.normalize(_i(this, Fn) + t, this.symbol.Ha)), !0) : (1 === e || 3 === e) && (i = A(t.J, t.U), Ri(this, Un, s.normalize(_i(this, Un) + i, 8)), 1 === e ? (_i(this, An) || ([e] = et(this.symbol.h, this.symbol.xb, this.symbol.dc, this.prices, t.Nb), Ri(this, An, e)), e = _i(this, An)) : e = r, t = this.kc(1, t.J, i, e), Ri(this, Pn, s.normalize(_i(this, Pn) + t, this.symbol.Ha)), !0))
        }
        Fb(t) {
            if (!_i(this, Nn)) {
                let [i, s] = et(this.symbol.h, this.symbol.xb, this.symbol.dc, this.prices, t.D);
                Ri(this, Nn, i), Ri(this, In, s)
            }
            return Ri(this, Cn, 0 === t.o ? 0 : 1), Ri(this, En, t.l), Ri(this, Dn, A(t.l, t.U)), Ri(this, On, this.kc(_i(this, Cn), _i(this, En), _i(this, Dn), _i(this, Nn))), !0
        }
        Wa() {
            if (!_i(this, Dn) && !_i(this, xn) && !_i(this, Un)) return 0;
            var t = this.account,
                i = this.prices.sc(this.symbol, this.symbol.Aa, this.account.ra),
                e = this.prices.Kc(this.symbol, this.symbol.Aa, this.account.ra);
            if (this.symbol.oa()) {
                if (Ri(this, Xn, 0), Ri(this, _n, 0), Ri(this, qn, 0), Ri(this, Rn, 0), Ri(this, Vn, 0), 0n !== _i(this, En)) {
                    if (0 === _i(this, Cn)) {
                        var r = s.normalize(_i(this, Dn) * _i(this, Nn), this.account.j);
                        r *= this.symbol.trade.Oa, r = s.normalize(r * i, this.account.j), Ri(this, Rn, r), t.assets = s.normalize(t.assets + r, this.account.j), t.collateral = s.normalize(t.collateral + r, this.account.j)
                    }
                    1 === _i(this, Cn) && (r = s.normalize(_i(this, Dn) * _i(this, Nn), this.account.j), r = s.normalize(r * e, this.account.j), Ri(this, Vn, -r), t.liabilities = s.normalize(t.liabilities - r, this.account.j), t.collateral = s.normalize(t.collateral - r, this.account.j))
                }
                return _i(this, qn)
            }
            if (r = 0, _i(this, Dn) ? (Ri(this, Xn, this.ja(_i(this, Cn), _i(this, Dn), _i(this, On), !1)), Ri(this, _n, this.ja(_i(this, Cn), _i(this, Dn), _i(this, On), !0)), Ri(this, qn, _i(this, _n)), 0 === _i(this, Cn) && (Ri(this, Xn, s.normalize(_i(this, Xn) * i, this.account.j)), Ri(this, _n, s.normalize(_i(this, _n) * i, this.account.j)), Ri(this, qn, _i(this, _n)), this.symbol.trade.Oa && (Ri(this, Rn, _i(this, On) * this.symbol.trade.Oa), Ri(this, Rn, s.normalize(_i(this, Rn) * i, this.account.j))), r = _i(this, Dn)), 1 === _i(this, Cn) && (Ri(this, Xn, s.normalize(_i(this, Xn) * e, this.account.j)), Ri(this, _n, s.normalize(_i(this, _n) * e, this.account.j)), Ri(this, qn, _i(this, _n)), this.symbol.trade.Oa && (Ri(this, Vn, _i(this, On) * this.symbol.trade.Oa), Ri(this, Vn, s.normalize(_i(this, Vn) * e, this.account.j))), r = -_i(this, Dn))) : (Ri(this, Xn, 0), Ri(this, _n, 0), Ri(this, qn, 0), Ri(this, Rn, 0), Ri(this, Vn, 0)), _i(this, xn)) {
                var a = r + _i(this, xn);
                if (a <= 0) i = 0;
                else {
                    if (this.symbol.Fa(0, !0)) {
                        var h = this.ja(0, _i(this, xn), _i(this, Fn), !0);
                        h = s.normalize(h * i, this.account.j)
                    } else h = s.normalize(_i(this, Fn) * i, this.account.j);
                    i = r > 0 ? s.normalize(_i(this, qn) + h, this.account.j) : s.normalize(a * h / _i(this, xn), this.account.j)
                }
            } else i = _i(this, _n);
            return _i(this, Un) ? (a = r - _i(this, Un)) >= 0 ? e = 0 : (this.symbol.Fa(1, !0) ? (h = this.ja(1, _i(this, Un), _i(this, Pn), !0), h = s.normalize(h * e, this.account.j)) : h = s.normalize(_i(this, _n) * e, this.account.j), e = r < 0 ? s.normalize(_i(this, qn) + h, this.account.j) : s.normalize(-a * h / _i(this, Un), this.account.j)) : e = _i(this, _n), (i || e) && Ri(this, qn, Math.max(i, e)), t.margin = s.normalize(t.margin + _i(this, qn), this.account.j), t.S = s.normalize(t.S + _i(this, _n), this.account.j), t.P = s.normalize(t.P + _i(this, Xn), this.account.j), t.assets = s.normalize(t.assets + _i(this, Rn), this.account.j), t.liabilities = s.normalize(t.liabilities - _i(this, Vn), this.account.j), _i(this, qn)
        }
        ja(t, i, e, r) {
            if (r) var a = this.symbol.trade.S;
            else a = this.symbol.trade.S, this.symbol.trade.P && (a = this.symbol.trade.P);
            return s.normalize(a > 0 ? a * i / this.symbol.I * this.symbol.Fa(t, r) : e * this.symbol.Fa(t, r), this.account.j)
        }
    }
    var Nn = new WeakMap,
        In = new WeakMap,
        An = new WeakMap,
        Cn = new WeakMap,
        En = new WeakMap,
        Dn = new WeakMap,
        On = new WeakMap,
        xn = new WeakMap,
        Fn = new WeakMap,
        Un = new WeakMap,
        Pn = new WeakMap,
        qn = new WeakMap,
        _n = new WeakMap,
        Xn = new WeakMap,
        Rn = new WeakMap,
        Vn = new WeakMap;
    class Hn extends xh {
        Td(t) {
            return new Ln(this.account, t, this.prices)
        }
    }
    class Gn extends Vh {
        constructor() {
            super(...arguments), Xi(this, po), Xi(this, Jn), Xi(this, Kn, 1), Xi(this, Yn, 0), Xi(this, Zn, 0n), Xi(this, Qn, 0), Xi(this, to, 0), Xi(this, io, 0), Xi(this, so, 0), Xi(this, eo, 0), Xi(this, ro, 0), Xi(this, ao, 0n), Xi(this, ho, 0n), Xi(this, no, !1), Xi(this, oo, 0), Xi(this, lo, 0n), Xi(this, co, 0), Xi(this, uo, 0)
        }
        Da(t, i) {
            if (this.symbol.oa()) return !1;
            var e = A(t.J, t.U);
            if (e <= 0) return !0;
            var r = t.T;
            if (i && (Ri(this, no, !0), 1 === t.mb && (t.isLimit() || t.isStop()) && (r = t.isBuy() ? 0 : 1), 2 === t.mb && t.isStopLimit() && (r = t.isBuy() ? 2 : 3)), (i = this.symbol.Fa(r, !0)) <= 0) return !0;
            var a = t.m;
            !a && ht(r) && (a = t.Nb), ct(r) && (a = t.K);
            var h = 0;
            return rt(r) ? (t.G ? h = t.G : this.prices.ee(this.symbol.h) && (h = this.prices.Zf(this.symbol, this.account.ra, a)), h <= 0 || (e = (e = mt(this.symbol, _i(this, Kn), r, e, a, !0, !1)) * h * i, Ri(this, eo, s.normalize(_i(this, eo) + e, this.account.j)), Ri(this, ao, _i(this, ao) + t.J)), !0) : !!at(r) && (t.G ? h = t.G : this.prices.ee(this.symbol.h) && (h = this.prices.$f(this.symbol, this.account.ra, a)), h <= 0 || (e = (e = mt(this.symbol, _i(this, Kn), r, e, a, !0, !1)) * h * i, Ri(this, ro, s.normalize(_i(this, ro) + e, this.account.j)), Ri(this, ho, _i(this, ho) + t.J)), !0)
        }
        Fb(t) {
            t.isBuy() && Ri(this, Yn, 0), t.isSell() && Ri(this, Yn, 1), Ri(this, Qn, A(t.l, t.U)), Ri(this, to, t.sa), Ri(this, io, t.D);
            var i = mt(this.symbol, _i(this, Kn), _i(this, Yn), _i(this, Qn), _i(this, to), !1, !0);
            return i *= t.gb, i *= this.symbol.Fa(_i(this, Yn), !1), Ri(this, so, s.normalize(i, this.account.j)), Ri(this, Zn, t.l), !0
        }
        Wa() {
            var t = this.account;
            if (this.symbol.oa()) {
                if (Ri(this, oo, 0), Ri(this, lo, 0n), Ri(this, co, 0), Ri(this, uo, 0), 0n !== _i(this, Zn)) {
                    if (0 === _i(this, Yn)) {
                        var i = this.prices.sc(this.symbol, this.symbol.Aa, this.account.ra),
                            e = Vi(this, po, mo).call(this, _i(this, io), _i(this, Yn));
                        e = s.normalize(_i(this, Qn) * e, this.account.j), e *= this.symbol.trade.Oa, e = s.normalize(e * i, this.account.j), t.assets = s.normalize(t.assets + e, this.account.j), t.collateral = s.normalize(t.collateral + e, this.account.j)
                    }
                    1 === _i(this, Yn) && (i = this.prices.Kc(this.symbol, this.symbol.Aa, this.account.ra), e = Vi(this, po, mo).call(this, _i(this, io), _i(this, Yn)), e = s.normalize(_i(this, Qn) * e, this.account.j), e = s.normalize(e * i, this.account.j), t.liabilities = s.normalize(t.liabilities - e, this.account.j), t.collateral = s.normalize(t.collateral - e, this.account.j))
                }
                return _i(this, oo)
            }
            if (i = _i(this, eo), e = _i(this, ro), Ri(this, oo, 0), 0n !== _i(this, Zn)) {
                if (0 === _i(this, Yn))
                    if (i += _i(this, so), this.symbol.qd()) {
                        var r = mt(this.symbol, _i(this, Kn), 1, _i(this, Qn), _i(this, to), !1, !0);
                        e = s.normalize(e - r, this.account.j)
                    } else _i(this, ro) && _i(this, ho) && (e -= s.normalize(_i(this, ro) / Number(_i(this, ho)) * Number(_i(this, Zn)), this.account.j));
                1 === _i(this, Yn) && (e += _i(this, so), this.symbol.qd() ? (r = mt(this.symbol, _i(this, Kn), 0, _i(this, Qn), _i(this, to), !1, !0), i = s.normalize(i - r, this.account.j)) : _i(this, eo) && _i(this, ao) && (i -= s.normalize(_i(this, eo) / Number(_i(this, ao)) * Number(_i(this, Zn)), this.account.j)))
            }
            return Ri(this, oo, Math.max(i, e)), i = _i(this, ao), e = _i(this, ho), Ri(this, lo, 0n), Ri(this, uo, 0), Ri(this, co, 0), 0n !== _i(this, Zn) && (0 === _i(this, Yn) && (i += _i(this, Zn)), 1 === _i(this, Yn) && (e += _i(this, Zn))), i > e ? (Ri(this, lo, i), Ri(this, co, 0)) : i < e ? (Ri(this, lo, e), Ri(this, co, 1)) : (Ri(this, lo, i), Ri(this, co, _i(this, Yn))), _i(this, lo) ? Ri(this, uo, _i(this, oo) / Number(_i(this, lo))) : Ri(this, uo, 0), t.liabilities = s.normalize(t.liabilities - _i(this, oo), this.account.j), _i(this, oo)
        }
        Xd() {
            return _i(this, lo)
        }
    }
    var Jn = new WeakMap,
        Kn = new WeakMap,
        Yn = new WeakMap,
        Zn = new WeakMap,
        Qn = new WeakMap,
        to = new WeakMap,
        io = new WeakMap,
        so = new WeakMap,
        eo = new WeakMap,
        ro = new WeakMap,
        ao = new WeakMap,
        ho = new WeakMap,
        no = new WeakMap,
        oo = new WeakMap,
        lo = new WeakMap,
        co = new WeakMap,
        uo = new WeakMap,
        po = new WeakSet,
        mo = function(t, i) {
            return t || (0 === i ? this.prices.md(this.symbol.h) : 1 === i ? this.prices.ld(this.symbol.h) : 0)
        };
    class fo extends xh {
        Td(t) {
            return new Gn(this.account, t, this.prices)
        }
    }
    class bo extends Wh {
        constructor(t, i) {
            super(t, i), Xi(this, yo), Xi(this, go), Ri(this, go, new Sh(new mn(t, i), new $n(t, i), new Hn(t, i), new fo(t, i)))
        }
        jc(t, i, e, r = !1) {
            var a = this.account;
            a.profit = 0, a.M = 0, a.margin = 0, a.Ic = 0, a.S = 0, a.P = 0, a.floating = 0, a.equity = 0, a.assets = 0, a.liabilities = 0, a.collateral = 0, a.W = s.normalize(a.ma + a.na, a.j), _i(this, go).Ea(), this.Jk(t, e), this.Ik(i, e, r), Vi(this, yo, wo).call(this), this.Je()
        }
        Dc() {
            var t = this.account;
            t.Bb = 0, !(t.P <= 0 || t.margin <= 0) && t.equity < t.S && (t.Bb = 1, t.equity < t.P && (t.Bb = 2))
        }
        Je() {
            Vi(this, yo, ko).call(this), Vi(this, yo, vo).call(this), Vi(this, yo, Mo).call(this)
        }
        uh(t) {
            var i = this.Wl(t);
            if (i) return i;
            if (t = this.prices.ee(t)) {
                switch (t.ga) {
                    case 32:
                    case 37:
                        i = _i(this, go).Of.Me(t);
                        break;
                    case 38:
                    case 39:
                        i = _i(this, go).Pf.Me(t);
                        break;
                    case 35:
                    case 36:
                        i = _i(this, go).Qf.Me(t);
                        break;
                    default:
                        i = _i(this, go).Rf.Me(t)
                }
                return i
            }
        }
        Wl(t) {
            return _i(this, go).Of.Pe(t) ?? _i(this, go).Pf.Pe(t) ?? _i(this, go).Qf.Pe(t) ?? _i(this, go).Rf.Pe(t)
        }
        Jk(t, i) {
            var e = this.account;
            t.forEach(t => {
                if (t && 0n !== t.l) {
                    var r = this.uh(t.h);
                    r && r.Fb(t) && !r.oa() && (i && i.h === t.h && (_i(this, go).dm = t), e.profit = s.normalize(e.profit + t.profit, e.j), t.M && (e.M = s.normalize(e.M + t.M, e.j)), r.vl() && (_i(this, go).Ud = s.normalize(_i(this, go).Ud + t.profit, e.j), t.M && (_i(this, go).Ud = s.normalize(_i(this, go).Ud + t.M, e.j))))
                }
            }), e.floating = e.profit, e.M && (e.floating = s.normalize(e.floating + e.M, e.j))
        }
        Ik(t, i, e = !1) {
            var r = this.account,
                a = r.j,
                h = !!i;
            t.forEach(t => {
                var n = this.uh(t.h);
                n && (i && i.B === t.B ? (e || (n.Da(i, h), 0 !== it(t.ma, i.ma, a) && (r.W = s.normalize(r.W + (i.ma - t.ma), a)), 0 !== it(t.na, i.na, a) && (r.W = s.normalize(r.W + (i.na - t.na), a)), _i(this, go).Zb = i), i = null) : n.Da(t, h))
            }), i && (t = this.uh(i.h)) && (t.Da(i, h), i.ma && (r.W = s.normalize(r.W + i.ma, a)), i.na && (r.W = s.normalize(r.W + i.na, a)), _i(this, go).Zb = i)
        }
    }
    var go = new WeakMap,
        yo = new WeakSet,
        wo = function() {
            var t = this.account;
            t.margin = 0, t.S = 0, t.P = 0, t.assets = 0, t.liabilities = 0, t.collateral = 0, _i(this, go).Of.wc(t => t.Wa()), _i(this, go).Pf.wc(t => t.Wa()), _i(this, go).Qf.wc(t => t.Wa()), _i(this, go).Rf.wc(t => t.Wa())
        },
        vo = function() {
            var t = this.account;
            t.R = s.normalize(t.equity - t.margin, t.j)
        },
        ko = function() {
            var t = this.account;
            t.equity = t.balance, t.equity = s.normalize(t.equity + _i(this, go).Ud, t.j), t.credit && (t.equity = s.normalize(t.equity + t.credit, t.j)), t.assets && (t.equity = s.normalize(t.equity + t.assets, t.j)), t.liabilities && (t.equity = s.normalize(t.equity + t.liabilities, t.j)), t.W && (t.equity = s.normalize(t.equity + t.W, t.j))
        },
        Mo = function() {
            var t = this.account;
            t.Ic = 0 === t.P ? 0 : t.equity / t.P * 100
        };
    class To {
        constructor(t) {
            this.rb = t
        }
        Ea() {
            this.rb.Ub()
        }
    }
    class zo extends Rh {
        constructor() {
            super(...arguments), Xi(this, Ao), Xi(this, Wo, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }), Xi(this, So, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }), Xi(this, jo, [{
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }, {
                volume: 0n,
                Sa: 0n,
                price: 0,
                D: 0,
                G: 0,
                Y: 0
            }]), Xi(this, Bo, 0), Xi(this, $o, 0n), Xi(this, Lo, 0n), Xi(this, No, 0n), Xi(this, Io, 0)
        }
        Da(t, i) {
            if (this.symbol.oa()) return !1;
            if (t.nd() || t.Zd()) return !0;
            var s = t.T;
            i && (1 === t.mb && (t.isLimit() || t.isStop()) && (s = t.isBuy() ? 0 : 1), 2 === t.mb && t.isStopLimit() && (s = t.isBuy() ? 2 : 3));
            var e = this.symbol.Fa(s, !0);
            if (e <= 0) return !0;
            var r = 0,
                a = t.m;
            return !a && ht(s) && (a = t.Nb), ct(s) && (a = t.K), rt(s) ? (t.G ? r = t.G : this.prices.ee(this.symbol.h) && (r = this.prices.Zf(this.symbol, this.account.ra, a)), r <= 0 || (i && 0 === s ? (_i(this, Wo).volume += t.J, _i(this, Wo).price += a * Number(t.J), _i(this, Wo).G += r * Number(t.J), _i(this, Wo).D = a, _i(this, Wo).Sa = t.J, _i(this, Wo).Y = e) : (_i(this, jo)[s].volume += t.J, _i(this, jo)[s].price += a * Number(t.J), _i(this, jo)[s].G += r * Number(t.J), _i(this, jo)[s].Y = e)), !0) : !!at(s) && (t.G ? r = t.G : this.prices.ee(this.symbol.h) && (r = this.prices.$f(this.symbol, this.account.ra, a)), r <= 0 || (i && 1 === s ? (_i(this, So).volume += t.J, _i(this, So).price += a * Number(t.J), _i(this, So).G += r * Number(t.J), _i(this, So).D = a, _i(this, So).Sa = t.J, _i(this, So).Y = e) : (_i(this, jo)[s].volume += t.J, _i(this, jo)[s].price += a * Number(t.J), _i(this, jo)[s].G += r * Number(t.J), _i(this, jo)[s].Y = e)), !0)
        }
        Fb(t) {
            return 0 === t.o ? (_i(this, Wo).volume += t.l, _i(this, Wo).price += t.sa * Number(t.l), _i(this, Wo).G += t.gb * Number(t.l), _i(this, Wo).D = t.D, _i(this, Wo).Y = this.symbol.Fa(0, !1), !0) : 1 === t.o && (_i(this, So).volume += t.l, _i(this, So).price += t.sa * Number(t.l), _i(this, So).G += t.gb * Number(t.l), _i(this, So).D = t.D, _i(this, So).Y = this.symbol.Fa(1, !1), !0)
        }
        Wa() {
            return Ri(this, Bo, 0), yt(_i(this, Wo)), yt(_i(this, So)), this.symbol.oa() ? Vi(this, Ao, Co).call(this) : this.ah() ? Vi(this, Ao, Eo).call(this) : Vi(this, Ao, Oo).call(this)
        }
        ja(t, i, e, r, a) {
            t = this.symbol;
            var h = this.account,
                n = A(i, t.I),
                o = l(i, 8);
            switch (r ? r = t.trade.S : (r = t.trade.S, t.trade.P && (r = t.trade.P)), a && (r && (r = t.trade.yc), n = A(i, t.trade.yc)), t.ga) {
                case 0:
                    return r > 0 ? r * o / h.zc : n / h.zc;
                case 5:
                    return r > 0 ? r * o : n;
                case 1:
                case 33:
                case 34:
                    return r * o;
                case 3:
                    if (r > 0) return r * o;
                    if (t.N) return n * e / t.N * t.va;
                    break;
                case 4:
                    return r > 0 ? r * o / h.zc : n * e / h.zc;
                case 2:
                case 32:
                case 38:
                case 35:
                case 36:
                    return r > 0 ? r * o : n * e;
                case 37:
                case 39:
                    return r > 0 ? r * o : s.normalize(n * t.Ka * e / 100, t.Ha)
            }
            return 0
        }
    }
    var Wo = new WeakMap,
        So = new WeakMap,
        jo = new WeakMap,
        Bo = new WeakMap,
        $o = new WeakMap,
        Lo = new WeakMap,
        No = new WeakMap,
        Io = new WeakMap,
        Ao = new WeakSet,
        Co = function() {
            var t = this.account,
                i = t.j;
            if (_i(this, Wo).volume) {
                var e = this.prices.sc(this.symbol, this.symbol.Aa, t.ra),
                    r = Vi(this, Ao, Uo).call(this, _i(this, Wo).D, 0);
                r = s.normalize(A(_i(this, Wo).volume, this.symbol.I) * r, i), r *= this.symbol.trade.Oa, r = s.normalize(r * e, i), t.assets = s.normalize(t.assets + r, i), t.collateral = s.normalize(t.collateral + r, i)
            }
            return _i(this, So).volume && (e = this.prices.Kc(this.symbol, this.symbol.Aa, t.ra), r = Vi(this, Ao, Uo).call(this, _i(this, So).D, 1), r = s.normalize(A(_i(this, So).volume, this.symbol.I) * r, i), r = s.normalize(r * e, i), t.liabilities = s.normalize(t.liabilities - r, i), t.collateral = s.normalize(t.collateral - r, i)), _i(this, Bo)
        },
        Eo = function() {
            for (var t = 0, i = 0, s = 0, e = 0, r = 0, a = 0, h = 0n, n = 0n, o = 0; o < _i(this, jo).length; o++) {
                let s = _i(this, jo)[o];
                if (s.volume) {
                    if (yt(s), 0 === o || 2 === o || 4 === o || 6 === o) {
                        var l = this.ja(o, s.volume, s.price, !0, !1);
                        l *= s.G, t += l *= s.Y
                    }
                    at(o) && (l = this.ja(o, s.volume, s.price, !0, !1), l *= s.G, i += l *= s.Y)
                }
            }
            return _i(this, Wo).volume && ((h = _i(this, Wo).Sa) ? (l = _i(this, Wo).volume > h ? _i(this, Wo).volume - h : 0n, r = s = this.ja(0, h, _i(this, Wo).price, !0, !1), l && (s += this.ja(0, l, _i(this, Wo).price, !1, !1))) : s = this.ja(0, _i(this, Wo).volume, _i(this, Wo).price, !1, !1), s *= _i(this, Wo).G, s *= _i(this, Wo).Y, r *= _i(this, Wo).G, r *= _i(this, Wo).Y), _i(this, So).volume && (n = _i(this, So).Sa, _i(this, So).Sa ? (l = _i(this, So).volume > n ? _i(this, So).volume - n : 0n, a = e = this.ja(1, n, _i(this, So).price, !0, !1), l && (e += this.ja(1, l, _i(this, So).price, !1, !1))) : e = this.ja(1, _i(this, So).volume, _i(this, So).price, !1, !1), e *= _i(this, So).G, e *= _i(this, So).Y, a *= _i(this, So).G, a *= _i(this, So).Y), (l = s + t) >= (o = e + i) ? (Ri(this, Bo, l), Ri(this, Io, r), Ri(this, No, h)) : (Ri(this, Bo, o), Ri(this, Io, a), Ri(this, No, n)), Vi(this, Ao, Do).call(this, l, o, s, t, e, i), _i(this, Bo)
        },
        Do = function(t, i, s, e, r, a) {
            if (this.Zg())
                if (t >= i) {
                    if (this.Ab = _i(this, Wo).volume - _i(this, No), this.xc = _i(this, No), this.sd = _i(this, Wo).price, this.Kb = s - _i(this, Io), this.Wb = _i(this, Io), this.rd = _i(this, Wo).G, this.ob = e) {
                        for (t = 0; t < _i(this, jo).length; t++) !(i = _i(this, jo)[t]).volume || 0 !== t && 2 !== t && 4 !== t && 6 !== t || (this.Ua += i.volume, this.qb += i.price * Number(i.volume), this.pb += i.G * Number(i.volume));
                        this.qb /= Number(this.Ua), this.pb /= Number(this.Ua)
                    }
                } else if (this.Ab = _i(this, So).volume - _i(this, No), this.xc = _i(this, No), this.sd = _i(this, So).price, this.Kb = r - _i(this, Io), this.Wb = _i(this, Io), this.rd = _i(this, So).G, this.ob = a) {
                for (t = 0; t < _i(this, jo).length; t++) !(i = _i(this, jo)[t]).volume || 1 !== t && 3 !== t && 5 !== t && 7 !== t || (this.Ua += i.volume, this.qb += i.price * Number(i.volume), this.pb += i.G * Number(i.volume));
                this.qb /= Number(this.Ua), this.pb /= Number(this.Ua)
            }
        },
        Oo = function() {
            var t = 0,
                i = 0,
                s = Vi(this, Ao, Fo).call(this);
            for (let r = 0; r < _i(this, jo).length; r++) {
                let s = _i(this, jo)[r];
                if (s.volume) {
                    if (yt(s), 2 === r || 4 === r || 6 === r) {
                        var e = this.ja(r, s.volume, s.price, !0, !1);
                        e *= s.G, t += e *= s.Y
                    }
                    3 !== r && 5 !== r && 7 !== r || (e = this.ja(r, s.volume, s.price, !0, !1), e *= s.G, i += e *= s.Y)
                }
            }
            if (_i(this, jo)[0].volume) {
                _i(this, Wo).Y || (_i(this, Wo).Y = _i(this, jo)[0].Y);
                let [t, i] = gt(_i(this, Wo), _i(this, jo)[0]);
                _i(this, Wo).price = t, _i(this, Wo).G = i, _i(this, Wo).volume += _i(this, jo)[0].volume, _i(this, Wo).Sa += _i(this, jo)[0].volume
            }
            if (_i(this, jo)[1].volume) {
                _i(this, So).Y || (_i(this, So).Y = _i(this, jo)[1].Y);
                let [t, i] = gt(_i(this, So), _i(this, jo)[1]);
                _i(this, So).price = t, _i(this, So).G = i, _i(this, So).volume += _i(this, jo)[1].volume, _i(this, So).Sa += _i(this, jo)[1].volume
            }
            return (_i(this, jo)[0].volume || _i(this, jo)[1].volume) && (e = Vi(this, Ao, Fo).call(this), s = Math.max(s, e)), Ri(this, Bo, s + t + i), Vi(this, Ao, xo).call(this, s, t, i), _i(this, Bo)
        },
        xo = function(t, i, s) {
            if (this.Zg()) {
                var e = this.symbol.I,
                    r = this.symbol.trade.yc;
                _i(this, $o) > _i(this, No) ? (this.Ab = _i(this, $o) - _i(this, No), _i(this, Lo) && this.symbol.trade.yc && this.symbol.I && (this.Ab += BigInt(Number(_i(this, Lo)) * r / e)), this.xc = _i(this, No)) : (this.Ab = 0n, _i(this, Lo) && this.symbol.trade.yc && this.symbol.I && (this.Ab += BigInt(Number(_i(this, Lo)) * r / e)), this.xc = _i(this, $o)), t > _i(this, Io) ? this.Kb = t - _i(this, Io) : this.Kb = 0, this.Wb = _i(this, Io);
                var [a, h] = gt(_i(this, Wo), _i(this, So));
                if (this.sd = a, this.rd = h, this.ob = i + s) {
                    for (t = 0; t < _i(this, jo).length; t++)(i = _i(this, jo)[t]).volume && (this.Ua += i.volume, this.qb += i.price * Number(i.volume), this.pb += i.G * Number(i.volume));
                    this.qb /= Number(this.Ua), this.pb /= Number(this.Ua)
                }
            }
        },
        Fo = function() {
            var t = 0,
                i = 0;
            if (Ri(this, $o, 0n), Ri(this, Lo, 0n), Ri(this, No, 0n), Ri(this, Io, 0), _i(this, Wo).volume > _i(this, So).volume) {
                if (Ri(this, $o, _i(this, Wo).volume - _i(this, So).volume), Ri(this, No, _i(this, Wo).Sa), _i(this, No))
                    if (_i(this, $o) > _i(this, No)) {
                        var s = _i(this, $o) - _i(this, No);
                        i = this.ja(0, _i(this, No), _i(this, Wo).price, !0, !1), Ri(this, Io, i), s && (i += this.ja(0, s, _i(this, Wo).price, !1, !1))
                    } else i = this.ja(0, _i(this, $o), _i(this, Wo).price, !0, !1), Ri(this, Io, i);
                else i = this.ja(0, _i(this, $o), _i(this, Wo).price, !1, !1);
                i *= _i(this, Wo).G, i *= _i(this, Wo).Y, Ri(this, Io, _i(this, Io) * _i(this, Wo).G), Ri(this, Io, _i(this, Io) * _i(this, Wo).Y)
            }
            if (_i(this, Wo).volume < _i(this, So).volume && (Ri(this, $o, _i(this, So).volume - _i(this, Wo).volume), Ri(this, No, _i(this, So).Sa), _i(this, No) ? _i(this, $o) > _i(this, No) ? (s = _i(this, $o) - _i(this, No), i = this.ja(1, _i(this, No), _i(this, So).price, !0, !1), Ri(this, Io, i), s && (i += this.ja(1, s, _i(this, So).price, !1, !1))) : (i = this.ja(1, _i(this, $o), _i(this, So).price, !0, !1), Ri(this, Io, i)) : i = this.ja(1, _i(this, $o), _i(this, So).price, !1, !1), i *= _i(this, So).G, i *= _i(this, So).Y, Ri(this, Io, _i(this, Io) * _i(this, So).G), Ri(this, Io, _i(this, Io) * _i(this, So).Y)), Ri(this, Lo, h.bMath.min(_i(this, Wo).volume, _i(this, So).volume)), _i(this, Lo) > 0) {
                let [i, e] = gt(_i(this, Wo), _i(this, So));
                s = (_i(this, Wo).Y + _i(this, So).Y) / 2, t = this.ja(0, _i(this, Lo), i, !1, !0), t *= e, t *= s
            }
            return i + t
        },
        Uo = function(t, i) {
            return t || (0 === i ? this.prices.md(this.symbol.h) : 1 === i ? this.prices.ld(this.symbol.h) : 0)
        };
    class Po extends xh {
        Td(t) {
            return new zo(this.account, t, this.prices)
        }
    }
    class qo extends Wh {
        constructor(t, i) {
            super(t, i), Xi(this, Xo), Xi(this, _o), Ri(this, _o, new To(new Po(t, i)))
        }
        jc(t, i, e, r = !1) {
            var a = this.account;
            a.profit = 0, a.M = 0, a.margin = 0, a.S = 0, a.P = 0, a.floating = 0, a.equity = 0, a.assets = 0, a.liabilities = 0, a.collateral = 0, a.$b = 0, a.W = s.normalize(a.ma + a.na, a.j), _i(this, _o).rb.Ub(), Vi(this, Xo, Jo).call(this, t), Vi(this, Xo, Ko).call(this, i, e, r), Vi(this, Xo, Ro).call(this), this.Je()
        }
        Dc() {
            var t = this.account;
            t.Bb = 0, 0 === t.af ? 0 !== t.margin && t.Ic < t.$e && (t.Bb = 1, t.Ic < t.bf && (t.Bb = 2)) : 1 === t.af && (0 !== t.margin ? t.equity < t.$e && (t.Bb = 1, t.equity < t.bf && (t.Bb = 2)) : 0 !== (this.account.Db & Zs.pk) && t.equity < 0 && (t.profit || t.M) && (t.Bb = 2))
        }
        Je() {
            Vi(this, Xo, Vo).call(this), Vi(this, Xo, Ho).call(this), Vi(this, Xo, Go).call(this)
        }
    }
    var _o = new WeakMap,
        Xo = new WeakSet,
        Ro = function() {
            var t = this.account;
            t.assets = 0, t.liabilities = 0, t.collateral = 0, t.margin = _i(this, _o).rb.ja()
        },
        Vo = function() {
            var t = this.account,
                i = t.j;
            switch (t.R = t.balance, t.R = s.normalize(t.R - t.margin, i), t.credit && (t.R = s.normalize(t.R + t.credit, i)), t.assets && (t.R = s.normalize(t.R + t.assets, i)), t.liabilities && (t.R = s.normalize(t.R + t.liabilities, i)), t.W && (t.R = s.normalize(t.R + t.W, i)), t.th) {
                case 1:
                    t.R = s.normalize(t.R + t.floating, i);
                    break;
                case 2:
                    t.floating > 0 && (t.R = s.normalize(t.R + t.floating, i));
                    break;
                case 3:
                    t.floating < 0 && (t.R = s.normalize(t.R + t.floating, i))
            }
            t.$b && (t.R = s.normalize(t.R - t.$b, i)), 3 === t.Xe && t.Sb > 0 && (t.R = s.normalize(t.R - t.Sb, i))
        },
        Ho = function() {
            var t = this.account,
                i = t.j;
            t.equity = t.balance, t.equity = s.normalize(t.equity + t.floating, i), t.credit && (t.equity = s.normalize(t.equity + t.credit, i)), t.assets && (t.equity = s.normalize(t.equity + t.assets, i)), t.liabilities && (t.equity = s.normalize(t.equity + t.liabilities, i)), t.W && (t.equity = s.normalize(t.equity + t.W, i)), 3 === t.Xe && t.Sb > 0 && (t.equity = s.normalize(t.equity - t.Sb, i))
        },
        Go = function() {
            var t = this.account;
            t.Ic = t.margin > 0 ? (t.equity - t.$b) / t.margin * 100 : 0
        },
        Jo = function(t) {
            if (t.length) {
                var i = this.account,
                    e = i.j;
                t.forEach(t => {
                    if (t && t.l) {
                        var r = _i(this, _o).rb.Wd(t.h);
                        r && r.Fb(t) && !r.oa() && (i.profit = s.normalize(i.profit + t.profit, e), t.M && (i.M = s.normalize(i.M + t.M, e)), r.Jf() && t.isBuy() && (i.$b = s.normalize(i.$b + t.profit, e)))
                    }
                }), i.floating = i.profit, i.M && (i.floating = s.normalize(i.floating + i.M, e))
            }
        },
        Ko = function(t, i, e = !1) {
            var r = this.account,
                a = r.j,
                h = !!i;
            t.forEach(t => {
                var n = _i(this, _o).rb.Wd(t.h);
                n && (i && i.B === t.B ? (e || (n.Da(i), 0 !== it(t.ma, i.ma, a) && (r.W = s.normalize(r.W + i.ma - t.ma, a)), 0 !== it(t.na, i.na, a) && (r.W = s.normalize(r.W + i.na - t.na, a))), i = void 0) : n.Da(t, h))
            }), i && (t = _i(this, _o).rb.Wd(i.h)) && (t.Da(i, h), i.ma && (r.W = s.normalize(r.W + i.ma, a)), i.na && (r.W = s.normalize(r.W + i.na, a)))
        };
    class Yo {
        constructor(t, i, s) {
            this.jf = [], this.ne = [], this.oe = [], this.Sf = 0, this.Tf = 0n, this.wh = 0, this.xh = 0n, this.rb = t, this.Xb = i, this.Yb = s
        }
        Ea() {
            this.rb.Ub(), this.Xb.Ub(), this.Yb.Ub(), this.jf = [], this.ne = [], this.oe = [], this.Sf = 0, this.Tf = 0n, this.wh = 0, this.xh = 0n
        }
    }
    class Zo extends Rh {
        constructor() {
            super(...arguments), Xi(this, kl), Xi(this, Qo), Xi(this, tl, 0), Xi(this, il, 0n), Xi(this, sl, 0), Xi(this, el, 0), Xi(this, rl, 0), Xi(this, al, 0), Xi(this, hl, 0), Xi(this, nl, 0n), Xi(this, ol, 0n), Xi(this, ll, 0), Xi(this, cl, 0), Xi(this, ul, 0), Xi(this, pl, 0), Xi(this, ml, 0), Xi(this, fl, 0), Xi(this, dl, !1), Xi(this, bl, 0), Xi(this, gl, 0n), Xi(this, yl, 0n), Xi(this, wl, 0), Xi(this, vl, 0)
        }
        Da(t, i) {
            if (this.symbol.oa()) return !1;
            var e = A(t.J, t.U);
            if (e <= 0) return !0;
            var r = t.T;
            if (i && (Ri(this, dl, !0), 1 === t.mb && (t.isLimit() || t.isStop()) && (r = t.isBuy() ? 0 : 1), 2 === t.mb && t.isStopLimit() && (r = t.isBuy() ? 2 : 3)), (i = this.symbol.Fa(r, !0)) <= 0) return !0;
            var a = t.m;
            if (a || 0 !== r && 1 !== r || (a = t.Nb), 6 !== r && 7 !== r || (a = t.K), rt(r)) {
                var h = t.G ? t.G : this.prices.Zf(this.symbol, this.account.ra, a);
                return h <= 0 || (e = (e = wt(this.symbol, this.account, r, e, a, !0, !1)) * h * i, Ri(this, ul, s.normalize(_i(this, ul) + e, this.account.j)), Ri(this, nl, _i(this, nl) + t.J), Ri(this, ll, _i(this, ll) + a * Number(t.J)), Ri(this, ml, _i(this, ml) + h * Number(t.J))), !0
            }
            return !!at(r) && ((h = t.G ? t.G : this.prices.$f(this.symbol, this.account.ra, a)) <= 0 || (e = (e = wt(this.symbol, this.account, r, e, a, !0, !1)) * h * i, Ri(this, pl, s.normalize(_i(this, pl) + e, this.account.j)), Ri(this, ol, _i(this, ol) + t.J), Ri(this, cl, _i(this, cl) + a * Number(t.J)), Ri(this, fl, _i(this, fl) + h * Number(t.J))), !0)
        }
        Fb(t) {
            t.isBuy() && Ri(this, tl, 0), t.isSell() && Ri(this, tl, 1), Ri(this, sl, A(t.l, t.U)), Ri(this, el, t.sa), Ri(this, rl, t.D), Ri(this, hl, t.gb);
            var i = wt(this.symbol, this.account, _i(this, tl), _i(this, sl), _i(this, el), !1, !0);
            return i *= t.gb, i *= this.symbol.Fa(_i(this, tl), !1), Ri(this, al, s.normalize(i, this.account.j)), Ri(this, il, t.l), !0
        }
        Wa() {
            if (this.symbol.oa()) return Vi(this, kl, Ml).call(this, this.account);
            var t = _i(this, ul),
                i = _i(this, pl);
            if (Ri(this, bl, 0), 0n !== _i(this, il)) {
                if (0 === _i(this, tl))
                    if (t += _i(this, al), this.symbol.qd()) {
                        var e = wt(this.symbol, this.account, 1, _i(this, sl), _i(this, el), !1, !0);
                        i = s.normalize(i - e, this.account.j)
                    } else _i(this, pl) && _i(this, ol) && (i -= s.normalize(_i(this, pl) / Number(_i(this, ol)) * Number(_i(this, il)), this.account.j));
                1 === _i(this, tl) && (i += _i(this, al), this.symbol.qd() ? (e = wt(this.symbol, this.account, 0, _i(this, sl), _i(this, el), !1, !0), t = s.normalize(t - e, this.account.j)) : _i(this, ul) && _i(this, nl) && (t -= s.normalize(_i(this, ul) / Number(_i(this, nl)) * Number(_i(this, il)), this.account.j)))
            }
            Ri(this, bl, Math.max(t, i)), e = _i(this, nl);
            var r = _i(this, ol);
            return Ri(this, gl, 0n), Ri(this, vl, 0), Ri(this, wl, 0), 0n !== _i(this, il) && (0 === _i(this, tl) && (e += _i(this, il)), 1 === _i(this, tl) && (r += _i(this, il))), e > r ? (Ri(this, gl, e), Ri(this, wl, 0)) : e < r ? (Ri(this, gl, r), Ri(this, wl, 1)) : (Ri(this, gl, e), Ri(this, wl, _i(this, tl))), _i(this, gl) ? Ri(this, vl, _i(this, bl) / Number(_i(this, gl))) : Ri(this, vl, 0), Vi(this, kl, Tl).call(this, t, i), _i(this, bl)
        }
        Wg() {
            return _i(this, Qo)
        }
        Nh(t) {
            Ri(this, Qo, t)
        }
        Oh(t) {
            Ri(this, yl, t)
        }
        el() {
            return _i(this, yl)
        }
        Xd() {
            return _i(this, gl)
        }
        kl() {
            return _i(this, wl)
        }
        $i() {
            return _i(this, vl)
        }
        Sj(t) {
            Ri(this, gl, _i(this, gl) - h.bMath.min(_i(this, gl), t))
        }
        bj() {
            return _i(this, dl)
        }
    }
    var Qo = new WeakMap,
        tl = new WeakMap,
        il = new WeakMap,
        sl = new WeakMap,
        el = new WeakMap,
        rl = new WeakMap,
        al = new WeakMap,
        hl = new WeakMap,
        nl = new WeakMap,
        ol = new WeakMap,
        ll = new WeakMap,
        cl = new WeakMap,
        ul = new WeakMap,
        pl = new WeakMap,
        ml = new WeakMap,
        fl = new WeakMap,
        dl = new WeakMap,
        bl = new WeakMap,
        gl = new WeakMap,
        yl = new WeakMap,
        wl = new WeakMap,
        vl = new WeakMap,
        kl = new WeakSet,
        Ml = function(t) {
            if (Ri(this, bl, 0), Ri(this, gl, 0n), Ri(this, wl, 0), Ri(this, vl, 0), 0n !== _i(this, il)) {
                if (0 === _i(this, tl)) {
                    var i = this.prices.sc(this.symbol, this.symbol.Aa, this.account.ra),
                        e = Vi(this, kl, zl).call(this, _i(this, rl), _i(this, tl));
                    e = s.normalize(_i(this, sl) * e, this.account.j), e *= this.symbol.trade.Oa, e = s.normalize(e * i, this.account.j), t.assets = s.normalize(t.assets + e, this.account.j), t.collateral = s.normalize(t.collateral + e, this.account.j)
                }
                1 === _i(this, tl) && (i = this.prices.Kc(this.symbol, this.symbol.Aa, this.account.ra), e = Vi(this, kl, zl).call(this, _i(this, rl), _i(this, tl)), e = s.normalize(_i(this, sl) * e, this.account.j), e = s.normalize(e * i, this.account.j), t.liabilities = s.normalize(t.liabilities - e, this.account.j), t.collateral = s.normalize(t.collateral - e, this.account.j))
            }
            return _i(this, bl)
        },
        Tl = function(t, i) {
            this.Zg() && (t >= i ? (0 === _i(this, tl) && (this.Ab = _i(this, il), this.xc = 0n, this.sd = _i(this, el), this.Kb = _i(this, al), this.Wb = 0, this.rd = _i(this, hl)), this.Ua = _i(this, nl), this.ob = _i(this, ul), _i(this, nl) && (this.qb = _i(this, ll) / Number(_i(this, nl)), this.pb = _i(this, ml) / Number(_i(this, nl)))) : (1 === _i(this, tl) && (this.Ab = _i(this, il), this.xc = 0n, this.sd = _i(this, el), this.Kb = _i(this, al), this.Wb = 0, this.rd = _i(this, hl)), this.Ua = _i(this, ol), this.ob = _i(this, pl), _i(this, nl) && (this.qb = _i(this, cl) / Number(_i(this, ol)), this.pb = _i(this, fl) / Number(_i(this, ol)))))
        },
        zl = function(t, i) {
            return t || (0 === i ? this.prices.md(this.symbol.h) : 1 === i ? this.prices.ld(this.symbol.h) : 0)
        };
    class Wl extends xh {
        Td(t) {
            return new Zo(this.account, t, this.prices)
        }
    }
    class Sl extends Wh {
        constructor(t, i, s) {
            super(t, i), Xi(this, $l), Xi(this, jl), Xi(this, Bl), Ri(this, Bl, s), Ri(this, jl, new Yo(new Wl(t, i), new Wl(t, i), new Wl(t, i)))
        }
        jc(t, i, e, r = !1) {
            var a = this.account;
            a.profit = 0, a.M = 0, a.margin = 0, a.S = 0, a.P = 0, a.floating = 0, a.equity = 0, a.assets = 0, a.liabilities = 0, a.collateral = 0, a.$b = 0, a.W = s.normalize(a.ma + a.na, a.j), Vi(this, $l, Ll).call(this), Vi(this, $l, Pl).call(this, t, e), Vi(this, $l, ql).call(this, i, e, r), Vi(this, $l, Nl).call(this), this.Je()
        }
        Dc() {
            var t = this.account;
            this.account.Bb = 0, 0 === this.account.af ? 0 !== t.margin && t.Ic < this.account.$e && (t.Bb = 1, t.Ic < this.account.bf && (t.Bb = 2)) : 1 === this.account.af && 0 !== t.margin && this.account.equity < this.account.$e && (this.account.Bb = 1, t.equity < this.account.bf && (t.Bb = 2))
        }
        Je() {
            Vi(this, $l, Il).call(this), Vi(this, $l, Al).call(this), Vi(this, $l, Cl).call(this)
        }
    }
    var jl = new WeakMap,
        Bl = new WeakMap,
        $l = new WeakSet,
        Ll = function() {
            _i(this, jl).rb.Ub(), _i(this, jl).Sf = 0, _i(this, jl).Tf = 0n, _i(this, jl).wh = 0, _i(this, jl).xh = 0n
        },
        Nl = function() {
            this.account.assets = 0, this.account.liabilities = 0, this.account.collateral = 0, this.account.margin = _i(this, jl).rb.ja(), Vi(this, $l, El).call(this)
        },
        Il = function() {
            var t = this.account;
            switch (t.R = t.balance, t.R = s.normalize(t.R - t.margin, t.j), t.credit && (t.R = s.normalize(t.R + t.credit, t.j)), t.assets && (t.R = s.normalize(t.R + t.assets, t.j)), t.liabilities && (t.R = s.normalize(t.R + t.liabilities, t.j)), t.W && (t.R = s.normalize(t.R + t.W, t.j)), this.account.th) {
                case 1:
                    t.R = s.normalize(t.R + t.floating, t.j);
                    break;
                case 2:
                    t.floating > 0 && (t.R = s.normalize(t.R + t.floating, t.j));
                    break;
                case 3:
                    t.floating < 0 && (t.R = s.normalize(t.R + t.floating, t.j))
            }
            t.$b && (t.R = s.normalize(t.R - t.$b, t.j)), 1 === this.account.Xe && t.Sb > 0 && (t.R = s.normalize(t.R - t.Sb, t.j))
        },
        Al = function() {
            var t = this.account;
            t.equity = t.balance, t.equity = s.normalize(t.equity + t.floating, t.j), t.credit && (t.equity = s.normalize(t.equity + t.credit, t.j)), t.assets && (t.equity = s.normalize(t.equity + t.assets, t.j)), t.liabilities && (t.equity = s.normalize(t.equity + t.liabilities, t.j)), t.W && (t.equity = s.normalize(t.equity + t.W, t.j)), 1 === t.Xe && t.Sb > 0 && (t.equity = s.normalize(t.equity - t.Sb, t.j))
        },
        Cl = function() {
            var t = this.account;
            t.Ic = t.margin > 0 ? (t.equity - t.$b) / t.margin * 100 : 0
        },
        El = function() {
            var t = this.account;
            if (_i(this, Bl).jh()) {
                _i(this, jl).jf = [], _i(this, jl).rb.wc(t => {
                    t = t.getName(), _i(this, jl).jf = _i(this, Bl).ih(t)
                });
                for (var i = 0, e = {
                        value: 0
                    }; Vi(this, $l, Dl).call(this, e);) it(e.value, 0, t.j) > 0 && (i = s.normalize(i + e.value, t.j));
                i = Math.min(t.margin, i), t.margin = s.normalize(t.margin - i, t.j)
            }
        },
        Dl = function(t) {
            var i, s, e = 0,
                r = er.Ie,
                a = {
                    ed: 0
                },
                h = {
                    ed: 0
                };
            t.value = 0;
            for (let l = 0; l < _i(this, jl).jf.length && Vi(this, $l, Ul).call(this); l++) {
                let t = _i(this, jl).jf[l].spread;
                var n = kt(t, _i(this, jl).Xb, t.ce, a),
                    o = kt(t, _i(this, jl).Yb, t.de, h);
                n && o && (n = Math.min(a.ed, h.ed)) > 0 ? it(n = Vi(this, $l, Ol).call(this, t, t.ce, t.de, n, _i(this, jl).Xb, _i(this, jl).Yb), 0, this.account.j) > 0 && (n > e || t.xj(r)) && (e = n, r = t.xd, vt(_i(this, jl).Xb, _i(this, jl).ne), vt(_i(this, jl).Yb, _i(this, jl).oe)) : (n = kt(t, _i(this, jl).Yb, t.ce, a), o = kt(t, _i(this, jl).Xb, t.de, h), n && o && (n = Math.min(a.ed, h.ed)) > 0 && it(n = Vi(this, $l, Ol).call(this, t, t.ce, t.de, n, _i(this, jl).Yb, _i(this, jl).Xb), 0, this.account.j) > 0 && (n > e || t.xj(r)) && (e = n, r = t.xd, vt(_i(this, jl).Xb, _i(this, jl).ne), vt(_i(this, jl).Yb, _i(this, jl).oe)))
            }
            if (t.value = Math.min(this.account.margin, e), t.value > 0) {
                if (_i(this, jl).ne.length === _i(this, jl).Xb.Ve())
                    for (t = 0; t < _i(this, jl).ne.length; t++) null == (i = _i(this, jl).Xb.at(t)) || i.Sj(_i(this, jl).ne[t]);
                if (_i(this, jl).oe.length === _i(this, jl).Yb.Ve())
                    for (t = 0; t < _i(this, jl).oe.length; t++) null == (s = _i(this, jl).Yb.at(t)) || s.Sj(_i(this, jl).oe[t]);
                return !0
            }
            return !1
        },
        Ol = function(t, i, e, r, a, h) {
            switch (t.xd) {
                case er.Ie:
                    var n = {
                        Zb: !1
                    };
                    return (a = Vi(this, $l, xl).call(this, i, a, r, n)) + (h = Vi(this, $l, xl).call(this, e, h, r, n)) - t.S * r / 1e8;
                case er.pi:
                    return r = {
                            Zb: !1
                        },
                        function(t) {
                            t.wc(t => {
                                t.Wg() && t.Oh(t.Xd())
                            })
                        }((t = Vi(this, $l, Fl).call(this, a, r)) >= (r = Vi(this, $l, Fl).call(this, h, r)) ? h : a), Math.min(t, r);
                case er.ug:
                    return n = {
                        Zb: !1
                    }, a = Vi(this, $l, xl).call(this, i, a, r, n), h = Vi(this, $l, xl).call(this, e, h, r, n), t = !n.Zb && t.P ? t.P : t.S, s.normalize(a * t / 100 + h * t / 100, this.account.j);
                case er.vg:
                    return n = {
                        Zb: !1
                    }, a = Vi(this, $l, xl).call(this, i, a, r, n), h = Vi(this, $l, xl).call(this, e, h, r, n), s.normalize(a + h - (Math.abs(a - h) + (!n.Zb && t.P ? t.P : t.S) * r / 1e8), this.account.j)
            }
            return 0
        },
        xl = function(t, i, e, r) {
            var a = 0;
            i = i.Qi();
            for (let o = 0; o < i.length; o++) {
                let l = i[o];
                var n = l.Wg();
                if (!n) continue;
                if (!t.includes(n)) continue;
                let c = l.Xd();
                n = BigInt(n.Sh * e), n = h.bMath.min(c, n), a = s.normalize(a + l.$i() * Number(n), this.account.j), l.Oh(n), r.Zb || (r.Zb = l.bj())
            }
            return a
        },
        Fl = function(t, i) {
            var e = 0;
            return t.wc(t => {
                if (t.Wg()) {
                    var r = t.Xd();
                    e = s.normalize(e + t.$i() * Number(r), this.account.j), i.Zb || (i.Zb = t.bj())
                }
            }), e
        },
        Ul = function() {
            return _i(this, jl).Xb.Ub(), _i(this, jl).Yb.Ub(), _i(this, jl).rb.wc(t => {
                t.Nh(), t.Oh(0n), t.Xd() && (0 === t.kl() ? _i(this, jl).Xb.Gg(t) : _i(this, jl).Yb.Gg(t))
            }), !(!_i(this, jl).Xb.Ve() && !_i(this, jl).Yb.Ve())
        },
        Pl = function(t, i) {
            var e = this.account,
                r = e.j;
            t.forEach(t => {
                if (t && 0n !== t.l) {
                    var a = _i(this, jl).rb.Wd(t.h);
                    a && a.Fb(t) && !a.oa() && (i && i.h === t.h && (_i(this, jl).wh = t.o, _i(this, jl).xh = t.l), e.profit = s.normalize(e.profit + t.profit, r), e.M = s.normalize(e.M + t.M, r), a.Jf() && t.isBuy() && (e.$b = s.normalize(e.$b + t.profit, r)))
                }
            }), e.floating = e.profit, e.floating = s.normalize(e.floating + e.M, r)
        },
        ql = function(t, i = null, e) {
            var r = this.account,
                a = this.account.j,
                h = i,
                n = !!h;
            t.forEach(t => {
                if (t) {
                    var i = _i(this, jl).rb.Wd(t.h);
                    i && (h && h.B === t.B ? (e || (i.Da(h, n), 0 !== it(t.ma, h.ma, a) && (r.W = s.normalize(r.W + h.ma - t.ma, a)), 0 !== it(t.na, h.na, a) && (r.W = s.normalize(r.W + (h.na - t.na), a)), _i(this, jl).Sf = h.T, _i(this, jl).Tf = h.J), h = null) : i.Da(t, n))
                }
            }), h && (t = _i(this, jl).rb.Wd(h.h)) && (t.Da(h, n), h.ma && (r.W = s.normalize(r.W + h.ma, r.j)), h.na && (r.W = s.normalize(r.W + h.na, a)), _i(this, jl).Sf = h.T, _i(this, jl).Tf = h.J)
        };
    class _l {
        constructor(t, i, s) {
            Xi(this, Xl), Xi(this, Rl), Xi(this, Vl), Xi(this, Hl), Xi(this, Gl), Xi(this, Jl), Ri(this, Jl, s), Ri(this, Xl, t), Ri(this, Rl, i), Ri(this, Vl, new bo(_i(this, Jl), _i(this, Xl))), Ri(this, Hl, new qo(_i(this, Jl), _i(this, Xl))), Ri(this, Gl, new Sl(_i(this, Jl), _i(this, Xl), _i(this, Rl)))
        }
        static nc() {
            return 2 === (void 0).ge
        }
        jc(t, i, s, e) {
            var r = _i(this, Jl).ge;
            1 === r ? _i(this, Vl).jc(i, t, s, e) : 2 === r ? _i(this, Hl).jc(i, t, s, e) : _i(this, Gl).jc(i, t, s, e)
        }
        Dc(t) {
            1 === (t = t.ge) ? _i(this, Vl).Dc() : 2 === t ? _i(this, Hl).Dc() : _i(this, Gl).Dc()
        }
    }
    var Xl = new WeakMap,
        Rl = new WeakMap,
        Vl = new WeakMap,
        Hl = new WeakMap,
        Gl = new WeakMap,
        Jl = new WeakMap;
    class Kl {
        constructor() {
            this.B = 0n, this.h = this.yd = "", this.A = this.v = this.Nb = this.K = this.m = this.Pc = this.ya = this.ea = this.T = this.jg = this.ua = this.kf = 0, this.J = this.Ra = 0n, this.rc = 0, this.H = this.eb = 0n, this.comment = "", this.mb = this.G = this.na = this.ma = this.ca = this.i = this.U = 0
        }
        Cf() {
            var t = new Kl;
            return t.B = this.B, t.yd = this.yd, t.h = this.h, t.kf = this.kf, t.ua = this.ua, t.jg = this.jg, t.T = this.T, t.ea = this.ea, t.ya = this.ya, t.Pc = this.Pc, t.m = this.m, t.K = this.K, t.Nb = this.Nb, t.v = this.v, t.A = this.A, t.Ra = this.Ra, t.J = this.J, t.rc = this.rc, t.eb = this.eb, t.H = this.H, t.comment = this.comment, t.U = this.U, t.i = this.i, t.ca = this.ca, t.ma = this.ma, t.na = this.na, t.G = this.G, t.mb = this.mb, t
        }
        isBuy() {
            return rt(this.T)
        }
        isSell() {
            return at(this.T)
        }
        isMarket() {
            return ht(this.T)
        }
        isPending() {
            return nt(this.T)
        }
        isLimit() {
            return ot(this.T)
        }
        isStop() {
            return lt(this.T)
        }
        isStopLimit() {
            return ct(this.T)
        }
        bh() {
            return this.isMarket() && !this.m
        }
        Zd() {
            return 8 === this.T
        }
        nd() {
            return !(!this.isMarket() || !this.H)
        }
    }
    class Yl {
        constructor(t, i) {
            this.fa = 0, this.result = t ?? 1, this.fa = i ?? 0
        }
        Cl() {
            return 0 === this.result
        }
        pd() {
            return !this.fa
        }
        Od(t, i) {
            this.pd() || (this.fa = s.normalize(this.fa * t, i))
        }
    }
    class Zl {
        constructor(t, i) {
            this.rate = 0, this.sb = new Yl, this.rate = t ?? 0, this.sb = i ?? new Yl
        }
        pd() {
            return (!this.rate || this.sb.Cl()) && this.sb.pd()
        }
        Od(t, i) {
            this.rate && (this.rate = s.normalize(this.rate * t, 7), this.sb.Od(t, i))
        }
    }
    class Ql {
        constructor(t, i) {
            this.initial = t ?? new Zl, this.oc = i ?? new Zl
        }
        pd() {
            return this.initial.pd() && this.oc.pd()
        }
        Od(t, i) {
            this.initial.Od(t.Ye, i), this.oc.Od(t.Ze, i)
        }
    }
    class tc {
        constructor(t, i, s, e, r) {
            Xi(this, hc), Xi(this, ic), Xi(this, sc), Xi(this, ec), Xi(this, rc), Xi(this, ac), Ri(this, ic, t), Ri(this, sc, i), Ri(this, ec, s), Ri(this, rc, e), Ri(this, ac, r)
        }
        Gi(t) {
            var {
                Lb: i,
                Mb: s
            } = _i(this, ac).trade;
            return t >= i.length || t >= s.length ? new Ql : new Ql(new Zl(i[t], Vi(this, hc, nc).call(this, t, !0)), new Zl(s[t], Vi(this, hc, nc).call(this, t, !1)))
        }
        al(t) {
            var {
                rules: i
            } = _i(this, rc);
            if (i.length && i[0].ab.length)
                for (let e = 0; e < i.length; e++) {
                    let s = i[e];
                    if (!Ur.check(s.path, _i(this, ac).trade.Pa)) continue;
                    let r = {
                        floating: !0,
                        mode: Mt(t, s.zj),
                        list: []
                    };
                    if (Object.values({
                            BUY: 0,
                            SELL: 1,
                            BUY_LIMIT: 2,
                            SELL_LIMIT: 3,
                            BUY_STOP: 4,
                            SELL_STOP: 5,
                            BUY_STOP_LIMIT: 6,
                            SELL_STOP_LIMIT: 7
                        }).forEach(t => {
                            var i = [];
                            s.ab.forEach(s => {
                                var e, r = this.Gi(t);
                                r.Od(s, _i(this, rc).j);
                                var a = r.initial.sb.fa,
                                    n = s.Cd;
                                i.push.call(i, {
                                    from: s.Bd,
                                    to: n !== h.FLOAT64_MAX ? n : 1 / 0,
                                    initial: {
                                        rate: r.initial.rate,
                                        sb: a
                                    },
                                    oc: {
                                        rate: r.oc.rate || r.initial.rate,
                                        sb: (null == (e = r.oc.sb) ? void 0 : e.pd()) ? a : r.oc.sb.fa
                                    }
                                })
                            }), r.list[t] = i
                        }), r.list.length) return r
                }
            var s = {
                floating: !1,
                mode: Mt(t),
                list: []
            };
            return Object.values({
                BUY: 0,
                SELL: 1,
                BUY_LIMIT: 2,
                SELL_LIMIT: 3,
                BUY_STOP: 4,
                SELL_STOP: 5,
                BUY_STOP_LIMIT: 6,
                SELL_STOP_LIMIT: 7
            }).forEach(t => {
                var i = [],
                    e = this.Gi(t);
                i.push({
                    initial: {
                        rate: e.initial.rate,
                        sb: e.initial.sb.fa
                    },
                    oc: {
                        rate: e.oc.rate,
                        sb: e.oc.sb.fa
                    }
                }), s.list[t] = i
            }), s
        }
    }
    var ic = new WeakMap,
        sc = new WeakMap,
        ec = new WeakMap,
        rc = new WeakMap,
        ac = new WeakMap,
        hc = new WeakSet,
        nc = function(t, i = !1) {
            var s = _i(this, ac),
                e = _i(this, rc).Cf();
            e.rules = [];
            var r = e.j,
                a = e.ra,
                h = new _l(_i(this, ic), _i(this, sc), e),
                n = new Kl;
            return n.h = s.h, n.T = t, n.Ra = 1n * BigInt(1e8), n.J = n.Ra, n.U = s.I, n.rc = 0, n.i = s.i, n.ca = r, (r = _i(this, ec).ad(s.h, !1)) ? (n.m = 0 === t ? r.L : 1 === t ? r.O : 0, n.m <= 0 ? new Yl(10021) : (n.isBuy() ? n.G = _i(this, ic).Zf(s, a, n.m) : n.G = _i(this, ic).$f(s, a, n.m), n.G <= 0 ? new Yl(10021) : (i ? h.jc([], [], n, !1) : h.jc([n], []), new Yl(0, e.margin)))) : new Yl(10021)
        };
    class oc {
        constructor(t, i, s, e, r) {
            Xi(this, lc), Xi(this, cc), Xi(this, uc), Xi(this, pc), Xi(this, mc), Ri(this, lc, t), Ri(this, cc, i), Ri(this, uc, s), Ri(this, pc, e), Ri(this, mc, r)
        }
        yk(t, i) {
            return (i = _i(this, lc).Ba(i)) ? new tc(_i(this, cc), _i(this, uc), _i(this, pc), _i(this, mc), i).al(t) : null
        }
    }
    var lc = new WeakMap,
        cc = new WeakMap,
        uc = new WeakMap,
        pc = new WeakMap,
        mc = new WeakMap;
    class fc {
        constructor(t) {
            Xi(this, dc), Ri(this, dc, t)
        }
        getLeveragesBySymbol(t, i) {
            return (t = _i(this, dc).yk(t, i)) ? {
                mode: t.mode,
                floating: null == t ? void 0 : t.floating,
                list: t.list.map(t => t.map(t => ({
                    from: t.from,
                    to: t.to,
                    initial: {
                        rate: t.initial.rate,
                        money: t.initial.sb
                    },
                    maintenance: {
                        rate: t.oc.rate,
                        money: t.oc.sb
                    }
                })))
            } : null
        }
    }
    var dc = new WeakMap;
    class bc {
        constructor(t, i, s, e, r) {
            this.controller = new _l(s, e, r.ha()), this.Nl = new oc(t, s, e, i, r.ha()), this.view = new fc(this.Nl)
        }
    }
    class gc {
        constructor(t) {
            Xi(this, yc), Ri(this, yc, t)
        }
        load(t) {
            return _i(this, yc).cl(t)
        }
    }
    var yc = new WeakMap,
        wc = {
            zg: 1,
            Cg: 5,
            Ag: 15,
            Bg: 30,
            xg: 60,
            yg: 240,
            wg: 1440,
            Eg: 10080,
            ck: 43200
        },
        vc = {
            zg: 1,
            Cg: 5,
            Ag: 15,
            Bg: 30,
            xg: 16385,
            yg: 16388,
            wg: 16408,
            Eg: 32769,
            ek: 49153
        };
    class kc extends Is {
        async cl(t) {
            var i = this.C,
                s = i.qa;
            return t = Hi.serialize([
                [11, (t.symbol || "").substring(0, 32), 64],
                [5, Tt(t.period)],
                [3, Math.floor(((null == t ? void 0 : t.from) ?? 0) / 1e3)],
                [3, Math.floor(((null == t ? void 0 : t.to) ?? 0) / 1e3)]
            ]), (await s.call(i, 11, t)).Z
        }
    }
    class Mc {
        constructor(t) {
            Xi(this, Tc), Ri(this, Tc, t)
        }
        getRates(t, i, s, e) {
            return _i(this, Tc).load({
                from: s,
                to: e,
                symbol: t,
                period: i
            })
        }
    }
    var Tc = new WeakMap;
    class zc {
        constructor(t) {
            this.controller = new gc(new kc(t)), this.Lm = new Mc(this.controller)
        }
    }
    class Wc {
        constructor() {
            this.withdrawal = this.deposit = this.credit = this.za = this.Yc = this.commission = this.swap = this.profit = this.balance = 0
        }
        Rd() {
            this.withdrawal = this.deposit = this.credit = this.za = this.Yc = this.commission = this.swap = this.profit = this.balance = 0
        }
        rm(t) {
            var i = t.ca;
            this.balance = s.normalize(this.balance + t.profit, i), t.dj() ? this.credit = s.normalize(this.credit + t.profit, i) : 2 === t.o && t.profit > 0 ? this.deposit = s.normalize(this.deposit + t.profit, i) : 2 === t.o && t.profit < 0 ? this.withdrawal = s.normalize(this.withdrawal + t.profit, i) : t.isBalance() ? (this.profit = s.normalize(this.profit + t.profit, i), this.za = s.normalize(this.za + t.profit, i)) : (this.profit = s.normalize(this.profit + t.profit, i), this.za = s.normalize(this.za + t.profit, i), this.swap = s.normalize(this.swap + t.M, i), this.balance = s.normalize(this.balance + t.M, i), this.za = s.normalize(this.za + t.M, i), this.commission = s.normalize(this.commission + t.commission, i), this.Yc = s.normalize(this.Yc + t.La, i), this.balance = s.normalize(this.balance + t.commission, i), this.za = s.normalize(this.za + t.commission, i), this.balance = s.normalize(this.balance + t.La, i), this.za = s.normalize(this.za + t.La, i))
        }
    }
    var Sc = {
            oi: 0,
            Sc: 1,
            tf: 2,
            hk: 3
        },
        jc = class {
            constructor(t = {}) {
                Xi(this, Bc), Ri(this, Bc, !1), this.wa = 0n, this.Hb = "", this.B = 0n, this.o = this.dd = this.Ca = 0, this.h = "", this.l = 0n, this.M = this.commission = this.gb = this.tb = this.profit = this.la = this.ka = this.ca = this.i = this.D = this.sa = this.entry = this.Eb = 0, this.eb = 0n, this.comment = "", this.La = this.U = 0, this.Zc = "", this.Vd = this.H = 0n, this.value = 0, this.l = t.l ?? 0n, this.wa = t.wa ?? this.wa, this.Hb = t.Hb ?? this.Hb, this.h = t.h ?? this.h, this.entry = t.entry ?? this.entry, this.D = t.D ?? this.D, this.B = t.B ?? this.B, this.dd = t.dd ?? this.dd, this.Ca = t.Ca ?? this.Ca, this.o = t.o ?? this.o, this.Eb = t.Eb ?? this.Eb, this.i = t.i ?? this.i, this.ka = t.ka ?? this.ka, this.la = t.la ?? this.la, this.profit = t.profit ?? this.profit, this.tb = t.tb ?? this.tb, this.gb = t.gb ?? this.gb, this.commission = t.commission ?? this.commission, this.sa = t.sa ?? this.sa, this.M = t.M ?? this.M, this.eb = t.eb ?? this.eb, this.H = t.H ?? this.H, this.comment = t.comment ?? this.comment, this.U = t.U ?? this.U, this.ca = t.ca ?? this.ca, this.La = t.La ?? this.La, this.Zc = t.Zc ?? this.Zc, this.Vd = t.Vd ?? this.Vd
            }
            Cf() {
                return new jc({
                    l: this.l,
                    wa: this.wa,
                    Hb: this.Hb,
                    h: this.h,
                    entry: this.entry,
                    D: this.D,
                    B: this.B,
                    dd: this.dd,
                    Ca: this.Ca,
                    o: this.o,
                    Eb: this.Eb,
                    i: this.i,
                    ka: this.ka,
                    la: this.la,
                    profit: this.profit,
                    tb: this.tb,
                    gb: this.gb,
                    commission: this.commission,
                    sa: this.sa,
                    M: this.M,
                    eb: this.eb,
                    H: this.H,
                    comment: this.comment,
                    U: this.U,
                    ca: this.ca,
                    La: this.La,
                    Zc: this.Zc,
                    Vd: this.Vd,
                    Kn: _i(this, Bc)
                })
            }
            ul() {
                return this.entry === Sc.Sc
            }
            rl() {
                return this.entry === Sc.tf
            }
            ll() {
                return this.entry === Sc.Sc || this.entry === Sc.tf
            }
            isBuy() {
                return 0 === this.o
            }
            isSell() {
                return 1 === this.o
            }
            ij() {
                return 0 === this.o || 1 === this.o
            }
            dj() {
                return 3 === this.o || 6 === this.o
            }
            gh() {
                return [6, 8, 11, 12, 13, 14].includes(this.Eb)
            }
            isBalance() {
                return dt(this.o)
            }
            isBalanceAllowed() {
                return bt(this.o)
            }
            oa() {
                return _i(this, Bc), _i(this, Bc)
            }
        },
        Bc = new WeakMap,
        $c = jc;
    class Lc extends $c {
        constructor() {
            super(...arguments), this.H = 0n, this.h = "", this.Eb = this.u = 0, this.qc = this.eb = 0n, this.cf = this.he = 0, this.cb = 0n, this.U = this.ca = this.i = this.profit = this.M = this.commission = this.Sd = this.Ec = 0
        }
        Ne(t) {
            t.isBalance() ? (this.H = t.wa, this.u = t.o, this.eb = t.eb, this.profit = t.profit, this.Eb = t.Eb, this.qc = 0n, this.he = t.Ca, this.la = this.ka = this.cf = 0, this.cb = 0n, this.Sd = this.Ec = 0, this.comment = t.comment, this.i = t.i, this.ca = t.ca) : t.H && (this.qc ? this.H === t.H && (this.profit = s.normalize(this.profit + t.profit, this.ca), this.M = s.normalize(this.M + t.M, this.ca), this.commission = s.normalize(this.commission + t.commission, this.ca), this.La = s.normalize(this.La + t.La, this.ca), t.isBuy() && 0 === this.u || t.isSell() && 1 === this.u ? (t.gh() || (this.he = Math.min(this.he, t.Ca), this.cf = (Number(this.qc) * this.cf + Number(t.l) * t.sa) / (Number(this.qc) + Number(t.l)), this.qc += t.l, this.ka = t.ka, this.la = t.la), (t.ul() || t.rl()) && (this.Ec = Math.max(this.Ec, t.Ca)), !t.gh() && t.comment && (this.comment = t.comment)) : t.gh() || (this.Ec ? (this.Ec = Math.max(this.Ec, t.Ca), this.Sd = (Number(this.cb) * this.Sd + Number(t.l) * t.sa) / (Number(this.cb) + Number(t.l)), this.cb += t.l) : (this.Ec = t.Ca, this.Sd = t.sa, this.cb = t.l), this.ka = t.ka, this.la = t.la), this.i = t.i, this.ca = t.ca, this.U = t.U) : (this.h = t.h, this.H = t.H, this.u = t.isBuy() ? 0 : 1, this.eb = t.eb, this.Eb = t.Eb, this.qc = t.l, this.he = t.Ca, this.cf = t.sa, this.ka = t.ka, this.la = t.la, this.cb = 0n, this.Sd = this.Ec = 0, this.profit = t.profit, this.M = t.M, this.commission = t.commission, this.La = t.La, this.i = t.i, this.ca = t.ca, this.U = t.U, this.comment = t.comment))
        }
        isBuy() {
            return 0 === this.u
        }
        isSell() {
            return 1 === this.u
        }
        isBalance() {
            return dt(this.u)
        }
    }
    class Nc {
        constructor() {
            this.rejected = this.canceled = this.filled = this.total = 0
        }
        Rd() {
            this.rejected = this.canceled = this.filled = this.total = 0
        }
        rj(t) {
            switch (this.total += 1, t.rc) {
                case 4:
                    this.filled += 1;
                    break;
                case 2:
                    this.canceled += 1;
                    break;
                case 5:
                    this.rejected += 1
            }
        }
    }
    class Ic {
        constructor() {
            this.withdrawal = this.deposit = this.credit = this.za = this.Yc = this.commission = this.swap = this.profit = this.balance = 0
        }
        Rd() {
            this.withdrawal = this.deposit = this.credit = this.za = this.Yc = this.commission = this.swap = this.profit = this.balance = 0
        }
        Ne(t) {
            var i = t.ca;
            this.swap = s.normalize(this.swap + t.M, i), this.commission = s.normalize(this.commission + t.commission, i), this.Yc = s.normalize(this.Yc + t.La, i), this.balance = s.normalize(this.balance + t.profit, i), this.balance = s.normalize(this.balance + t.M, i), this.balance = s.normalize(this.balance + t.commission, i), this.balance = s.normalize(this.balance + t.La, i), t.ij() ? (this.profit = s.normalize(this.profit + t.profit, i), this.za = s.normalize(this.za + t.profit, i), this.za = s.normalize(this.za + t.M, i), this.za = s.normalize(this.za + t.commission, i), this.za = s.normalize(this.za + t.La, i)) : t.dj() ? this.credit = s.normalize(this.credit + t.profit, i) : 2 === t.o && t.profit > 0 ? this.deposit = s.normalize(this.deposit + t.profit, i) : 2 === t.o && t.profit < 0 ? this.withdrawal = s.normalize(this.withdrawal + t.profit, i) : t.isBalance() && (this.profit = s.normalize(this.profit + t.profit, i), this.za = s.normalize(this.za + t.profit, i))
        }
    }
    class Ac {
        constructor() {
            Xi(this, Cc, !1), Xi(this, Ec, null), Xi(this, Dc, null), Xi(this, Oc, null), Xi(this, xc, null), Xi(this, Fc, null), Xi(this, Uc, null), Xi(this, Pc, null), Xi(this, qc, null), Xi(this, _c, null)
        }
        Ea() {
            Ri(this, xc, null), Ri(this, Ec, null), Ri(this, Uc, null), Ri(this, Fc, null), Ri(this, Dc, null), Ri(this, Oc, null)
        }
        Da(t) {
            var i, s;
            null == (i = _i(this, xc)) || i.push(t), null == (s = _i(this, qc)) || s.rj(t)
        }
        Zm(t) {
            Ri(this, xc, t), this.Ak()
        }
        Vb() {
            return _i(this, xc) && [..._i(this, xc)] || []
        }
        Tg() {
            return _i(this, qc)
        }
        Ak() {
            var t;
            _i(this, qc) || Ri(this, qc, new Nc), _i(this, qc).Rd(), null == (t = _i(this, xc)) || t.forEach(t => {
                var i;
                null == (i = _i(this, qc)) || i.rj(t)
            })
        }
        fb(t) {
            var i;
            if (!(null == (i = _i(this, Fc)) ? void 0 : i.length)) return null;
            for (var s = 0, e = _i(this, Fc).length; s < e;) {
                let i = Math.floor(s + (e - s) / 2),
                    r = _i(this, Fc)[i] && _i(this, Fc)[i].B;
                if (r === t) return _i(this, Fc)[i];
                r > t ? e = i - 1 : s = i + 1
            }
            return null
        }
        cg(t, i) {
            if (_i(this, xc)) {
                var s = _i(this, xc) && _i(this, xc).findIndex(i => i.B === t); - 1 !== s && (i ? _i(this, xc)[s] = i : _i(this, xc).splice(s, 1), this.hb())
            }
        }
        Fg(t) {
            var i, s;
            null == (i = _i(this, Ec)) || i.push(t), null == (s = _i(this, _c)) || s.Ne(t)
        }
        Xm(t) {
            Ri(this, Ec, t), this.xk()
        }
        Qg() {
            var t;
            return (null == (t = _i(this, Ec)) ? void 0 : t.slice()) ?? []
        }
        Rg() {
            return _i(this, _c)
        }
        xk() {
            var t;
            _i(this, _c) || Ri(this, _c, new Ic), _i(this, _c).Rd(), null == (t = _i(this, Ec)) || t.forEach(t => {
                var i;
                null == (i = _i(this, _c)) || i.Ne(t)
            })
        }
        Gf(t) {
            var i;
            if (!(null == (i = _i(this, Dc)) ? void 0 : i.length)) return null;
            for (var s = 0, e = _i(this, Dc).length; s < e;) {
                let i = Math.floor(s + (e - s) / 2),
                    r = _i(this, Dc)[i] && _i(this, Dc)[i].wa;
                if (r === t) return _i(this, Dc)[i];
                r > t ? e = i - 1 : s = i + 1
            }
            return null
        }
        Hf(t) {
            var i;
            if (!(null == (i = _i(this, Oc)) ? void 0 : i.length)) return null;
            t = t.toString();
            for (var s = 0, e = _i(this, Oc).length; s < e;) {
                let i = Math.floor(s + (e - s) / 2),
                    r = _i(this, Oc)[i] && _i(this, Oc)[i].H.toString();
                if (r === t) return _i(this, Oc)[i];
                r > t ? e = i - 1 : s = i + 1
            }
            return null
        }
        Pg(t, i) {
            return t.nc() ? this.Hf(i) : null
        }
        ag(t, i) {
            if (_i(this, Ec)) {
                var s = _i(this, Ec).findIndex(i => i.wa === t);
                "number" == typeof s && -1 !== s && (i ? _i(this, Ec)[s] = i : _i(this, Ec).splice(s, 1), this.hb())
            }
        }
        Ib() {
            return _i(this, Uc) && [..._i(this, Uc)] || []
        }
        Ug() {
            return _i(this, Pc)
        }
        vk() {
            Ri(this, Uc, []), _i(this, Pc) || Ri(this, Pc, new Wc), _i(this, Pc).Rd(), _i(this, Ec) && ([..._i(this, Ec)].sort(jt).forEach(t => this.qg(t)), this.Fi(), _i(this, Uc).sort(St))
        }
        qg(t, i = !1) {
            var s, e = t.isBalance() ? t.wa : t.H,
                r = _i(this, Uc) && _i(this, Uc).find(i => i.H === e && dt(i.u) === dt(t.o));
            r ? r.Ne(t) : ((r = new Lc).Ne(t), null == (s = _i(this, Uc)) || s.push(r), i && _i(this, Uc) && _i(this, Uc).sort(St))
        }
        Fi() {
            _i(this, Pc) || Ri(this, Pc, new Wc), _i(this, Pc).Rd(), _i(this, Ec) && _i(this, Ec).forEach(t => {
                var i, s = t.isBalance() ? t.wa : t.H,
                    e = _i(this, Uc) && _i(this, Uc).find(i => i.H === s && dt(i.u) === dt(t.o));
                e && (e.cb || e.isBalance()) && (null == (i = _i(this, Pc)) || i.rm(t))
            })
        }
        hb() {
            _i(this, Ec) && (Ri(this, Dc, [..._i(this, Ec)].sort(Bt)), Ri(this, Oc, [..._i(this, Ec)].sort(Wt)), Ri(this, Cc, _i(this, Ec).some(t => !!t.Hb))), _i(this, xc) && (Ri(this, Fc, [..._i(this, xc)].sort(zt)), _i(this, Cc) || Ri(this, Cc, _i(this, xc).some(t => !!t.yd)))
        }
    }
    var Cc = new WeakMap,
        Ec = new WeakMap,
        Dc = new WeakMap,
        Oc = new WeakMap,
        xc = new WeakMap,
        Fc = new WeakMap,
        Uc = new WeakMap,
        Pc = new WeakMap,
        qc = new WeakMap,
        _c = new WeakMap;
    class Xc {
        constructor(t, i) {
            Xi(this, Rc), Xi(this, Vc, new Ac), Xi(this, Hc), Xi(this, Gc, t => {
                var i = t.deals,
                    s = t.orders;
                return _i(this, Vc).Zm(s), _i(this, Vc).Xm(i), _i(this, Vc).hb(), _i(this, Vc).vk(), t
            }), Ri(this, Rc, t), Ri(this, Hc, i)
        }
        async Ql(t) {
            t = await _i(this, Rc).gl(t), _i(this, Gc).call(this, t)
        }
        destroy() {
            _i(this, Vc).Ea()
        }
        Da(t) {
            _i(this, Vc).Da(t)
        }
        hb() {
            _i(this, Vc).hb()
        }
        fb(t) {
            return _i(this, Vc).fb(t)
        }
        Pg(t) {
            return _i(this, Vc).Pg(_i(this, Hc).ha(), t)
        }
        cg(t, i) {
            _i(this, Vc).cg(t, i)
        }
        Gf(t) {
            return _i(this, Vc).Gf(t)
        }
        Hf(t) {
            return _i(this, Vc).Hf(t)
        }
        qg(t, i = !1) {
            _i(this, Vc).qg(t, i), _i(this, Vc).Fi()
        }
        ag(t, i) {
            _i(this, Vc).ag(t, i)
        }
        Fg(t) {
            _i(this, Vc).Fg(t)
        }
        Qg() {
            return _i(this, Vc).Qg()
        }
        Rg() {
            return _i(this, Vc).Rg()
        }
        Vb() {
            return _i(this, Vc).Vb()
        }
        Tg() {
            return _i(this, Vc).Tg()
        }
        Ib() {
            return _i(this, Vc).Ib()
        }
        Ug() {
            return _i(this, Vc).Ug()
        }
    }
    var Rc = new WeakMap,
        Vc = new WeakMap,
        Hc = new WeakMap,
        Gc = new WeakMap,
        Jc = [{
            propType: 17
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 6
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 3
        }, {
            propType: 3
        }],
        Kc = Hi.getSeriesSize(Jc),
        Yc = [{
            propType: 17
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 17
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 18
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 3
        }, {
            propType: 3
        }, {
            propType: 8
        }],
        Zc = Hi.getSeriesSize(Yc);
    class Qc extends Is {
        async gl(t) {
            return {
                deals: At(t = (await this.C.qa(5, function({
                    from: t,
                    to: i
                }) {
                    return Int32Array.from([t, i]).buffer
                }(t))).Z, 0),
                orders: Lt(t, It(t, 0))
            }
        }
    }
    class tu {
        constructor(t) {
            Xi(this, iu), Ri(this, iu, t)
        }
        async load(t) {
            await _i(this, iu).Ql(t)
        }
        deals() {
            return {
                items: _i(this, iu).Qg().map(su.from),
                total: eu.from(_i(this, iu).Rg())
            }
        }
        orders() {
            return {
                items: _i(this, iu).Vb().map(ru.from),
                total: au.from(_i(this, iu).Tg())
            }
        }
        positions() {
            var t = [];
            return _i(this, iu).Ib().forEach(i => {
                i.isBalance() ? t.push(new nu(i)) : i.cb && t.push(new hu(i))
            }), {
                items: t.sort((t, i) => t.timeOpen - i.timeOpen),
                total: eu.from(_i(this, iu).Ug())
            }
        }
    }
    var iu = new WeakMap;
    class su {
        constructor(t) {
            this.isSell = this.isBuy = !1, this.symbol = t.h, this.timeCreate = t.Ca, this.deal = t.wa.toString(), this.id = t.Hb, this.order = t.B ? t.B.toString() : "", this.position = Ct(t), this.action = t.o, this.isBuy = t.isBuy(), this.isSell = t.isSell(), this.isBalance = t.isBalance(), this.entry = function(t) {
                switch (t.entry) {
                    case Sc.oi:
                        return "in";
                    case Sc.Sc:
                        return "out";
                    case Sc.tf:
                        return "in/out";
                    case Sc.hk:
                        return "out by";
                    default:
                        return ""
                }
            }(t), this.volume = D(t.l), this.volumeValue = I(t.l), this.tradeReason = t.Eb, this.volumeSize = E(A(t.l, t.U)), this.priceOpen = s.normalize(t.sa, t.i + 3), this.priceClose = s.normalize(t.D, t.i + 3), this.commission = t.commission, this.commissionFee = t.La, this.storage = t.M, this.digits = t.i, this.digitsCurrency = t.ca, this.comment = t.comment || "", (t.ll() || t.profit) && (this.profit = s.normalize(t.profit, t.ca))
        }
        static from(t) {
            return new su(t)
        }
    }
    class eu {
        constructor(t) {
            this.withdrawal = this.deposit = this.credit = this.buysell = this.commissionFee = this.commission = this.swap = this.profit = this.balance = 0, t && (this.balance = t.balance, this.profit = t.profit, this.swap = t.swap, this.commission = t.commission, this.commissionFee = t.Yc, this.buysell = t.za, this.credit = t.credit, this.deposit = t.deposit, this.withdrawal = t.withdrawal)
        }
        static from(t) {
            return new eu(t)
        }
    }
    class ru {
        constructor(t) {
            this.price = null, this.timeSetup = t.kf, this.timeDone = t.jg, this.order = t.B.toString(), this.id = t.yd, this.symbol = t.h, this.type = t.T, this.typeReason = t.Pc, this.volume = Ft(t, !1), this.volumeValue = I(t.Ra), this.volumeSize = Ft(t, !0), this.digits = t.i, this.digitsCurrency = t.ca, t.m && (this.price = s.normalize(t.m, t.i)), this.sl = s.normalize(t.v, t.i), this.tp = s.normalize(t.A, t.i), this.comment = t.comment, this.state = t.rc
        }
        static from(t) {
            return new ru(t)
        }
    }
    class au {
        constructor(t) {
            this.rejected = this.canceled = this.filled = this.total = 0, t && (this.total = t.total, this.filled = t.filled, this.canceled = t.canceled, this.rejected = t.rejected)
        }
        static from(t) {
            return new au(t)
        }
    }
    class hu {
        constructor(t) {
            this.isBalance = this.isSell = this.isBuy = !1, this.id = Ct(t), this.comment = t.comment || "", this.timeOpen = t.he, this.sl = s.normalize(t.ka, t.i), this.tp = s.normalize(t.la, t.i), this.digits = t.i, this.digitsCurrency = t.ca, this.type = t.u, this.isBuy = t.isBuy(), this.isSell = t.isSell(), this.isBalance = t.isBalance(), t.qc === t.cb ? (this.volume = D(t.qc), this.volumeValue = I(t.qc), this.volumeSize = E(A(t.qc, t.U))) : (this.volume = D(t.cb), this.volumeValue = I(t.cb), this.volumeSize = E(A(t.cb, t.U))), t.cb && (this.timeClose = t.Ec), this.symbol = t.h, this.priceOpen = s.normalize(t.cf, this.digits + 3), this.priceClose = s.normalize(t.Sd, this.digits + 3), this.commission = s.normalize(t.commission || 0, this.digitsCurrency), this.commissionFee = s.normalize(t.La || 0, this.digitsCurrency), (t.profit || t.isBalance()) && (this.profit = s.normalize(t.profit || 0, this.digitsCurrency)), t.cb && (this.storage = s.normalize(t.M || 0, this.digitsCurrency))
        }
        static from(t) {
            return new hu(t)
        }
    }
    class nu extends hu {
        static from(t) {
            return new nu(t)
        }
        constructor(t) {
            super(t), this.id = Ct(t), this.comment = t.comment || "", this.timeOpen = t.he, this.digits = t.i, this.digitsCurrency = t.ca, this.type = t.u, (t.profit || t.isBalance()) && (this.profit = s.normalize(t.profit, this.digitsCurrency)), t.cb && (this.storage = s.normalize(t.M || 0, this.digitsCurrency))
        }
    }
    class ou {
        constructor(t, i) {
            this.controller = new Xc(new Qc(t), i), this.view = new tu(this.controller)
        }
    }
    class lu {
        constructor() {
            Xi(this, cu), Xi(this, uu), Ri(this, cu, []), Ri(this, uu, []), this.has = {}
        }
        Ib() {
            return [..._i(this, cu)]
        }
        Vb() {
            return [..._i(this, uu)]
        }
        Ea() {
            Ri(this, cu, []), Ri(this, uu, []), this.has.id = !1, this.has.wm = !1, this.has.xm = !1, this.has.jm = !1, this.has.km = !1
        }
        hb() {
            this.has.wm = _i(this, cu).some(t => !!t.ka), this.has.xm = _i(this, cu).some(t => !!t.la), this.has.jm = _i(this, uu).some(t => !!t.v), this.has.km = _i(this, uu).some(t => !!t.A)
        }
        Da(t) {
            if (!t) return !1;
            var i = t.B;
            return !_i(this, uu).some(t => t.B === i) && (t.df = new Kl, _i(this, uu).push(t), t.yd && (this.has.id = !0), !0)
        }
        Fb(t) {
            return t.df = new $c, _i(this, cu).push(t), t.Zc && (this.has.id = !0), !0
        }
        bg(t, i = null) {
            if (!t) return !1;
            var s = t.B;
            return -1 !== (t = _i(this, uu).findIndex(t => t.B === s)) && (i ? _i(this, uu)[t] = i : _i(this, uu).splice(t, 1), !0)
        }
        dg(t, i = null) {
            return (t = t.H ? this.Xa(t.H, !0) : this.$c(t.h, !0)) > -1 && (i ? _i(this, cu)[t] = i : _i(this, cu).splice(t, 1), !0)
        }
        fb(t) {
            return _i(this, uu).find(i => i.B === t) ?? null
        }
        Se(t) {
            return _i(this, uu).filter(i => i.h === t)
        }
        Xa(t, i) {
            return t ? i ? _i(this, cu).findIndex(i => i.H === t) : _i(this, cu).find(i => i.H === t) ?? null : null
        }
        $c(t, i) {
            return i ? _i(this, cu).findIndex(i => i.h === t) : _i(this, cu).find(i => i.h === t) ?? null
        }
        Te(t) {
            return _i(this, cu).filter(i => i.h === t)
        }
        rg(t) {
            return !(!_i(this, uu).some(i => i.h === t) && !_i(this, cu).some(i => i.h === t))
        }
    }
    var cu = new WeakMap,
        uu = new WeakMap,
        pu = new Map;
    class mu {
        constructor(t, i, s, e, r, a, h) {
            Xi(this, Su), Xi(this, fu, null), Xi(this, du, new Set), Xi(this, bu), Xi(this, gu), Xi(this, yu), Xi(this, wu), Xi(this, vu, new lu), Xi(this, ku), Xi(this, Mu), Xi(this, Tu), Xi(this, zu, t => {
                var i = t.positions;
                i && i.forEach(t => {
                    this.Fb(t)
                }), (t = t.orders) && t.forEach(t => {
                    this.Da(t)
                })
            }), Xi(this, Wu, t => {
                t = t.h;
                var i = pu.get(t);
                i || (i = Vi(this, Su, ju).bind(this, t), pu.set(t, i)), _i(this, du).add(i), _i(this, fu) || Ri(this, fu, setTimeout(() => {
                    _i(this, du).forEach(t => t()), _i(this, du).clear(), Ri(this, fu, null)
                }, 200))
            }), Ri(this, bu, t), Ri(this, gu, i), Ri(this, yu, s), Ri(this, wu, e), Ri(this, ku, r), Ri(this, Mu, a), Ri(this, Tu, h)
        }
        Ck(t, i, s, e, r) {
            t = _i(this, wu).Ba(t);
            var a = _i(this, ku).ha();
            return i = new $c({
                l: C(i),
                sa: e,
                D: r,
                o: s ? 0 : 1,
                U: null == t ? void 0 : t.I
            }), t && qt(t, i, a, s = _i(this, Mu).sc(t, t.Aa, a.ra), e = _i(this, Mu).Kc(t, t.Aa, a.ra), !1), i.profit
        }
        async init() {
            await this.Rl()
        }
        async Rl() {
            var t = await _i(this, gu).il(),
                i = [...(null == t ? void 0 : t.orders) ?? [], ...(null == t ? void 0 : t.positions) ?? []].map(({
                    h: t
                }) => t);
            await Vi(this, Su, Bu).call(this, i), _i(this, zu).call(this, t)
        }
        Re() {
            return [..._i(this, vu).Vb().map(t => t.h).filter(Boolean), ..._i(this, vu).Ib().map(t => t.h).filter(Boolean)]
        }
        destroy() {
            _i(this, yu).Fd(), this.Re().forEach(t => _i(this, yu).da(t, _i(this, Wu))), _i(this, vu).Ea(), pu = new Map
        }
        Da(t) {
            _i(this, vu).Da(t) && (t = t.h, _i(this, yu).Fd(this.Re()), _i(this, yu).V(t, _i(this, Wu)))
        }
        bg(t, i = null) {
            return (i = _i(this, vu).bg(t, i)) && (t = null == t ? void 0 : t.h) && !_i(this, vu).rg(t) && _i(this, yu).da(t, _i(this, Wu)), _i(this, yu).Fd(this.Re()), i
        }
        Fb(t) {
            _i(this, vu).Fb(t) && (_i(this, yu).Fd(this.Re()), t = t.h, _i(this, yu).V(t, _i(this, Wu)))
        }
        dg(t, i = null) {
            _i(this, vu).dg(t, i) && (t = null == t ? void 0 : t.h) && !_i(this, vu).rg(t) && (_i(this, yu).Fd(this.Re()), _i(this, yu).da(t, _i(this, Wu)))
        }
        rg(t) {
            return _i(this, vu).rg(t)
        }
        Ib() {
            return _i(this, vu).Ib()
        }
        Vb() {
            return _i(this, vu).Vb()
        }
        fb(t) {
            return _i(this, vu).fb(t)
        }
        hb() {
            _i(this, vu).hb()
        }
        $c(t) {
            return _i(this, vu).$c(t)
        }
        Xa(t) {
            return _i(this, vu).Xa(t)
        }
        Se(t) {
            return _i(this, vu).Se(t)
        }
        Te(t) {
            return _i(this, vu).Te(t)
        }
    }
    var fu = new WeakMap,
        du = new WeakMap,
        bu = new WeakMap,
        gu = new WeakMap,
        yu = new WeakMap,
        wu = new WeakMap,
        vu = new WeakMap,
        ku = new WeakMap,
        Mu = new WeakMap,
        Tu = new WeakMap,
        zu = new WeakMap,
        Wu = new WeakMap,
        Su = new WeakSet,
        ju = function(t) {
            var i = _i(this, vu).Se(t),
                s = _i(this, vu).Te(t);
            if (i.length || s.length) {
                var e = _i(this, wu).Ba(t);
                if (e) {
                    var r = _i(this, yu).ad(t, e.od());
                    if (r) {
                        var a = Pt(e, r);
                        if (e.Ta() || !(a.O <= 0 || a.L <= 0)) {
                            var h = _i(this, ku).ha(),
                                n = _i(this, Mu).sc(e, e.Aa, h.ra),
                                o = _i(this, Mu).Kc(e, e.Aa, h.ra);
                            n && o && s.length && (s.forEach(t => {
                                if (e) {
                                    let i = 0;
                                    if (e.oa()) h.$d() ? i = r.Na ?? i : r.Na ? i = r.Na : (t.isBuy() && (i = r.O), t.isSell() && (i = r.L));
                                    else {
                                        let s = Pt(e, r);
                                        t.isBuy() && (i = s.O), t.isSell() && (i = s.L)
                                    }
                                    i && (t.D = i, qt(e, t, h, n, o)), qt(e, t, h, n, o, e.oa()), _i(this, bu).aa(4, t.H.toString())
                                }
                            }), _i(this, Tu).jc(this.Vb(), this.Ib()), _i(this, Tu).Dc(h), _i(this, bu).aa(3)), i.length && i.forEach(t => {
                                switch (t.T) {
                                    case 0:
                                    case 2:
                                    case 4:
                                    case 6:
                                        a.L && (t.Nb = a.L);
                                        break;
                                    case 1:
                                    case 3:
                                    case 5:
                                    case 7:
                                        a.O && (t.Nb = a.O)
                                }
                                _i(this, bu).aa(5, t.B.toString())
                            })
                        }
                    }
                }
            }
        },
        Bu = async function(t) {
            var i = [],
                s = [],
                e = [];
            t.forEach((t, r) => {
                var a = _i(this, wu).Ma(t);
                a && (a instanceof Ir ? s.push(a) : (s.push(null), e.push({
                    Yg: r,
                    symbol: t
                }), i.push(a.ta)))
            }), i.length && (await _i(this, wu).cd(i), e.forEach(({
                Yg: t,
                symbol: i
            }) => {
                (i = _i(this, wu).Ma(i)) && i instanceof Ir && (s[t] = i)
            }))
        }, $u = [{
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 18
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 3
        }, {
            propType: 3
        }], Lu = Hi.getSeriesSize($u);
    class Nu extends Is {
        async il() {
            var t = (await this.C.qa(4)).Z;
            return {
                positions: Rt(t, 0),
                orders: Lt(t, Xt(t, 0))
            }
        }
    }
    var Iu = class {
            constructor(t) {
                Xi(this, Au), Ri(this, Au, t)
            }
            static Pi(t) {
                var i = t.h,
                    e = Ct(t),
                    r = t.Zc,
                    a = t.Ca,
                    h = t.dd,
                    n = ft(t.o),
                    o = t.o,
                    l = D(t.l),
                    c = I(t.l),
                    u = E(A(t.l, t.U)),
                    p = s.normalize(t.sa, t.i),
                    m = s.normalize(t.D, t.i + 3),
                    f = s.normalize(t.ka, t.i),
                    d = s.normalize(t.la, t.i),
                    b = s.normalize(t.M || 0, t.ca),
                    g = s.normalize(t.profit || 0, t.ca),
                    y = 0 === Number(t.profit) ? null : t.profit > 0,
                    w = t.comment || "",
                    v = Ot(t),
                    k = Dt(t, Ct(t) || t.Hb);
                return new Eu({
                    symbol: i,
                    id: e,
                    Qk: r,
                    Vh: a,
                    nn: h,
                    hi: n,
                    pn: o,
                    volume: l,
                    ji: c,
                    ii: u,
                    priceOpen: p,
                    priceClose: m,
                    ka: f,
                    la: d,
                    M: b,
                    profit: g,
                    Jm: y,
                    comment: w,
                    info: v,
                    ol: k,
                    isBuy: t.isBuy(),
                    isSell: t.isSell(),
                    i: t.i,
                    Mg: t.ca
                })
            }
            static Tk(t) {
                return new Du({
                    id: Ct(t),
                    symbol: t.h,
                    Vh: t.Ca,
                    action: ft(t.o),
                    volume: D(t.l),
                    ii: E(A(t.l, t.U)),
                    priceClose: O(t.D, t.i, 3),
                    comment: t.comment || "",
                    info: Ot(t)
                })
            }
            static Oi(t) {
                var i = new Ou({
                    symbol: t.h,
                    order: t.B.toString(),
                    id: t.yd,
                    timeSetup: t.kf,
                    type: t.T,
                    hi: pt(t.T),
                    isBuy: t.isBuy(),
                    isSell: t.isSell(),
                    nd: t.nd(),
                    Zd: t.Zd(),
                    isLimit: t.isLimit(),
                    isMarket: t.isMarket(),
                    bh: t.bh(),
                    isPending: t.isPending(),
                    isStop: t.isStop(),
                    isStopLimit: t.isStopLimit(),
                    ji: I(t.Ra),
                    volume: Ft(t),
                    vn: Ft(t, !0),
                    price: s.normalize(t.m, t.i),
                    ka: s.normalize(t.v, t.i),
                    la: s.normalize(t.A, t.i),
                    zm: s.normalize(t.Nb, t.i + 3),
                    state: t.rc,
                    comment: t.comment || "",
                    info: Ut(t),
                    i: t.i,
                    Mg: t.ca,
                    expiration: t.ya,
                    date: t.ua,
                    Sk: t.ea
                });
                return t.isStopLimit() && (i.Am = O(t.m, t.i), i.Bm = t.K), i
            }
            getPosition(t) {
                return (t = _i(this, Au).Xa(BigInt(t))) ? Iu.Pi(t) : null
            }
            getPositions() {
                var t = {
                    items: []
                };
                return _i(this, Au).Ib().forEach(i => {
                    i.oa() ? t.collateral = Iu.Tk(i) : t.items.push(Iu.Pi(i))
                }), t
            }
            getOrder(t) {
                return (t = _i(this, Au).fb(BigInt(t))) ? Iu.Oi(t) : null
            }
            getOrders() {
                return _i(this, Au).Vb().map(t => Iu.Oi(t))
            }
            calcProfit(t, i, s, e, r) {
                return _i(this, Au).Ck(t, i, s, e, r)
            }
        },
        Au = new WeakMap,
        Cu = Iu;
    class Eu {
        constructor(t) {
            this.symbol = t.symbol, this.id = t.id, this.externalId = t.Qk, this.timeCreate = t.Vh, this.timeUpdate = t.nn, this.typeName = t.hi, this.volume = t.volume, this.volumeValue = t.ji, this.volumeSize = t.ii, this.priceOpen = t.priceOpen, this.priceClose = t.priceClose, this.sl = t.ka, this.tp = t.la, this.storage = t.M, this.profit = t.profit, this.comment = t.comment, this.info = t.info, this.infoTemplate = t.ol, this.profitState = t.Jm, this.tradeAction = t.pn, this.isBuy = t.isBuy, this.isSell = t.isSell, this.digits = t.i, this.digitsCurrency = t.Mg
        }
    }
    class Du {
        constructor(t) {
            this.id = t.id, this.symbol = t.symbol, this.timeCreate = t.Vh, this.typeName = t.action, this.volume = t.volume, this.volumeSize = t.ii, this.priceClose = t.priceClose, this.comment = t.comment, this.info = t.info
        }
    }
    class Ou {
        constructor(t) {
            this.symbol = t.symbol, this.order = t.order, this.id = t.id, this.timeSetup = t.timeSetup, this.type = t.type, this.typeName = t.hi, this.volume = t.volume, this.volumeValue = t.ji, this.volumeLots = t.vn, this.price = t.price, this.sl = t.ka, this.tp = t.la, this.priceCurrent = t.zm, this.state = t.state, this.comment = t.comment, this.info = t.info, this.priceOrder = t.Am, this.priceTrigger = t.Bm, this.isBuy = t.isBuy, this.isSell = t.isSell, this.isClose = t.nd, this.isCloseBy = t.Zd, this.isLimit = t.isLimit, this.isMarket = t.isMarket, this.isMarketPrice = t.bh, this.isPending = t.isPending, this.isStop = t.isStop, this.isStopLimit = t.isStopLimit, this.digits = t.i, this.digitsCurrency = t.Mg, this.expiration = t.expiration, this.date = t.date, this.filling = t.Sk
        }
    }
    class xu {
        constructor(t, i, s, e, r, a, h) {
            this.controller = new mu(t, new Nu(i), s, e, r, a, h), this.view = new Cu(this.controller)
        }
    }
    var Fu = {
        vf: 0,
        Tc: 1,
        fd: 2,
        Ge: 3,
        Ee: 4
    };
    class Uu {
        constructor(t) {
            this.isSell = t.isSell(), this.isBuy = t.isBuy(), this.isSpread = t.zl(), this.price = t.price, this.volume = t.l, this.volumeLots = t.qn, this.ratio = t.ratio;
            var i = t.orders.map(t => ({
                    isSell: t.isSell(),
                    type: Ht(t.T),
                    volume: I(t.Ra)
                })),
                s = t.Rh.map(t => ({
                    isSell: !t.isSell(),
                    type: 5,
                    volume: I(t.l)
                }));
            t = t.Yh.map(t => ({
                isSell: !t.isSell(),
                type: 6,
                volume: I(t.l)
            })), this.actions = [...i, ...s, ...t]
        }
    }
    var Pu = class {
            constructor(t, i, e, r, a, h = !1) {
                Xi(this, qu), this.orders = [], this.positions = [], this.Rh = [], this.Yh = [], this.ratio = 0, this.vc = t.vc, this.ba = t.ba, this.price = i, this.l = I(t.l), this.qn = a ? s.normalize(this.l / a, 8) : 0, Ri(this, qu, h), this.zk(e), this.Bk(r)
            }
            static Th(t, i, s, e, r = !1) {
                return new Pu({
                    vc: 1,
                    ba: t,
                    price: 0n,
                    l: 0n
                }, i, s, e, 0, r)
            }
            Qe() {
                return new Uu(this)
            }
            Bk(t) {
                this.positions = [], this.Rh = [], this.Yh = [], t.forEach(t => {
                    t.sa === this.price && this.positions.push(t), t.ka === this.price && this.Rh.push(t), t.la === this.price && this.Yh.push(t)
                })
            }
            zk(t) {
                this.orders = [], t.forEach(t => {
                    t.m === this.price && this.orders.push(t)
                })
            }
            fj() {
                return this.ba === Fu.fd
            }
            gj() {
                return this.ba === Fu.Tc
            }
            isBuy() {
                return this.fj() || this.ba === Fu.Ee
            }
            isSell() {
                return this.gj() || this.ba === Fu.Ge
            }
            zl() {
                return _i(this, qu)
            }
        },
        qu = new WeakMap,
        _u = Pu;
    class Xu {
        constructor(t) {
            this.symbol = t.symbol, this.digits = t.X.i, this.books = t.Af.map(t => t.Qe()), this.extendedBooks = [...t.eg, ...t.spread, ...t.Bf].map(t => t.Qe())
        }
    }
    class Ru {
        constructor(t, i, s, e = [], r = []) {
            Xi(this, Yu), Xi(this, Vu), Xi(this, Hu), Xi(this, Gu), Xi(this, Ju), Xi(this, Ku), Ri(this, Vu, []), Ri(this, Hu, !0), Ri(this, Gu, []), Ri(this, Ju, []), this.Jg = this.vc = 0, this.Af = [], this.eg = [], this.spread = [], this.Bf = [], this.ec = "ignored", this.X = i, this.symbol = i.h, this.gg = s, Ri(this, Ku, Gt(i)), this.ec = this.Bi(t, e, r)
        }
        static Qe(t) {
            return new Xu(t)
        }
        Qe() {
            return new Xu(this)
        }
        Bi(t, i = [], s = []) {
            if (this.vc = t[3], this.Jg = t[4], Ri(this, Gu, i), Ri(this, Ju, s), _i(this, Hu)) {
                if (!(t = Vi(this, Yu, Zu).call(this, t[6]))) return this.ec = "ignored"
            } else {
                if (2 & this.Jg) return this.ec = "ignored";
                if (!(t = Vi(this, Yu, Qu).call(this, t[6]))) return Ri(this, Hu, !0), this.ec = "corrupted"
            }
            return t.sort(Jt), (i = Vi(this, Yu, tp).call(this, t)) ? (Ri(this, Vu, t), Ri(this, Hu, !1), Vi(this, Yu, hp).call(this, i), Ri(this, Ku, Gt(this.X)), this.ec = "applied") : (Ri(this, Hu, !0), this.ec = "corrupted")
        }
        Mm(t, i = [], s = []) {
            var e = Gt(t),
                r = _i(this, Ku);
            return r = !(r.i === e.i && r.Ga === e.Ga && r.Ij === e.Ij && r.uj === e.uj && r.fg === e.fg && r.Fj === e.Fj && r.qj === e.qj && r.Li === e.Li), this.X = t, this.symbol = t.h, Ri(this, Gu, i), Ri(this, Ju, s), !(!r || _i(this, Hu) || !(t = Vi(this, Yu, tp).call(this, _i(this, Vu))) || (Vi(this, Yu, hp).call(this, t), Ri(this, Ku, e), 0))
        }
        hf(t) {
            var i = this.gg;
            return this.gg = t, !_i(this, Hu) && ((t = Vi(this, Yu, tp).call(this, _i(this, Vu))) ? (Vi(this, Yu, hp).call(this, t), !0) : (this.gg = i, !1))
        }
    }
    var Vu = new WeakMap,
        Hu = new WeakMap,
        Gu = new WeakMap,
        Ju = new WeakMap,
        Ku = new WeakMap,
        Yu = new WeakSet,
        Zu = function(t) {
            if (2 & this.Jg) return t.map(Vt);
            var i = t.findIndex(t => t[1] === Fu.vf);
            return -1 === i ? null : t.slice(i + 1).map(Vt)
        },
        Qu = function(t) {
            var i = _i(this, Vu).map(t => ({
                    ...t
                })),
                s = !1;
            if (t.forEach(t => {
                    if (!s) {
                        var e = Vt(t);
                        if (e.ba === Fu.vf) i.length = 0;
                        else if (t = i.findIndex(t => t.ba === e.ba && t.price === e.price), 0n === e.l) - 1 === t ? s = !0 : i.splice(t, 1);
                        else if (-1 === t) i.push(e);
                        else {
                            var r = i[t].l + e.l;
                            0n === r ? i.splice(t, 1) : i[t] = {
                                ...i[t],
                                l: r
                            }
                        }
                    }
                }), s || i.some(t => t.l < 0n)) return null;
            t = i.filter(t => t.ba === Fu.fd).length;
            var e = i.filter(t => t.ba === Fu.Tc).length;
            return t > this.X.Bc || e > this.X.Bc ? null : i
        },
        tp = function(t) {
            var i = this.X.i,
                s = this.X.Ga,
                e = this.X.trade,
                r = this.X.I,
                a = [],
                n = !1;
            return t.forEach(t => {
                if (!n) {
                    var r = h.toDouble64(t.price, i);
                    e.Ia && (t.ba === Fu.Tc ? r = J(e.Ia, e.Cb, s, i, r) : t.ba === Fu.fd && (r = G(e.Ia, e.Cb, s, i, r))), !Number.isFinite(r) || r < 0 && !this.X.Ta() ? n = !0 : a.push({
                        raw: t,
                        price: r
                    })
                }
            }), n ? null : ((t = e.zd) && t < this.X.Bc && Vi(this, Yu, ip).call(this, a, t), t = a.filter(({
                raw: t
            }) => t.ba !== Fu.vf).map(({
                raw: t,
                price: i
            }) => new _u(t, i, _i(this, Gu), _i(this, Ju), r)), Vi(this, Yu, sp).call(this, t), Vi(this, Yu, ep).call(this, t))
        },
        ip = function(t, i) {
            if (t.length) {
                var s = -1;
                t.forEach((t, i) => {
                    t.raw.ba === Fu.Tc && (s = i)
                });
                var e = s >= 0 ? s + 1 : 0;
                e > i && (e -= i, t.splice(0, e), s -= e), (e = s >= 0 ? t.length - s - 1 : t.length) > i && t.splice(t.length - (e - i), e - i)
            }
        },
        sp = function(t) {
            var i = t.filter(t => t.isBuy()),
                s = Math.max(0, ...i.map(t => Math.abs(t.l)));
            i.forEach(t => {
                t.ratio = s ? Math.abs(t.l / s) : 0
            }), t = t.filter(t => t.isSell());
            var e = Math.max(0, ...t.map(t => Math.abs(t.l)));
            t.forEach(t => {
                t.ratio = e ? Math.abs(t.l / e) : 0
            })
        },
        ep = function(t) {
            var i = t.filter(t => t.gj()),
                e = t.filter(t => t.fj()),
                r = t.filter(t => t.ba === Fu.Ge),
                a = t.filter(t => t.ba === Fu.Ee);
            return r = [...Vi(this, Yu, rp).call(this, i), ...r], a = [...a, ...Vi(this, Yu, ap).call(this, e)], i = i.length ? i[i.length - 1].price : null, e = e.length ? e[0].price : null, e = null !== i && null !== e ? function(t, i, e, r, a = 10) {
                if (!a) return [];
                var h = e,
                    n = s.normalize(i - h - (t + h), r);
                if (n / h > a) {
                    h = s.normalize(Math.ceil(n / a / h) * h, r), n = [t = s.normalize(t + e, r)];
                    let o = [a = s.normalize(i - e, r)];
                    for (t = s.normalize(t + h, r), a = s.normalize(a - h, r); t < i - e;) t < a && n.unshift(t), a > (t = s.normalize(t + h, r)) && o.push(a), a = s.normalize(a - h, r);
                    return [...o, ...n]
                }
                for (h = [], i = s.normalize(i - e, r); i > t;) h.push(i), i = s.normalize(i - e, r);
                return h
            }(e, i, this.X.Ga, this.X.i, this.gg).map(t => _u.Th(Fu.vf, t, _i(this, Gu), _i(this, Ju), !0)) : [], {
                Af: t,
                eg: r,
                spread: e,
                Bf: a
            }
        },
        rp = function(t) {
            if (!t.length || !this.X.Ga) return [...t];
            var i = new Map(t.map(t => [t.price, t])),
                e = [];
            t = s.normalize(t[t.length - 1].price, this.X.i);
            for (let r = 0; r < 10 && (!(t < 0) || this.X.Ta()); r += 1) e.push(i.get(t) ?? _u.Th(Fu.Tc, t, _i(this, Gu), _i(this, Ju))), t = s.normalize(t + this.X.Ga, this.X.i);
            return e.reverse()
        },
        ap = function(t) {
            if (!t.length || !this.X.Ga) return [...t];
            var i = new Map(t.map(t => [t.price, t])),
                e = [];
            t = s.normalize(t[0].price, this.X.i);
            for (let r = 0; r < 10 && (!(t < 0) || this.X.Ta()); r += 1) e.push(i.get(t) ?? _u.Th(Fu.fd, t, _i(this, Gu), _i(this, Ju))), t = s.normalize(t - this.X.Ga, this.X.i);
            return e
        },
        hp = function(t) {
            this.Af = t.Af, this.eg = t.eg, this.spread = t.spread, this.Bf = t.Bf
        };
    class np {
        constructor() {
            Xi(this, op, 10), Xi(this, lp, {})
        }
        Vk() {
            return {
                ..._i(this, lp)
            }
        }
        hf(t) {
            Ri(this, op, t)
        }
        Ea() {
            delete this.Gj, Ri(this, lp, {})
        }
        Si(t) {
            return _i(this, lp)[t]
        }
        Wm(t, i) {
            _i(this, lp)[t] = i
        }
        Wi() {
            return _i(this, op)
        }
    }
    var op = new WeakMap,
        lp = new WeakMap;
    class cp {
        constructor(t, i, s, e) {
            Xi(this, vp), Xi(this, up), Xi(this, pp), Xi(this, mp, new np), Xi(this, fp, 0), Xi(this, dp, !1), Xi(this, bp), Xi(this, gp), Xi(this, yp, t => {
                Vi(this, vp, kp).call(this, this.sn(t))
            }), Xi(this, wp, t => {
                var i = [];
                t.forEach(t => {
                    var s = _i(this, mp).Si(t),
                        e = _i(this, bp).Ba(t);
                    if (s && e) {
                        var r = _i(this, gp).Se(t);
                        t = _i(this, gp).Te(t), s.Mm(e, r, t) && i.push(s)
                    }
                }), Vi(this, vp, kp).call(this, i)
            }), Ri(this, up, t), Ri(this, pp, i), Ri(this, bp, s), Ri(this, gp, e), _i(this, pp).V(_i(this, yp)), _i(this, up).V(17, _i(this, wp))
        }
        destroy() {
            Ri(this, fp, _i(this, fp) + 1), Ri(this, dp, !1), _i(this, pp).da(_i(this, yp)), _i(this, up).da(17, _i(this, wp)), _i(this, mp).Ea()
        }
        cn(t) {
            if (_i(this, mp).Gj !== t || _i(this, dp)) {
                Ri(this, fp, _i(this, fp) + 1);
                var i = _i(this, fp);
                Ri(this, dp, !1), "number" == typeof t ? _i(this, mp).Gj = t : _i(this, mp).Ea(), _i(this, pp).subscribe("number" == typeof t ? [t] : []).catch(() => {
                    i === _i(this, fp) && Ri(this, dp, !0)
                })
            }
        }
        hf(t) {
            _i(this, mp).hf(t);
            var i = [];
            Object.values(_i(this, mp).Vk()).forEach(t => {
                t.hf(_i(this, mp).Wi()) && i.push(t)
            }), Vi(this, vp, kp).call(this, i)
        }
        sn(t) {
            var i = [];
            return t.forEach(t => {
                var s = _i(this, bp).Vi(t[0]);
                if (s) {
                    var e = _i(this, gp).Se(s.h),
                        r = _i(this, gp).Te(s.h),
                        a = _i(this, mp).Si(s.h);
                    a ? a.Bi(t, e, r) : (a = new Ru(t, s, _i(this, mp).Wi(), e, r), _i(this, mp).Wm(s.h, a)), "applied" === a.ec && i.push(a)
                }
            }), i
        }
    }
    var up = new WeakMap,
        pp = new WeakMap,
        mp = new WeakMap,
        fp = new WeakMap,
        dp = new WeakMap,
        bp = new WeakMap,
        gp = new WeakMap,
        yp = new WeakMap,
        wp = new WeakMap,
        vp = new WeakSet,
        kp = function(t) {
            t.length && _i(this, up).aa(8, t.map(Ru.Qe))
        },
        Mp = [{
            propType: 6
        }, {
            propType: 4
        }, {
            propType: 17
        }, {
            propType: 17
        }],
        Tp = Hi.getSeriesSize(Mp),
        zp = [{
            propType: 6
        }, {
            propType: 3
        }, {
            propType: 3
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 5
        }],
        Wp = Hi.getSeriesSize(zp);
    class Sp extends Is {
        constructor() {
            super(...arguments), Xi(this, Bp), Xi(this, jp, new WeakMap)
        }
        subscribe(t) {
            return this.C.qa(22, T(t), !1)
        }
        V(t) {
            var i = _i(this, jp).get(t);
            i || (i = Vi(this, Bp, $p).bind(this, t), _i(this, jp).set(t, i)), this.C.V(23, i)
        }
        da(t) {
            (t = _i(this, jp).get(t)) && this.C.da(23, t)
        }
    }
    var jp = new WeakMap,
        Bp = new WeakSet,
        $p = function(t, i) {
            if ((i = i.Z).byteLength <= 4) i = [];
            else {
                var s = [],
                    e = 0,
                    r = new DataView(i).getUint32(e, !0);
                e += 4;
                for (let t = 0; t < r; t++) {
                    let t = Qt(i, e);
                    e += Wp, s.push([...t, Zt(i, e, t[5])]), e += Yt(t[5])
                }
                i = s
            }
            t(i)
        };
    class Lp {
        constructor(t) {
            Xi(this, Np), Ri(this, Np, t)
        }
        signBooks(t) {
            _i(this, Np).cn(t)
        }
        setSpreadSize(t) {
            _i(this, Np).hf(t)
        }
    }
    var Np = new WeakMap;
    class Ip {
        constructor(t, i, s, e) {
            this.controller = new cp(t, new Sp(i), s, e), this.view = new Lp(this.controller)
        }
    }
    class Ap {
        constructor(t, i, s, e, r) {
            Xi(this, Fp), Xi(this, Cp), Xi(this, Ep), Xi(this, Dp), Xi(this, Op), Xi(this, xp), Ri(this, Cp, t), Ri(this, Ep, i), Ri(this, Dp, s), Ri(this, Op, e), Ri(this, xp, r)
        }
        init() {
            var t = _i(this, Dp).ha(),
                i = _i(this, Op).Vb(),
                s = _i(this, Op).Ib();
            _i(this, Ep).jc(i, s), _i(this, Ep).Dc(t), _i(this, Cp).aa(14)
        }
        un(t) {
            var i = _i(this, Op).fb(t.B);
            i ? (t.df = i, _i(this, Op).bg(i, t)) : _i(this, Op).Da(t), _i(this, Op).hb(), Vi(this, Fp, Up).call(this)
        }
        Ok(t) {
            _i(this, Op).bg(t) && (_i(this, Op).hb(), Vi(this, Fp, Up).call(this))
        }
        rk(t) {
            _i(this, xp).fb(t.B) || (_i(this, xp).Da(t), _i(this, xp).hb(), Vi(this, Fp, Up).call(this))
        }
        tn(t) {
            var i = _i(this, xp).fb(t.B);
            i && (t.df = i, _i(this, xp).cg(t.B, t), Vi(this, Fp, Up).call(this))
        }
        Nk(t) {
            _i(this, xp).cg(t.B), Vi(this, Fp, Up).call(this)
        }
        yi(t) {
            _i(this, xp).Gf(t.wa) || (_i(this, xp).Fg(t), _i(this, xp).hb(), _i(this, xp).qg(t, !0), Vi(this, Fp, Up).call(this))
        }
        Qj(t) {
            var i = _i(this, xp).Gf(t.wa);
            i && (t.df = i, _i(this, xp).ag(t.wa, t), Vi(this, Fp, Up).call(this))
        }
        Mi(t) {
            _i(this, xp).ag(t.wa), Vi(this, Fp, Up).call(this)
        }
        Rj(t) {
            var i;
            if (i = t.H ? _i(this, Op).Xa(t.H) : _i(this, Op).$c(t.h)) t.df = i, t.l ? _i(this, Op).dg(i, t) : _i(this, Op).dg(i), Vi(this, Fp, Up).call(this);
            else {
                if (!t.l) return !1;
                _i(this, Op).Fb(t), _i(this, Op).hb()
            }
            return Vi(this, Fp, Up).call(this), !0
        }
    }
    var Cp = new WeakMap,
        Ep = new WeakMap,
        Dp = new WeakMap,
        Op = new WeakMap,
        xp = new WeakMap,
        Fp = new WeakSet,
        Up = function() {
            var t = _i(this, Dp).ha(),
                i = _i(this, Op).Vb(),
                s = _i(this, Op).Ib();
            _i(this, Ep).jc(i, s), _i(this, Ep).Dc(t), _i(this, Cp).aa(14), _i(this, Cp).aa(1)
        };
    class Pp {
        constructor(t, i, s, e, r) {
            this.controller = new Ap(t, i, s, e, r)
        }
    }
    class qp {
        constructor(t) {
            this.vc = t[0], this.Pj = t[2], this.wa = t[3], this.F = t[4], this.balance = t[5], this.credit = t[6], this.ma = t[7], this.na = t[8], this.Sb = t[9], this.deals = [], this.positions = []
        }
    }
    var _p = [{
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 12,
            parser: Nt,
            propLength: Zc
        }, {
            propType: 12,
            parser: _t,
            propLength: Lu
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }],
        Xp = Hi.getSeriesSize(_p);
    class Rp {
        constructor(t) {
            this.vc = t[0], this.Pj = t[2], this.B = t[3]
        }
    }
    var Vp = [{
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 12,
            parser: $t,
            propLength: Kc
        }],
        Hp = Hi.getSeriesSize(Vp);
    class Gp {
        constructor(t, i, s, e, r, a) {
            Xi(this, Jp), Xi(this, Kp), Xi(this, Yp), Xi(this, Zp), Xi(this, Qp), Xi(this, tm), Xi(this, im, t => {
                t.forEach(t => {
                    var i = t.Pj,
                        s = t.vc;
                    if (0 === s && t instanceof Rp) t = t.B, 0 === i || 1 === i ? _i(this, tm).un(t) : 2 === i && _i(this, tm).Ok(t), 0 === i ? _i(this, Jp).aa(6, _i(this, Yp).Em()) : 1 === i && _i(this, Jp).aa(6, _i(this, Yp).Gm());
                    else if (1 === s && t instanceof Rp) {
                        switch (t = t.B, i) {
                            case 0:
                                _i(this, tm).rk(t);
                                break;
                            case 1:
                                _i(this, tm).tn(t);
                                break;
                            case 2:
                                _i(this, tm).Nk(t)
                        }
                        0 === i && _i(this, Jp).aa(6, _i(this, Yp).Fm())
                    } else if (2 === s && t instanceof qp) {
                        s = t.deals;
                        let e = t.wa;
                        if (0 === i) {
                            let i = _i(this, Zp).ha();
                            i.balance = t.balance, i.credit = t.credit, i.Sb = t.Sb, i.ma = t.ma, i.na = t.na
                        }
                        if (t.F.h || t.wa.h) {
                            if (!_i(this, tm).Rj(t.F)) return;
                            t.positions.forEach(t => {
                                _i(this, tm).Rj(t)
                            }), _i(this, Qp).sign(e.h)
                        }
                        if ("0" !== e.wa.toString()) {
                            switch (i) {
                                case 0:
                                    _i(this, tm).yi(e);
                                    break;
                                case 1:
                                    _i(this, tm).Qj(e);
                                    break;
                                case 2:
                                    _i(this, tm).Mi(e)
                            }
                            e.ij() && _i(this, Jp).aa(6, _i(this, Yp).Cm(e))
                        }
                        s.forEach(t => {
                            switch (i) {
                                case 0:
                                    _i(this, tm).yi(t);
                                    break;
                                case 1:
                                    _i(this, tm).Qj(t);
                                    break;
                                case 2:
                                    _i(this, tm).Mi(t)
                            }
                        }), 0 === i ? _i(this, Jp).aa(6, _i(this, Yp).Dm()) : 1 === i && _i(this, Jp).aa(6, _i(this, Yp).Hm())
                    }
                })
            }), Ri(this, Jp, t), Ri(this, Kp, i), Ri(this, Yp, s), Ri(this, Zp, e), Ri(this, Qp, r), Ri(this, tm, a), _i(this, Kp).V(_i(this, im))
        }
        destroy() {
            _i(this, Kp).da(_i(this, im))
        }
    }
    var Jp = new WeakMap,
        Kp = new WeakMap,
        Yp = new WeakMap,
        Zp = new WeakMap,
        Qp = new WeakMap,
        tm = new WeakMap,
        im = new WeakMap;
    class sm extends Is {
        constructor() {
            super(...arguments), Xi(this, rm), Xi(this, em, new WeakMap)
        }
        V(t) {
            var i = _i(this, em).get(t);
            i || (i = Vi(this, rm, am).bind(this, t), _i(this, em).set(t, i)), this.C.V(10, i)
        }
        da(t) {
            return (t = _i(this, em).get(t)) && this.C.da(10, t), this
        }
    }
    var em = new WeakMap,
        rm = new WeakSet,
        am = function(t, i) {
            i = i.Z;
            for (var s = [], e = new DataView(i).getUint32(0, !0), r = 0, a = i.byteLength; r < a;) 2 === e ? (s.push(ii(i, r)), r += ti(i, r)) : (s.push(si(i, r)), r += Hp);
            t(s)
        };
    class hm {
        constructor(t, i, s) {
            Xi(this, cm), Xi(this, nm), Xi(this, om), Xi(this, lm), Ri(this, nm, t), Ri(this, om, i), Ri(this, lm, s)
        }
        Em() {
            return ""
        }
        Gm() {
            return ""
        }
        Fm() {
            return ""
        }
        Dm() {
            return ""
        }
        Hm() {
            return ""
        }
        Cm(t) {
            var i = `${_i(this,nm).ha().login}: deal `;
            return (i = i + Et(t, t.wa.toString() || t.Hb) + " done (based on order #" + (t.B ? t.B.toString() : "")) + ")"
        }
    }
    var nm = new WeakMap,
        om = new WeakMap,
        lm = new WeakMap,
        cm = new WeakSet;
    class um {
        constructor(t, i, s, e, r, a, h) {
            this.Im = new hm(s, h, a), this.controller = new Gp(t, new sm(i), this.Im, s, e, r)
        }
    }
    var pm = {
            NONE: 0,
            mi: 1,
            xa: 2
        },
        mm = {
            ak: 0,
            ni: 1
        };
    class fm {
        constructor(t, i, s, e) {
            Xi(this, wm), Xi(this, dm), Xi(this, bm), Xi(this, gm), Xi(this, ym), Ri(this, dm, t), Ri(this, bm, i), Ri(this, gm, s), Ri(this, ym, e)
        }
        Fk(t, i) {
            var s = _i(this, dm).ha();
            i.login = s.login, i.i = 5;
            var e = Vi(this, wm, zm).call(this, i);
            if (0 !== e) return e;
            switch (i.o) {
                case 0:
                    e = Vi(this, wm, Am).call(this, i);
                    break;
                case 1:
                    e = Vi(this, wm, Cm).call(this, i);
                    break;
                case 2:
                    e = Vi(this, wm, vm).call(this, t, i, !0);
                    break;
                case 3:
                    e = Vi(this, wm, Mm).call(this, i);
                    break;
                case 4:
                    e = Vi(this, wm, Lm).call(this, i);
                    break;
                case 5:
                    e = Vi(this, wm, Bm).call(this, i);
                    break;
                case 6:
                    e = Vi(this, wm, Wm).call(this, i);
                    break;
                case 7:
                    e = Vi(this, wm, Sm).call(this, i);
                    break;
                case 8:
                    e = Vi(this, wm, Tm).call(this, i);
                    break;
                case 10:
                    e = Vi(this, wm, jm).call(this, s, i)
            }
            return e
        }
    }
    var dm = new WeakMap,
        bm = new WeakMap,
        gm = new WeakMap,
        ym = new WeakMap,
        wm = new WeakSet,
        vm = function(t, i, s = !1) {
            var e = {},
                r = Vi(this, wm, Im).call(this, i, e);
            if (0 !== r || !e.F || !e.X) return r;
            var a = e.X;
            return ei(i.m, a) ? a.trade.ia !== Sr.tc ? 10013 : ri(a, i, !0) ? oi(i, a, e = e.F) ? 0 !== (r = Vi(this, wm, Nm).call(this, i, a, e)) || 0 !== (r = li(i, a, e)) ? r : i.Jc > h.INT32_MAX ? 10017 : ai(a, i.u) ? 0 !== (r = Vi(this, wm, km).call(this, t, _i(this, dm).ha(), i, a, s)) ? r : i.ea = 0 : 10035 : 10014 : 10030 : 10015
        },
        km = function(t, i, s, e, r = !1) {
            var a;
            if (!(a = 2 !== s.o) && (a = r)) t: {
                var h = Date.now();a = null;
                var n = t.Vg();
                for (var o of n) {
                    if (h > o.time) {
                        t.Df(o), a = null;
                        break t
                    }
                    s.o === o.Ae.o && s.u === o.Ae.u && s.l === o.Ae.l && s.h === o.Ae.h && (a = o)
                }
                a && (o = 0 === s.u ? a.L : a.O, t.Df(a), 10 ** e.i * Math.abs(s.m - o) > 0 && (a = null)),
                a = !!a
            }
            if (a) return 0;
            if (!(t = _i(this, gm).ad(e.h, e.od()))) return 10021;
            if (0 === s.u && t.fields && 2 & t.fields && s.m === t.fc || 1 === s.u && t.fields && 1 & t.fields && s.m === t.yb) return 0;
            if (!(null == (t = _i(this, gm).$k(s.h)) ? void 0 : t.size)) return 0;
            for (e = [...t], (e = [...e]).length > 20 && (e.length = 20), h = a = o = 0, n = e.length - 1; n >= 0; n--)
                if (t = e[n]) {
                    if (0 === s.u) {
                        if (!(t.fields && 2 & t.fields)) continue;
                        var l = t.L;
                        a = Math.floor(t.ib / 1e3), (h += 1) || (o = a - 1)
                    }
                    if (1 === s.u) {
                        if (!(t.fields && 1 & t.fields)) continue;
                        l = t.O, a = Math.floor(t.ib / 1e3), (h += 1) || (o = a - 1)
                    }
                    if (a < o) {
                        r && (i.hc += 2);
                        break
                    }
                    if (h > 2) {
                        r && (i.hc += 2);
                        break
                    }
                    if (l === s.m) {
                        if (h > 1) {
                            if (r && (i.hc += 2, i.hc >= 15)) break
                        } else r && --i.hc;
                        return 0
                    }
                } return h ? (r && n < 0 && (i.hc += 2), 10021) : 0
        },
        Mm = function(t) {
            var i = {},
                s = Vi(this, wm, Im).call(this, t, i);
            if (0 !== s || !i.X || !i.F) return s;
            var e = i.X;
            return ei(t.m, e) ? e.trade.ia !== Sr.xa ? 10013 : ri(e, t, !0) ? oi(t, e, i = i.F) ? 0 !== (s = Vi(this, wm, Nm).call(this, t, e, i)) || 0 !== (s = li(t, e, i)) ? s : ai(e, t.u) ? 0 : 10035 : 10014 : 10030 : 10015
        },
        Tm = function(t) {
            var i = _i(this, ym).fb(t.B);
            if (!i) return 10013;
            var s = _i(this, bm).Ba(i.h);
            if (!s) return 10013;
            var e = s && 0 !== s.trade.ac ? 0 : 10017;
            return 0 !== e ? e : ht(i.T) && s.trade.ia !== Sr.Va || 1 !== i.rc && 3 !== i.rc ? 10013 : (t.h = i.h, t.u = i.T, t.i = s.i, 0)
        },
        zm = function(t) {
            if (1 !== t.o && 2 !== t.o && 3 !== t.o && 4 !== t.o) return 0;
            var i = _i(this, bm).Ba(t.h);
            if (!i) return 10013;
            switch (i.trade.ia) {
                case Sr.uc:
                    1 !== t.o && (t.o = 1);
                    break;
                case Sr.tc:
                    t.o = i.trade.wb && t.l > i.trade.wb ? 1 : 2;
                    break;
                case Sr.xa:
                    3 !== t.o && (t.o = 3);
                    break;
                case Sr.Va:
                    4 !== t.o && (t.o = 4)
            }
            return 0
        },
        Wm = function(t) {
            var i = {},
                s = Vi(this, wm, Im).call(this, t, i);
            if (0 !== s || !i.X || !i.F) return s;
            var e = i.X;
            return (i = i.F).l ? ei(t.v, e) && ei(t.A, e) ? (t.m = i.D, t.u = i.isBuy() ? 0 : 1, (s = _i(this, gm).ad(e.h, e.od())) ? 0 !== (s = hi(s, e, t, i.D, i.ka, i.la)) ? s : i.ka === t.v && i.la === t.A ? 10025 : ai(e, t.u) ? 0 : 10035 : 10021) : 10016 : 10036
        },
        Sm = function(t) {
            var i = _i(this, ym).fb(t.B);
            if (!i) return 10013;
            var s = _i(this, bm).Ba(i.h);
            if (!s) return 10013;
            if (t.u = i.T, ht(i.T) || 1 !== i.rc && 3 !== i.rc) return 10013;
            var e = Vi(this, wm, $m).call(this, t, s, i);
            return 0 !== e ? e : i.m === t.m && i.K === t.K && i.v === t.v && i.A === t.A && i.ya === t.ya && i.ua === t.ua ? 10025 : ai(s, t.u) ? (t.h = i.h, t.u = i.T, t.i = s.i, 0) : 10035
        },
        jm = function(t, i) {
            if (!t.nc()) return 10013;
            t = _i(this, ym).Xa(i.F);
            var s = _i(this, ym).Xa(i.Ac);
            if (!t || !s || t.h !== s.h || t.o === s.o) return 10013;
            if (!(s = _i(this, bm).Ba(t.h))) return 10013;
            var e = s && 0 !== s.trade.ac ? 0 : 10017;
            return 0 !== e ? e : s && s.eh(Lr.pf) ? (i.h = s.h, i.i = s.i, i.l = t.l, 0) : 10035
        },
        Bm = function(t) {
            var i = {},
                s = Vi(this, wm, Im).call(this, t, i);
            if (0 !== s || !i.X || !i.F) return s;
            var e = i.X;
            return ! function(t, i) {
                switch (i.ya) {
                    case 0:
                        return !!(t.trade.Pb & $r.sf);
                    case 1:
                        return !!(t.trade.Pb & $r.qf);
                    case 2:
                        return !!(t.trade.Pb & $r.wf);
                    case 3:
                        return !!(t.trade.Pb & $r.xf);
                    default:
                        return !1
                }
            }(e, t) || (2 === t.ya || 3 === t.ya) && (!t.ua || t.ua < 0 || t.ua > h.INT32_MAX) ? 10022 : oi(t, e, i = i.F) ? 0 !== (s = Vi(this, wm, $m).call(this, t, e, new Kl)) ? s : t.isLimit() && (e.cc && it(t.m, e.cc, e.i) < 0 || e.bc && it(t.m, e.bc, e.i) > 0) ? 10015 : 0 !== (s = li(t, e, i)) ? s : ri(e, t, !0) ? ai(e, t.u) ? (e.trade.ia !== Sr.xa && e.trade.ia !== Sr.Va && (t.ea = 2), 0) : 10035 : 10030 : 10014
        },
        $m = function(t, i, s) {
            if (!ei(t.m, i) || !ei(t.K, i)) return 10015;
            if (!ei(t.v, i) || !ei(t.A, i)) return 10016;
            var e = _i(this, gm).ad(i.h, i.od());
            return e ? hi(e, i, t, s.m, s.v, s.A) : 10021
        },
        Lm = function(t) {
            var i = {},
                s = Vi(this, wm, Im).call(this, t, i);
            if (0 !== s || !i.X || !i.F) return s;
            var e = i.X;
            return ei(t.m, e) ? e.trade.ia !== Sr.Va ? 10013 : ri(e, t, !0) ? oi(t, e, i.F) ? 0 !== (s = Vi(this, wm, Nm).call(this, t, e, i.F)) || 0 !== (s = li(t, e, i.F)) ? s : ai(e, t.u) ? (t.kb |= pm.xa, t.m = 0) : 10035 : 10014 : 10030 : 10015
        },
        Nm = function(t, i, s) {
            if (!ei(t.m, i)) return 10015;
            if (!ei(t.v, i) || !ei(t.A, i)) return 10016;
            var e = s.ka,
                r = s.la;
            (0 === t.u && s.isSell() || 1 === t.u && s.isBuy()) && t.l >= s.l && (r = e = 0);
            var a = _i(this, gm).ad(i.h, i.od());
            return a ? hi(a, i, t, s.D, e, r) : 10021
        },
        Im = function(t, i) {
            var s = null;
            if (_i(this, dm).ha().nc()) {
                if (t.F && !(s = _i(this, ym).Xa(t.F))) return 10013;
                if (s && t.nd()) {
                    if (t.l > s.l) return 10014;
                    if (t.isBuy() && s.isBuy() || t.isSell() && s.isSell()) return 10013
                }
            } else t.h && (s = _i(this, ym).$c(t.h));
            s || (s = new $c);
            var e = (null == s ? void 0 : s.l) ? _i(this, bm).Ba(s.h) : _i(this, bm).Ba(t.h);
            if (!e) return 10013;
            var r = e && 0 !== e.trade.ac ? 0 : 10017;
            return 0 !== r ? r : (t.h = e.h, t.i = e.i, i && (i.F = s, i.X = e), 0)
        },
        Am = function(t) {
            var i = {},
                s = Vi(this, wm, Im).call(this, t, i);
            return 0 === s && i.X && i.F ? (i = i.X).trade.ia !== Sr.uc && (i.trade.ia !== Sr.tc || !i.trade.wb || i.trade.wb >= t.l) ? 10013 : function(t, i = 0n) {
                return !(i <= 0n || i > t.trade.Ld || i % t.trade.Md)
            }(i, t.l) ? 0 : 10014 : s
        },
        Cm = function(t) {
            var i = {},
                s = Vi(this, wm, Im).call(this, t, i);
            if (0 !== s || !i.X || !i.F) return s;
            var e = i.F;
            return ri(i = i.X, t, !0) ? oi(t, i, e) ? 0 !== (s = Vi(this, wm, Nm).call(this, t, i, e)) || 0 !== (s = li(t, i, e)) ? s : ai(i, t.u) ? t.ea = 0 : 10035 : 10014 : 10030
        };
    class Em {
        constructor(t, i, s, e) {
            this.controller = new fm(t, i, s, e)
        }
    }
    class Dm extends Is {
        async hl(t) {
            return t = Hi.serialize([
                [6, t.lb || 0],
                [6, t.o || 0],
                [11, (t.h || "").substring(0, 32), 64],
                [18, t.l || 0n],
                [6, t.i || 0],
                [18, t.B || 0n],
                [6, t.u || 0],
                [6, t.ea || 0],
                [6, t.ya || 0],
                [6, t.kb || 0],
                [6, t.Pc || 0],
                [8, t.m || 0],
                [8, t.K || 0],
                [8, t.v || 0],
                [8, t.A || 0],
                [6, t.Jc || 0],
                [8, t.Xf || 0],
                [8, t.Wf || 0],
                [11, t.comment.substring(0, 32), 64],
                [18, t.F || 0n],
                [18, t.Ac || 0n],
                [6, t.ua || 0]
            ]), t = await this.C.qa(12, t), new Uint32Array(t.Z)[0]
        }
    }
    class Om {
        constructor(t) {
            this.pa = 0, this.volume = this.B = 0n, this.L = this.O = this.price = 0, this.comment = "", this.pa = t ?? this.pa
        }
        ql() {
            return [10009, 10010, 11001].includes(this.pa)
        }
        isFinal() {
            var t = this.pa;
            return 0 !== t && 10001 !== t && 10002 !== t && 10003 !== t && 10028 !== t
        }
    }
    var xm = t => t ? `#${t} ` : "",
        Fm = {
            bk: t => `${xm(t.order)}market ${t.$a} ${t.volume} ${t.symbol} at ${t.price}`,
            Yj: t => `${xm(t.order)}exchange ${t.$a} ${t.volume} ${t.symbol} at ${t.price}`,
            Va: t => `${xm(t.order)}exchange ${t.$a} ${t.volume} ${t.symbol}`,
            ik: t => `${xm(t.order)}${t.$a} ${t.volume} ${t.symbol} at ${t.price}`,
            nk: t => `modify ${t.position} ${t.volume} ${t.symbol}\nsl: ${t.ka}, tp: ${t.la}`,
            dk: t => `${t.order} ${t.$a} ${t.volume} ${t.symbol} at ${t.price}\nsl: ${t.ka} tp: ${t.la}`,
            kk: t => `cancel #${t.order} ${t.$a} ${t.volume} ${t.symbol} at ${t.price}`,
            pf: (t, i) => `close position #${t.position} ${t.ym} ${t.volume} ${t.symbol}\nby position #${i.position} ${i.ym} ${i.volume} ${i.symbol}`,
            jk: (t, i) => `prices for ${t} ${i}`,
            uc: t => `${xm(t.order)}request ${t.$a} ${t.volume} ${t.symbol} at ${t.price}`,
            tc: t => `${xm(t.order)}instant ${t.$a} ${t.volume} ${t.symbol} at ${t.price}`,
            xa: t => `${xm(t.order)}market ${t.$a} ${t.volume} ${t.symbol}`,
            gd: t => ` sl: ${t}`,
            He: t => ` tp: ${t}`
        };
    class Um {
        constructor() {
            this.l = 0n, this.A = this.v = this.K = this.m = 0, this.Jc = mm.ak, this.o = this.lb = this.Wf = this.Xf = 0, this.h = "", this.i = 0, this.B = 0n, this.u = 0, this.kb = pm.NONE, this.comment = "", this.Ac = 0n, this.login = this.Bj = 0, this.complete = !1
        }
        Cf() {
            var t = new Um;
            return t.lb = this.lb, t.o = this.o, t.h = this.h, t.l = this.l, t.i = this.i, t.B = this.B, t.u = this.u, t.ea = this.ea, t.ya = this.ya, t.kb = this.kb, t.Pc = this.Pc, t.m = this.m, t.K = this.K, t.v = this.v, t.A = this.A, t.Jc = this.Jc, t.Xf = this.Xf, t.Wf = this.Wf, t.comment = this.comment, t.F = this.F, t.Ac = this.Ac, t
        }
        isBuy() {
            return rt(this.u)
        }
        isSell() {
            return at(this.u)
        }
        isLimit() {
            return ot(this.u)
        }
        isStop() {
            return lt(this.u)
        }
        isStopLimit() {
            return ct(this.u)
        }
        isMarket() {
            return [1, 2, 3, 4, 200].includes(this.o)
        }
        isPending() {
            return 5 === this.o
        }
        tl() {
            return 7 === this.o
        }
        wl() {
            return 8 === this.o
        }
        isBalance() {
            return 206 === this.o
        }
        xl() {
            return 101 === this.o || 102 === this.o
        }
        nd() {
            return !(!this.isMarket() && !this.xl() || !this.F)
        }
        Zd() {
            return 10 === this.o || 208 === this.o
        }
    }
    class Pm {
        constructor(t, i, s, e, r, a) {
            Xi(this, Jm), Xi(this, qm), Xi(this, _m), Xi(this, Xm), Xi(this, Rm), Xi(this, Vm), Xi(this, Hm), Xi(this, Gm, new Set), Ri(this, qm, t), Ri(this, _m, i), Ri(this, Xm, s), Ri(this, Rm, e), Ri(this, Vm, r), Ri(this, Hm, a)
        }
        destroy() {
            _i(this, Gm).forEach(t => t()), _i(this, Gm).clear()
        }
        async yh(t) {
            var i;
            if (t && (!(void 0 === t.symbol || "string" == typeof t.symbol && t.symbol) || void 0 !== t.types && !Array.isArray(t.types) || !((null == (i = t.types) ? void 0 : i.every(Si)) ?? !0))) return ki("invalid-options");
            var s = ki(),
                e = _i(this, Rm).Vb().filter(i => {
                    var s;
                    return !((null == t ? void 0 : t.symbol) && i.h !== t.symbol || !Si(i.T)) && (!(null == (s = null == t ? void 0 : t.types) ? void 0 : s.length) || t.types.includes(i.T))
                }),
                r = [];
            for (let a of e) {
                e = a.B.toString();
                let t = _i(this, Rm).fb(a.B);
                if (!t) {
                    Ti(s, e);
                    continue
                }
                let i = _i(this, Xm).Ba(t.h);
                if (!i) {
                    Ti(s, e);
                    continue
                }
                let h = vi();
                gi(h, i, t), r.push({
                    status: "submitted",
                    Uh: [e],
                    transaction: h
                })
            }
            for (let a of r)
                if (a.transaction = _i(this, Vm).call(this, a.transaction), Mi(s, a, 0 === a.transaction.result.pa ? "submitted" : "failed"), 0 !== a.transaction.result.pa) {
                    s.aborted = !0;
                    break
                } return s
        }
        async Ah(t) {
            if (t && (!(void 0 === t.symbol || "string" == typeof t.symbol && t.symbol) || ("closeBy" === t.mode || "reverse" === t.mode ? !t.symbol || "action" in t || "direction" in t : void 0 !== t.mode && "close" !== t.mode || void 0 !== t.action && 0 !== t.action && 1 !== t.action || void 0 !== t.direction && ![-1, 0, 1].includes(t.direction)))) return ki("invalid-options");
            var i = _i(this, _m).ha();
            if ("closeBy" === (null == t ? void 0 : t.mode)) return i.ae() ? ki("close-by-fifo") : i.nc() ? (i = ki(), await Vi(this, Jm, Zm).call(this, t.symbol, i), i) : ki("invalid-options");
            if ("reverse" === (null == t ? void 0 : t.mode)) return i.nc() ? ki("reverse-hedging") : Vi(this, Jm, Km).call(this, {
                symbol: t.symbol,
                direction: 0,
                reverse: !0
            });
            var s = (null == t ? void 0 : t.direction) ?? 0;
            if (i.ae() && (0 !== s || void 0 !== (null == t ? void 0 : t.action))) return ki("fifo-filter");
            var e = ki();
            return 0 !== s || void 0 !== (null == t ? void 0 : t.action) || !i.nc() || i.ae() || await Vi(this, Jm, Zm).call(this, null == t ? void 0 : t.symbol, e) ? Vi(this, Jm, Km).call(this, {
                symbol: null == t ? void 0 : t.symbol,
                action: null == t ? void 0 : t.action,
                direction: s,
                reverse: !1
            }, e) : e
        }
    }
    var qm = new WeakMap,
        _m = new WeakMap,
        Xm = new WeakMap,
        Rm = new WeakMap,
        Vm = new WeakMap,
        Hm = new WeakMap,
        Gm = new WeakMap,
        Jm = new WeakSet,
        Km = async function(t, i = ki()) {
            var s = _i(this, _m).ha(),
                e = _i(this, Rm).Ib().filter(i => !(t.symbol && i.h !== t.symbol || void 0 !== t.action && i.o !== t.action || t.direction > 0 && i.profit <= 0 || t.direction < 0 && i.profit >= 0));
            if (s.ae()) {
                for (var r of (e.sort(zi), e)) {
                    var a = Vi(this, Jm, Ym).call(this, r, t.reverse, i);
                    if (a) {
                        if (s = Wi(r), a.transaction = await _i(this, Hm).call(this, a.transaction), Mi(i, a, mi(a.transaction.result.pa) ? "succeeded" : "failed"), !mi(a.transaction.result.pa)) {
                            i.aborted = !0;
                            break
                        }
                        if (!(await Vi(this, Jm, tf).call(this, [s]))) {
                            i.aborted = !0;
                            break
                        }
                    }
                }
                return i
            }
            for (a of r = e.map(s => Vi(this, Jm, Ym).call(this, s, t.reverse, i)).filter(t => !!t))
                if (a.transaction = _i(this, Vm).call(this, a.transaction), Mi(i, a, 0 === a.transaction.result.pa ? "submitted" : "failed"), 0 !== a.transaction.result.pa) {
                    i.aborted = !0;
                    break
                } return i
        }, Ym = function(t, i, s) {
            var e = t.H.toString();
            if (!(t = _i(this, Rm).Xa(t.H))) return Ti(s, e), null;
            var r = _i(this, Xm).Ba(t.h);
            if (!r) return Ti(s, e), null;
            if (s = vi(), i) switch (i = s.request, i.h = r.h, i.l = 2n * t.l, i.i = r.i, i.B = 0n, i.kb = pm.xa, i.F = 0n, i.m = t.D, i.K = 0, i.v = 0, i.A = 0, i.ya = 0, i.ua = 0, i.u = t.isBuy() ? 1 : 0, r.trade.ia) {
                case Sr.tc:
                    if (i.ea = 0, 0n === r.trade.wb || i.l <= r.trade.wb) {
                        i.o = 2, i.Jc = mm.ni;
                        break
                    }
                    i.o = 1;
                    break;
                case Sr.uc:
                    i.o = 1;
                    break;
                case Sr.xa:
                    i.o = 3, i.ea = r.trade.Qa & Br.Rc ? 1 : r.trade.Qa & Br.Qc ? 0 : 2;
                    break;
                case Sr.Va:
                    i.o = 4, i.ea = 2
            } else yi(s, r, t, !0, t.D), r.trade.ia === Sr.uc && (s.request.o = 1, s.request.m = t.D);
            return {
                status: "submitted",
                Uh: [e],
                transaction: s
            }
        }, Zm = async function(t, i) {
            for (let r = 0; r < 128; r++) {
                var s = Vi(this, Jm, Qm).call(this, t);
                if (!s) return !0;
                let [r, a] = s;
                var e = _i(this, Xm).Ba(r.h);
                if (!e) return Ti(i, r.H.toString()), !0;
                if (wi(s = vi(), e, r, a), e = [Wi(r), Wi(a)], Mi(i, s = {
                        status: "submitted",
                        Uh: [r.H.toString(), a.H.toString()],
                        transaction: await _i(this, Hm).call(this, s)
                    }, mi(s.transaction.result.pa) ? "succeeded" : "failed"), !mi(s.transaction.result.pa) || !(await Vi(this, Jm, tf).call(this, e))) return i.aborted = !0, !1
            }
            return !Vi(this, Jm, Qm).call(this, t) || (i.aborted = !0, !1)
        }, Qm = function(t) {
            var i = _i(this, Rm).Ib().filter(i => !(t && i.h !== t || 0n === i.l || !(i = _i(this, Xm).Ba(i.h)) || !i.eh(Lr.pf)));
            for (let s of i) {
                let t = i.find(t => t.H !== s.H && t.h === s.h && t.o !== s.o);
                if (t) return [s, t]
            }
            return null
        }, tf = async function(t) {
            var i = () => t.every(t => {
                var i = _i(this, Rm).Xa(t.id);
                return !i || i.l !== t.volume
            });
            if (i()) return !0;
            var s = function(t, i) {
                var s;
                return 1e3 * ((i ? null == (s = t.Ba(i)) ? void 0 : s.trade.ze : void 0) || 7)
            }(_i(this, Xm), t.map(t => {
                var i;
                return null == (i = _i(this, Rm).Xa(t.id)) ? void 0 : i.h
            }).find(Boolean));
            return new Promise(t => {
                var e = !1,
                    r = i => {
                        e || (e = !0, _i(this, qm).da(1, a), void 0 !== n && clearTimeout(n), _i(this, Gm).delete(h), t(i))
                    },
                    a = () => {
                        i() && r(!0)
                    },
                    h = () => r(!1);
                _i(this, Gm).add(h), _i(this, qm).V(1, a);
                var n = setTimeout(() => r(!1), s);
                i() && r(!0)
            })
        };
    class sf {
        constructor() {
            Xi(this, ef), Xi(this, rf), Xi(this, af), Ri(this, ef, new Map), Ri(this, rf, new Map), Ri(this, af, new Map), this.count = 1e3
        }
        Ea() {
            var t = new Om(10012);
            _i(this, af).forEach(i => {
                clearTimeout(i.Lj), i.resolve(t)
            }), this.count = 1e3, _i(this, rf).clear(), _i(this, af).clear(), _i(this, ef).clear()
        }
        nl() {
            this.count += 1
        }
        Vm(t) {
            _i(this, rf).set(t.lb, t)
        }
        Ng(t) {
            return _i(this, rf).get(t)
        }
        wn(t, i, s) {
            return new Promise(e => {
                var r = setTimeout(s, i);
                _i(this, af).set(t, {
                    resolve: e,
                    Lj: r
                })
            })
        }
        Ke(t, i) {
            var s = _i(this, af).get(t);
            s && (clearTimeout(s.Lj), _i(this, af).delete(t), s.resolve(i))
        }
        dl(t) {
            var i = _i(this, ef).get(t);
            if (i) {
                if (i.time > Date.now()) return i;
                _i(this, ef).delete(t)
            }
            return null
        }
        Hg(t) {
            _i(this, ef).set(t.Ae.h, t)
        }
        Vg() {
            return [..._i(this, ef).values()]
        }
        Df(t) {
            _i(this, ef).delete(t.Ae.h)
        }
    }
    var ef = new WeakMap,
        rf = new WeakMap,
        af = new WeakMap;
    class hf {
        constructor(t, i, s, e, r, a, h, n, o) {
            Xi(this, yf), Xi(this, nf), Xi(this, of), Xi(this, lf, new sf), Xi(this, cf), Xi(this, uf), Xi(this, pf), Xi(this, mf), Xi(this, ff), Xi(this, df), Xi(this, bf), Xi(this, gf), Ri(this, nf, t), Ri(this, of, i), Ri(this, cf, s), Ri(this, uf, e), Ri(this, pf, r), Ri(this, mf, a), Ri(this, ff, h), Ri(this, df, n), Ri(this, bf, o), Ri(this, gf, new Pm(t, e, r, a, t => Vi(this, yf, kf).call(this, t), t => Vi(this, yf, Mf).call(this, t)))
        }
        destroy() {
            _i(this, gf).destroy(), this.Ea()
        }
        Ea() {
            _i(this, lf).Ea()
        }
        Lc(t) {
            t.Pc = 0, t.kb &= -257, t.kb &= -513;
            var i = _i(this, uf).ha();
            if (t.login = i.login, t.lb = _i(this, lf).count, _i(this, lf).nl(), t.Bj = Date.now(), 0 !== (i = _i(this, df).Fk(this, t))) {
                var s = _i(this, pf).Ma(t.h);
                return _i(this, nf).aa(6, fi(_i(this, mf), _i(this, ff), _i(this, uf), s, t, new Om(i), _i(this, bf))), i
            }
            return _i(this, cf).Xg() && _i(this, cf).ml() ? (_i(this, lf).Vm(t), _i(this, of).hl(t).then(i => Vi(this, yf, wf).call(this, t, i)).catch(() => this.Uf(t)), i = _i(this, pf).Ma(t.h), _i(this, nf).aa(6, fi(_i(this, mf), _i(this, ff), _i(this, uf), i, t, new Om(10001), _i(this, bf))), 0) : (i = new Om(10), s = _i(this, pf).Ma(t.h), _i(this, nf).aa(6, fi(_i(this, mf), _i(this, ff), _i(this, uf), s, t, i, _i(this, bf))), i.pa)
        }
        Uf(t) {
            if (this) {
                var i = new Om(10012);
                t.complete = !0, this.Ke(t.lb, i);
                var s = _i(this, pf).Ma(t.h);
                s = fi(_i(this, mf), _i(this, ff), _i(this, uf), s, t, i, _i(this, bf)), _i(this, nf).aa(6, s), _i(this, nf).aa(2, {
                    id: t.lb,
                    order: "",
                    action: di(t),
                    result: bi(i),
                    code: 10012,
                    log: s
                })
            }
        }
        Ng(t) {
            return _i(this, lf).Ng(t)
        }
        Ke(t, i) {
            i.isFinal() && _i(this, lf).Ke(t, i)
        }
        Hg(t) {
            _i(this, lf).Hg(t)
        }
        gm(t) {
            var i = ji();
            if (Bi(i, t), !t) return i;
            var s = Vi(this, yf, vf).call(this, i, t.h);
            return s ? (gi(i, s, t), i.result.pa = this.Lc(i.request), i) : i
        }
        hm(t, i, e, r, a, h, n, o) {
            var l = ji();
            if (Bi(l, t), !t) return l;
            var c = Vi(this, yf, vf).call(this, l, t.h);
            if (!c) return l;
            var u = l.request,
                p = i ? i - t.m : 0;
            return t.v && (t.v = s.normalize(t.v + p, t.i)), t.A && (t.A = s.normalize(t.A + p, t.i)), 6 !== t.T && 7 !== t.T || (t.K = s.normalize(t.K + p, t.i), o && 0 === p && (p = o - t.K, t.v && (t.v = s.normalize(t.v + p, t.i)), t.A && (t.A = s.normalize(t.A + p, t.i)))), p = c.N, c = c.i, u.h = t.h, u.o = 7, u.l = t.Ra, u.B = t.B, u.u = t.T, u.m = V(i ?? t.m, p, c), u.K = V(o ?? t.K, p, c), u.v = V(e ?? t.v, p, c), u.A = V(r ?? t.A, p, c), u.ya = a ?? t.ya, u.ua = Math.round((h ?? t.ua) / 1e3), u.comment = n ?? t.comment, l.result.pa = this.Lc(l.request), l
        }
        im(t, i, s, e, r, a, h, n, o, l, c) {
            var u = ji();
            if (!(i = Vi(this, yf, vf).call(this, u, i))) return u;
            var p = u.request;
            return p.u = t, p.h = i.h, p.o = nt(t) ? 5 : 2, p.l = C(s), p.i = i.i, p.kb = pm.xa, p.m = V(e, i.N, i.i), p.K = V(l ?? 0, i.N, i.i), p.v = V(r ?? 0, i.N, i.i), p.A = V(a ?? 0, i.N, i.i), p.ya = h ?? 0, p.ua = Math.round((n ?? 0) / 1e3), p.comment = o ?? "", p.ea = i.trade.ia === Sr.Va ? c ?? 2 : 2, u.result.pa = this.Lc(u.request), u
        }
        vj(t, i, s, e) {
            var r = ji();
            if ($i(r, t), !t) return r;
            var a = Vi(this, yf, vf).call(this, r, t.h);
            return a ? (yi(r, a, t, i, s, _i(this, lf).dl(t.h), e), r.result.pa = this.Lc(r.request), r) : r
        }
        tm(t) {
            return t = _i(this, mf).$c(t), this.vj(t, !1)
        }
        sm(t, i) {
            var s = ji();
            if ($i(s, t), !t) return s;
            if ($i(s, i), !i) return s;
            var e = Vi(this, yf, vf).call(this, s, t.h);
            return e ? (wi(s, e, t, i), s.result.pa = this.Lc(s.request), s) : s
        }
        wj(t, i, s) {
            var e = ji();
            if ($i(e, t), !t) return e;
            var r = Vi(this, yf, vf).call(this, e, t.h);
            if (!r) return e;
            var a = e.request;
            return a.h = r.h, a.F = t.H, a.l = t.l, a.o = 6, a.i = r.i, a.v = i === Number.MAX_VALUE ? V(t.ka, r.N, r.i) : V(i, r.N, r.i), a.A = s === Number.MAX_VALUE ? V(t.la, r.N, r.i) : V(s, r.N, r.i), e.result.pa = this.Lc(e.request), e
        }
        um(t, i, s) {
            return t = _i(this, mf).$c(t), this.wj(t, i, s)
        }
        vm(t, i, s, e, r, a, h, n) {
            var o, l = ji();
            if (!(t = Vi(this, yf, vf).call(this, l, t))) return l;
            r = r || 0, a = a || 0;
            var c = l.request;
            switch (c.h = t.h, c.l = C(i), c.i = t.i, c.kb = pm.xa, c.m = 0, c.K = 0, c.v = V(r, t.N, t.i), c.A = V(a, t.N, t.i), c.ya = 0, c.ua = 0, c.u = s, c.comment = n, null == (o = t.trade) ? void 0 : o.ia) {
                case Sr.tc:
                    if (c.ea = 0, !t.trade.wb || c.l <= t.trade.wb) {
                        c.o = 2, c.m = e, c.Jc = 0;
                        break
                    }
                case Sr.uc:
                    e ? (c.m = e, c.o = 1) : c.o = 0;
                    break;
                case Sr.xa:
                    c.o = 3, c.ea = t.trade.Qa & Br.Rc ? 1 : t.trade.Qa & Br.Qc ? 0 : 2;
                    break;
                case Sr.Va:
                    c.o = 4, c.ea = h, c.kb = pm.xa, c.m = 0
            }
            return l.result.pa = this.Lc(l.request), l
        }
        Vg() {
            return _i(this, lf).Vg()
        }
        Df(t) {
            _i(this, lf).Df(t)
        }
        yh(t) {
            return _i(this, gf).yh(t)
        }
        Ah(t) {
            return _i(this, gf).Ah(t)
        }
    }
    var nf = new WeakMap,
        of = new WeakMap,
        lf = new WeakMap,
        cf = new WeakMap,
        uf = new WeakMap,
        pf = new WeakMap,
        mf = new WeakMap,
        ff = new WeakMap,
        df = new WeakMap,
        bf = new WeakMap,
        gf = new WeakMap,
        yf = new WeakSet,
        wf = function(t, i) {
            if (0 !== i) {
                let e = new Om(i);
                t.complete = !0, this.Ke(t.lb, e);
                var s = _i(this, pf).Ma(t.h);
                s = fi(_i(this, mf), _i(this, ff), _i(this, uf), s, t, e, _i(this, bf)), _i(this, nf).aa(6, s), _i(this, nf).aa(2, {
                    id: t.lb,
                    order: "",
                    action: di(t),
                    result: bi(e),
                    code: i,
                    log: s
                })
            }
        },
        vf = function(t, i) {
            return (i = _i(this, pf).Ba(i)) || (t.result.pa = 2, null)
        },
        kf = function(t) {
            var i = this.Lc(t.request);
            return t.result = new Om(i), 0 !== i && (t.request.complete = !0), t
        },
        Mf = async function(t) {
            var i, s = this.Lc(t.request);
            return 0 !== s ? (t.request.complete = !0, t.result = new Om(s), t) : (s = (null == (i = _i(this, pf).Ba(t.request.h)) ? void 0 : i.trade.ze) || 7, t.result = await _i(this, lf).wn(t.request.lb, 1e3 * s, () => this.Uf(t.request)), t.request.complete = !0, t)
        };
    class Tf {
        constructor(t, i) {
            Xi(this, zf), Xi(this, Wf), Ri(this, zf, t), Ri(this, Wf, i)
        }
        positionOpen(t, i, s, e, r, a, h, n) {
            return Li(t = _i(this, zf).vm(i, s, t, e, r, a, h, n))
        }
        positionModify(t, i, s) {
            return t = _i(this, Wf).Xa(BigInt(t)), Li(_i(this, zf).wj(t, i, s))
        }
        modifyBySymbol(t, i, s) {
            return Li(t = _i(this, zf).um(t, i, s))
        }
        positionClose(t, i, s, e) {
            return t = _i(this, Wf).Xa(BigInt(t)), (i = _i(this, zf).vj(t, i, s, e)) && Li(i)
        }
        async positionsClose(t) {
            return Ni(t = await _i(this, zf).Ah(t))
        }
        positionCloseBy(t, i) {
            return t = _i(this, Wf).Xa(BigInt(t)), i = _i(this, Wf).Xa(BigInt(i)), (i = _i(this, zf).sm(t, i)) && Li(i)
        }
        positionCloseBySymbol(t) {
            return (t = _i(this, zf).tm(t)) && Li(t)
        }
        requestPrice(t, i, s) {
            return this.positionOpen(i, t, s, 0, 0, 0, 0, "")
        }
        orderOpen(t, i, s, e, r, a, h, n, o, l, c) {
            return Li(t = _i(this, zf).im(t, i, s, e, r, a, h, n, o, l, c))
        }
        orderModify(t, i, s, e, r, a, h, n) {
            return t = _i(this, Wf).fb(BigInt(t)), Li(i = _i(this, zf).hm(t, i, s, e, r, a, h, n))
        }
        orderDelete(t) {
            return (t = _i(this, Wf).fb(BigInt(t))) ? Li(t = _i(this, zf).gm(t)) : null
        }
        async ordersDelete(t) {
            return Ni(t = await _i(this, zf).yh(t))
        }
    }
    var zf = new WeakMap,
        Wf = new WeakMap;
    class Sf {
        constructor(t, i, s, e, r, a, h, n, o) {
            this.controller = new hf(t, new Dm(i), s, e, r, a, h, n, o), this.view = new Tf(this.controller, a)
        }
    }
    var jf = [{
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 18
        }, {
            propType: 6
        }, {
            propType: 17
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 11,
            propLength: 64
        }, {
            propType: 18
        }, {
            propType: 18
        }, {
            propType: 12,
            propLength: 4
        }],
        Bf = Hi.getSeriesSize(jf),
        $f = [{
            propType: 6
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 17
        }, {
            propType: 8
        }, {
            propType: 6
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 8
        }, {
            propType: 11,
            propLength: 64
        }],
        Lf = [{
            propType: 6
        }, {
            propType: 12,
            propLength: Bf,
            parser: function(t, i = 0) {
                return function(t, i = 0) {
                    return t = Hi.parse(t, jf, i), (i = new Um).lb = t[0], i.o = t[1], i.h = t[2], i.l = t[3], i.i = t[4], i.B = t[5], i.u = t[6], i.ea = t[7], i.ya = t[8], i.kb = t[9], i.Pc = t[10], i.m = t[11], i.K = t[12], i.v = t[13], i.A = t[14], i.Jc = t[15], i.Xf = t[16], i.Wf = t[17], i.comment = t[18], i.F = t[19], i.Ac = t[20], i
                }(t, i)
            }
        }, {
            propType: 12,
            propLength: Hi.getSeriesSize($f),
            parser: function(t, i = 0) {
                return function(t, i = 0) {
                    return t = Hi.parse(t, $f, i), (i = new Om(t[0])).pa = t[0], i.wa = t[1], i.B = t[2], i.volume = t[3], i.price = t[4], i.Om = t[5], i.O = t[6], i.L = t[7], i.Na = t[8], i.comment = t[9], i
                }(t, i)
            }
        }];
    class Nf extends Is {
        constructor() {
            super(...arguments), Xi(this, Af), Xi(this, If, new WeakMap)
        }
        V(t) {
            var i = _i(this, If).get(t);
            i || (i = Vi(this, Af, Cf).bind(this, t), _i(this, If).set(t, i)), this.C.V(19, i)
        }
        da(t) {
            (t = _i(this, If).get(t)) && this.C.da(19, t)
        }
    }
    var If = new WeakMap,
        Af = new WeakSet,
        Cf = function(t, i) {
            t(i = Hi.parse(i.Z, Lf, 0))
        };
    class Ef {
        constructor(t, i, s, e, r, a, h, n) {
            Xi(this, Df), Xi(this, Of), Xi(this, xf), Xi(this, Ff), Xi(this, Uf), Xi(this, Pf), Xi(this, qf), Xi(this, _f), Xi(this, Xf, t => {
                var i;
                _i(this, xf).ha();
                var s = t[1];
                if (t = t[2], s = _i(this, Uf).Ng(s.lb)) {
                    var e = _i(this, Ff).Ma(s.h),
                        r = Date.now() - s.Bj;
                    if (e = fi(_i(this, Pf), _i(this, qf), _i(this, xf), e, s, t, _i(this, _f), r), (r = t.isFinal()) && _i(this, Df).aa(7, e), 2 === s.o && 10004 === t.pa) {
                        let e = (null == (i = _i(this, Ff).Ba(s.h)) ? void 0 : i.trade.lf) ?? 7;
                        _i(this, Uf).Hg({
                            Ae: s,
                            time: Date.now() + 1e3 * e,
                            O: t.O,
                            L: t.L
                        })
                    }(s.complete = r) && _i(this, Uf).Ke(s.lb, t), _i(this, Df).aa(2, {
                        action: di(s),
                        result: bi(t),
                        id: s.lb,
                        order: t.B ? t.B.toString() : "",
                        code: t.pa,
                        log: e
                    }), _i(this, Df).aa(6, e)
                }
            }), Ri(this, Df, t), Ri(this, Of, i), Ri(this, xf, s), Ri(this, Ff, e), Ri(this, Uf, r), Ri(this, Pf, a), Ri(this, qf, h), Ri(this, _f, n), _i(this, Of).V(_i(this, Xf))
        }
        destroy() {
            _i(this, Of).da(_i(this, Xf))
        }
    }
    var Df = new WeakMap,
        Of = new WeakMap,
        xf = new WeakMap,
        Ff = new WeakMap,
        Uf = new WeakMap,
        Pf = new WeakMap,
        qf = new WeakMap,
        _f = new WeakMap,
        Xf = new WeakMap;
    class Rf {
        constructor(t, i, s, e, r, a, h, n) {
            this.controller = new Ef(t, new Nf(i), s, e, r, a, h, n)
        }
    }
    var Vf = [{
            propType: 6
        }, {
            propType: 11,
            propLength: 512
        }, {
            propType: 11,
            propLength: 512
        }, {
            propType: 6
        }, {
            propType: 12,
            propLength: 256
        }],
        Hf = Hi.getSeriesSize(Vf);
    class Gf extends Is {
        async Ol() {
            var t = (await this.C.qa(44)).Z,
                i = [],
                s = new DataView(t).getUint32(0, !0),
                e = 4;
            for (let h = 0; h < s; h++) {
                var r = i,
                    a = r.push;
                let s = Hi.parse(t, Vf, e);
                a.call(r, [s[0], s[1], s[2]]), e += Hf
            }
            return i
        }
    }
    class Jf {
        constructor(t, i) {
            Xi(this, Kf), Xi(this, Yf), Ri(this, Yf, t), Ri(this, Kf, i)
        }
        async bl() {
            if (_i(this, Yf).links) return _i(this, Yf).links;
            var t = await _i(this, Kf).Ol();
            return _i(this, Yf).links = t, [..._i(this, Yf).links]
        }
    }
    var Kf = new WeakMap,
        Yf = new WeakMap;
    class Zf {
        constructor() {
            this.links = null
        }
    }
    class Qf {
        constructor(t) {
            Xi(this, td), Ri(this, td, t)
        }
        async getLinks() {
            return _i(this, td).bl()
        }
    }
    var td = new WeakMap;
    class id {
        constructor(t) {
            Xi(this, sd, new Zf), Xi(this, ed), Ri(this, ed, new Gf(t)), this.controller = new Jf(_i(this, sd), _i(this, ed)), this.view = new Qf(this.controller)
        }
    }
    var sd = new WeakMap,
        ed = new WeakMap;
    class rd {
        constructor(t, i) {
            Xi(this, ad), Xi(this, hd), Ri(this, ad, t), Ri(this, hd, i)
        }
        Xk(t) {
            var i = _i(this, ad).ha().Ji,
                s = _i(this, hd).Ba(t);
            if (s) return i.filter(t => !t.pl() && Ur.check(t.path, s.trade.Pa))
        }
    }
    var ad = new WeakMap,
        hd = new WeakMap;
    class nd {
        constructor(t) {
            Xi(this, od), Ri(this, od, t)
        }
        getCommissions(t) {
            return (t = _i(this, od).Xk(t)) ? t.map(t => ({
                path: t.path,
                mode: t.mode,
                modeRange: t.bm,
                modeCharge: t.Zl,
                modeCurrency: t.$l,
                modeEntry: t.am,
                tiers: t.ab.map(t => ({
                    mode: t.mode,
                    type: t.type,
                    value: t.value,
                    rangeFrom: t.Bd,
                    rangeTo: t.Cd,
                    minimal: t.Yl,
                    maximal: t.Xl,
                    currency: t.currency
                }))
            })) : []
        }
    }
    var od = new WeakMap;
    class ld {
        constructor(t, i) {
            this.controller = new rd(t, i), this.view = new nd(this.controller)
        }
    }
    var cd = class {
            constructor(t, i, s, e, r) {
                Xi(this, ud), Xi(this, pd), Xi(this, md), Xi(this, fd), Xi(this, dd), Xi(this, bd), Xi(this, gd), Xi(this, yd), Xi(this, wd), Xi(this, vd), Xi(this, kd), Xi(this, Md), Xi(this, Td), Xi(this, zd), Xi(this, Wd), Xi(this, Sd), Xi(this, jd), Xi(this, Bd), Xi(this, $d), Xi(this, Ld), Xi(this, Nd), Xi(this, Id), Xi(this, Ad), Xi(this, Cd), Ri(this, Id, () => {}), Ri(this, Ad, () => {}), Ri(this, Cd, () => {}), this.destroy = () => {
                    _i(this, pd).controller.destroy(), _i(this, md).controller.destroy(), _i(this, dd).controller.destroy(), _i(this, gd).controller.destroy(), _i(this, yd).controller.destroy(), _i(this, Md).controller.destroy(), _i(this, Td).controller.destroy(), _i(this, zd).controller.destroy(), _i(this, Sd).controller.destroy(), _i(this, Bd).controller.destroy(), _i(this, $d).controller.destroy()
                }, Ri(this, ud, t), Ri(this, pd, s), _i(this, ud).V(15, _i(this, Id)), _i(this, ud).V(11, _i(this, Cd)), Ri(this, md, e), Ri(this, fd, new qe(i)), Ri(this, dd, new sr(i)), Ri(this, Ld, new id(i)), Ri(this, gd, new ga(_i(this, ud), i, _i(this, dd).controller, _i(this, md).controller)), Ri(this, Nd, new ld(_i(this, md).controller, _i(this, gd).controller)), Ri(this, bd, new Wr(i, _i(this, gd).controller)), Ri(this, yd, new hh(_i(this, ud), i, _i(this, gd).controller, _i(this, bd).controller)), Ri(this, wd, new zh(_i(this, gd).controller, _i(this, yd).controller)), Ri(this, vd, new bc(_i(this, gd).controller, _i(this, yd).controller, _i(this, wd).controller, _i(this, bd).controller, _i(this, md).controller)), Ri(this, kd, new zc(i)), Ri(this, Md, new ou(i, _i(this, md).controller)), Ri(this, Td, new xu(_i(this, ud), i, _i(this, yd).controller, _i(this, gd).controller, _i(this, md).controller, _i(this, wd).controller, _i(this, vd).controller)), Ri(this, zd, new Ip(_i(this, ud), i, _i(this, gd).controller, _i(this, Td).controller)), Ri(this, Wd, new Pp(_i(this, ud), _i(this, vd).controller, _i(this, md).controller, _i(this, Td).controller, _i(this, Md).controller)), Ri(this, Sd, new um(_i(this, ud), i, _i(this, md).controller, _i(this, yd).controller, _i(this, Wd).controller, _i(this, Md).controller, _i(this, Td).controller)), Ri(this, jd, new Em(_i(this, md).controller, _i(this, gd).controller, _i(this, yd).controller, _i(this, Td).controller)), Ri(this, Bd, new Sf(_i(this, ud), i, _i(this, pd).controller, _i(this, md).controller, _i(this, gd).controller, _i(this, Td).controller, _i(this, Md).controller, _i(this, jd).controller, r)), Ri(this, $d, new Rf(_i(this, ud), i, _i(this, md).controller, _i(this, gd).controller, _i(this, Bd).controller, _i(this, Td).controller, _i(this, Md).controller, r))
            }
            static async Lk(t, i, s, e, r) {
                return e = await De.Mk(t, i, e), i = new cd(t, i, s, e, r), await i.init(), {
                    destroy: i.destroy,
                    login: _i(i, pd).view,
                    account: _i(i, md).view,
                    notify: _i(i, fd).view,
                    symbols: _i(i, gd).view,
                    symbolTypes: _i(i, dd).view,
                    corporateLinks: _i(i, Ld).view,
                    rates: _i(i, kd).Lm,
                    otp: {
                        connect: Ai,
                        disconnect: Ci
                    },
                    ticks: _i(i, yd).view,
                    history: _i(i, Md).view,
                    books: _i(i, zd).view,
                    trade: _i(i, Td).view,
                    request: _i(i, Bd).view,
                    margin: _i(i, vd).view,
                    commissions: _i(i, Nd).view,
                    on: t.V.bind(t),
                    off: t.da.bind(t)
                }
            }
            async init() {
                _i(this, md).controller.ha().fh() || (await _i(this, dd).controller.init(), await _i(this, gd).controller.init(), await _i(this, Td).controller.init(), _i(this, Wd).controller.init())
            }
        },
        ud = new WeakMap,
        pd = new WeakMap,
        md = new WeakMap,
        fd = new WeakMap,
        dd = new WeakMap,
        bd = new WeakMap,
        gd = new WeakMap,
        yd = new WeakMap,
        wd = new WeakMap,
        vd = new WeakMap,
        kd = new WeakMap,
        Md = new WeakMap,
        Td = new WeakMap,
        zd = new WeakMap,
        Wd = new WeakMap,
        Sd = new WeakMap,
        jd = new WeakMap,
        Bd = new WeakMap,
        $d = new WeakMap,
        Ld = new WeakMap,
        Nd = new WeakMap,
        Id = new WeakMap,
        Ad = new WeakMap,
        Cd = new WeakMap,
        Ed = cd;
    u();
    var Dd = 0;
    class Od {
        constructor() {
            Xi(this, xd), this.count = 0, this.init = this.init.bind(this), this.lc = this.lc.bind(this), this.gi = this.gi.bind(this)
        }
        async init() {
            var t, i = Fi({});
            (null == (t = this.C) ? void 0 : t.Ya) || (this.count += 1, this.C = new js(Ys, {
                count: this.count
            }), await this.C.Le(), await this.C.qa(29, i))
        }
        lc() {
            var t;
            (null == (t = this.C) ? void 0 : t.Ya) && this.C.close()
        }
        gi() {
            if (!this.C || !this.C.Ya) throw Error(JSON.stringify([-1, 103]));
            return Vi(this, xd, Fd).call(this)
        }
    }
    var xd = new WeakSet,
        Fd = async function() {
            var t = await this.C.qa(41);
            return Hi.parse(t.Z, [{
                propType: 11,
                propLength: 32
            }, {
                propType: 11,
                propLength: 32
            }])
        }, Ud = new class {
            constructor() {
                this.controller = new Od
            }
        }, Pd = {
            init: Ud.controller.init,
            close: Ud.controller.lc,
            traderParams: Ud.controller.gi
        }, qd = [{
            propType: 6
        }, {
            propType: 17
        }, {
            propType: 11,
            propLength: 32
        }, {
            propType: 11,
            propLength: 32
        }], _d = [{
            propType: 4
        }, {
            propType: 4
        }], Xd = Object.freeze(Object.defineProperty({
            __proto__: null,
            pm: Ui,
            tj: Pi
        }, Symbol.toStringTag, {
            value: "Module"
        }));
    class Rd {
        constructor() {
            Xi(this, Vd), this.count = 0, this.init = this.init.bind(this), this.demo = this.demo.bind(this), this.lc = this.lc.bind(this), this.Gc = this.Gc.bind(this), this.Ed = this.Ed.bind(this)
        }
        async init() {
            var t, i = Fi({});
            (null == (t = this.C) ? void 0 : t.Ya) || (this.count += 1, this.C = new js(Ys, {
                count: this.count
            }), await this.C.Le(), await this.C.qa(29, i))
        }
        lc() {
            var t;
            (null == (t = this.C) ? void 0 : t.Ya) && this.C.close()
        }
        demo(t) {
            if (!this.C || !this.C.Ya) throw Error(JSON.stringify([-1, 103]));
            return this.request = Vi(this, Vd, Hd).call(this, {
                mt_firstName: t.mt_firstName,
                mt_secondName: t.mt_secondName,
                mt_email: t.mt_email,
                mt_deposit: t.mt_deposit,
                mt_leverage: t.mt_leverage,
                mt_group: t.mt_group,
                mt_agreements: t.mt_agreements,
                mt_language: t.mt_language,
                mt_phonePassword: t.mt_phonePassword,
                mt_country: t.mt_country,
                mt_city: t.mt_city,
                mt_state: t.mt_state,
                mt_zipcode: t.mt_zipcode,
                mt_address: t.mt_address,
                mt_phone: t.mt_phone,
                mt_emailConfirmCode: t.mt_emailConfirmCode,
                mt_phoneConfirmCode: t.mt_phoneConfirmCode,
                mt_domain: t.mt_domain,
                mt_utmCampaign: t.mt_utmCampaign,
                mt_utmSource: t.mt_utmSource
            })
        }
        Gc(t, i) {
            if (!this.C || !this.C.Ya) throw Error(JSON.stringify([-1, 103]));
            return Vi(this, Vd, Gd).call(this, t, i)
        }
        async Ed(t, i, s) {
            if (!this.C || !this.C.Ya) try {
                await this.init(), await this.Gc(t, s)
            } catch {
                throw Error(JSON.stringify([-1, 103]))
            }
            return Vi(this, Vd, Jd).call(this, t)
        }
    }
    var Vd = new WeakSet,
        Hd = async function(t) {
            return {
                account: Ui((t = await this.C.qa(30, xi(t))).Z)
            }
        }, Gd = async function(t, i) {
            var s = this.C,
                e = s.qa;
            return t = Hi.serialize([
                [2, i],
                [12, Ls, 16],
                [12, xi(t)]
            ]), {
                verify: Pi((s = await e.call(s, 27, t)).Z)
            }
        }, Jd = async function(t) {
            return {
                verify: Pi((t = await this.C.qa(40, xi(t))).Z)
            }
        }, Kd = new class {
            constructor() {
                this.controller = new Rd
            }
        }, Yd = {
            init: Kd.controller.init,
            close: Kd.controller.lc,
            open: Kd.controller.demo,
            getVerifyCodes: Kd.controller.Gc,
            sendVerifyCodes: Kd.controller.Ed
        }, Zd = t => Hi.serialize(Array.from({
            length: t
        }, () => [3, 0]));
    class Qd {
        constructor() {
            Xi(this, tb), this.count = 0, this.init = this.init.bind(this), this.real = this.real.bind(this), this.lc = this.lc.bind(this), this.Gc = this.Gc.bind(this), this.Ed = this.Ed.bind(this)
        }
        async init() {
            var t, i = Fi({});
            (null == (t = this.C) ? void 0 : t.Ya) || (this.count += 1, this.C = new js(Ys, {
                count: this.count
            }), await this.C.Le(), await this.C.qa(29, i))
        }
        async lc() {
            var t;
            (null == (t = this.C) ? void 0 : t.Ya) && await this.C.close()
        }
        real(t) {
            if (!this.C || !this.C.Ya) throw Error(JSON.stringify([-1, 103]));
            return Vi(this, tb, ib).call(this, t)
        }
        Gc(t, i) {
            if (!this.C || !this.C.Ya) throw Error(JSON.stringify([-1, 103]));
            return Vi(this, tb, sb).call(this, t, i)
        }
        async Ed(t, i, s) {
            if (!this.C || !this.C.Ya) try {
                await this.init(), await this.Gc(t, s)
            } catch {
                throw Error(JSON.stringify([-1, 103]))
            }
            return Vi(this, tb, eb).call(this, t)
        }
    }
    var tb = new WeakSet,
        ib = async function(t) {
            var i = Promise.resolve().then(() => Xd);
            t = this.C.qa(39, function(t) {
                var i = xi(t);
                return t = Hi.serialize([
                    [11, t.mt_firstName, 128],
                    [11, t.mt_secondName, 128],
                    [11, t.mt_middleName ?? "", 128],
                    [9, t.mt_birthDate],
                    [6, t.mt_gender ?? 0],
                    [11, t.mt_language, 128],
                    [11, t.mt_citizenship, 64],
                    [11, t.mt_taxId, 128],
                    [6, t.mt_employment || 0],
                    [6, t.mt_industry || 0],
                    [6, t.mt_education || 0],
                    [6, t.mt_wealth || 0],
                    [18, BigInt(t.mt_annualIncome)],
                    [18, BigInt(t.mt_netWorth)],
                    [18, BigInt(t.mt_annualDeposit)],
                    [6, t.mt_experienceFx || 0],
                    [6, t.mt_experienceCfd || 0],
                    [6, t.mt_experienceFutures || 0],
                    [6, t.mt_experienceStocks || 0],
                    [12, Zd(128), 512], ...qi(t.mt_documents)
                ]), null !== i && null !== t ? Hi.concat(i, t) : null
            }(t));
            var [{
                pm: s
            }, e] = await Promise.all([i, t]);
            return {
                account: s(e.Z)
            }
        }, sb = async function(t, i) {
            var s = Promise.resolve().then(() => Xd);
            t = this.C.qa(27, Hi.serialize([
                [2, i],
                [12, Ls, 16],
                [12, xi(t)]
            ]));
            var [{
                tj: e
            }, r] = await Promise.all([s, t]);
            return {
                verify: e(r.Z)
            }
        }, eb = async function(t) {
            var i = Promise.resolve().then(() => Xd);
            t = await this.C.qa(40, xi(t));
            var [{
                tj: s
            }, e] = await Promise.all([i, t]);
            return {
                verify: s(e.Z)
            }
        }, rb = new class {
            constructor() {
                this.controller = new Qd
            }
        }, ab = {
            demo: Yd,
            real: {
                init: rb.controller.init,
                close: rb.controller.lc,
                open: rb.controller.real,
                getVerifyCodes: rb.controller.Gc,
                sendVerifyCodes: rb.controller.Ed
            },
            config: Pd,
            login: async function(t, i, s, e, r, a, h, n, o) {
                return await u(), async function() {
                    var t = new js(Ys, {
                        count: Dd += 1,
                        Xh: o
                    });
                    return await t.Le(), async function() {
                        var s = new Bs;
                        t.subscribe("close", Di.bind(null, s, i)), t.subscribe("open", Ei.bind(null, s)), t.subscribe("error", Oi.bind(null, s));
                        var o = new Ks(s, t),
                            [l, c] = await o.controller.login(i, e, r, a, n);
                        return s = await async function(t, i, s, e, r, a) {
                            return await Ed.Lk(i, s, e, r, a)
                        }(0, s, t, o, i, h), [l, c || 0n, s]
                    }
                }
            },
            connectOtp: async function(t, i, s, e, r) {
                await Ai(t, i, s, e, r)
            },
            utils: {
                trade: {
                    printError: pi,
                    isLoadingCode: function(t) {
                        return void 0 !== t && [0, 10001, 10002, 10003, 10005].includes(t)
                    },
                    isSuccessCode: mi
                },
                volume: {
                    toDouble: l
                },
                order: {
                    isOrderType: function(t) {
                        return [0, 1, 2, 3, 4, 5, 6, 7, 8].includes(t)
                    },
                    isLimitOrStopLimit: ut,
                    isLimitOrStop: function(t) {
                        return ot(t) || lt(t)
                    },
                    isBuy: rt,
                    isSell: at,
                    isMarket: ht,
                    isPending: nt,
                    isLimit: ot,
                    isStop: lt,
                    isStopLimit: ct,
                    printType: pt,
                    printTypeShort: function(t) {
                        switch (t) {
                            case 0:
                                return "B";
                            case 1:
                                return "S";
                            case 2:
                                return "BL";
                            case 3:
                                return "SL";
                            case 4:
                                return "BS";
                            case 5:
                                return "SS";
                            case 6:
                                return "BSL";
                            case 7:
                                return "SSL";
                            case 8:
                                return "CB";
                            default:
                                return "unknown"
                        }
                    },
                    printOrderStatus: function(t) {
                        switch (t) {
                            case 0:
                                return "Started";
                            case 1:
                                return "Placed";
                            case 2:
                                return "Canceled";
                            case 3:
                                return "Partial";
                            case 4:
                                return "Filled";
                            case 5:
                                return "Rejected";
                            case 6:
                                return "Expired";
                            case 7:
                                return "Request adding";
                            case 8:
                                return "Request modifying";
                            case 9:
                                return "Request cancelling";
                            default:
                                return "unknown"
                        }
                    }
                },
                deal: {
                    printAction: ft,
                    isBuy: function(t) {
                        return 0 === t
                    },
                    isSell: function(t) {
                        return 1 === t
                    },
                    isBalance: dt,
                    isBalanceAllowed: bt
                },
                books: {
                    printBookActionType: function(t) {
                        switch (t) {
                            case 1:
                                return "BL";
                            case 2:
                                return "BS";
                            case 3:
                                return "SL";
                            case 4:
                                return "ST";
                            case 5:
                                return "sl";
                            case 6:
                                return "tp";
                            default:
                                return "unknown"
                        }
                    }
                },
                symbol: {
                    printCalcMode: function(t) {
                        switch (t) {
                            case 0:
                                return "Forex";
                            case 1:
                                return "Futures";
                            case 2:
                                return "CFD";
                            case 3:
                                return "CFD Index";
                            case 4:
                                return "CFD Leverage";
                            case 5:
                                return "Forex No Leverage";
                            case 32:
                                return "Exchange Stocks";
                            case 33:
                                return "Exchange Futures";
                            case 34:
                                return "FORTS Futures";
                            case 35:
                                return "Exchange Option";
                            case 36:
                                return "Exchange Margin Option";
                            case 37:
                                return "Exchange Bonds";
                            case 38:
                                return "Exchange MOEX Stocks";
                            case 39:
                                return "Exchange MOEX Bonds";
                            case 64:
                                return "Collateral";
                            default:
                                return ""
                        }
                    },
                    printTradeMode: function(t) {
                        switch (t) {
                            case 0:
                                return "Disabled";
                            case 1:
                                return "Long only";
                            case 2:
                                return "Short only";
                            case 3:
                                return "Close only";
                            case 4:
                                return "Full access";
                            default:
                                return ""
                        }
                    }
                }
            }
        };
    return window.__api = ab, i.apiModule = ab, Object.defineProperty(i, Symbol.toStringTag, {
        value: "Module"
    }), i
}({}, e, s, i, 0, a, Object.freeze(Object.defineProperty({
    __proto__: null,
    default: async function() {
        return h(() => import("./DKWDBbg3.js"), [])
    }
}, Symbol.toStringTag, {
    value: "Module"
})), r).apiModule;
export {
    n as apiModule
};